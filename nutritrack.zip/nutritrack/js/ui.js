/* ===========================================================================
   NutriTrack – js/ui.js

   Oberfläche: Rendering, Tabs, Dialoge, Toasts, Filter und Suche, Modale,
   Einstellungs-Menü und App-Start. Wird nach config.js, storage.js und
   engine.js geladen und vor ai.js.

   Aus storage.js werden benutzt: Zustand (userProfile,
   selectedDate, loggedFoods, appSettings) und alle Speicher-
   Funktionen. Aus engine.js: Berechnung, Personalisierung und Statistik.
   Aus ai.js werden nur scrollChatToBottom() und die Chat-Handler des HTML
   (sendMessage, clearChatHistory, ...) erwartet.

   Wie die übrigen Skripte ist dies bewusst kein ES-Modul: Die ca. 50
   Inline-Handler in index.html (onclick="switchTab(0)" usw.) brauchen globale
   Funktionen.
   =========================================================================== */



/* ===========================================================================
   1. UI-ZUSTAND
   (loggedFoods, selectedDate, userProfile, appSettings ... stehen in storage.js)
   =========================================================================== */

let currentTabIndex = 0;

/* Aktuell im Kalender angezeigter Monat (monthIndex 0–11); null = noch nicht gesetzt */
let calendarViewYear = null;
let calendarViewMonth = null;

let selectedCategoryFilter = CATEGORY_ALL;
let selectedAttributeFilter = 'all';
let selectedSortOption = 'default';
let filtersExpanded = false;
let favoritesOnly = false;

let selectedFoodForModal = null;
let currentModalQuantity = 100;
let selectedFoodOptions = {};

let activeAppDialogCleanup = null;
let toastTimer = null;

/* Mülleimer-Symbol (Linien-Stil wie in gängigen Apps), nutzt die Textfarbe des Buttons */
const TRASH_ICON_SVG = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 6h18"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/><path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/><path d="M10 11v6"/><path d="M14 11v6"/></svg>';

/* Monatswechsel im Kalender */
const CALENDAR_SLIDE_OUT_MS = 130;
const CALENDAR_SLIDE_DISTANCE_PX = 28;
const CALENDAR_HEIGHT_MS = 240;
let calendarSlideTimer = null;
let calendarHeightTimer = null;



/* ===========================================================================
   2. ALLGEMEINE HILFSFUNKTIONEN
   =========================================================================== */

function escapeHtml(value) {
  return String(value ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

/* Zahl aus einem Eingabefeld. Leeres oder ungültiges Feld ergibt den Rückfallwert. */
function readNumberInput(id, fallback = 0) {
  const element = document.getElementById(id);
  if (!element || String(element.value).trim() === '') return fallback;

  const value = Number(String(element.value).replace(',', '.'));
  return Number.isFinite(value) ? value : fallback;
}

function formatUnit(unit, quantity) {
  const rounded = Math.round(quantity * 100) / 100;
  const formattedNumber = rounded.toString().replace('.', ',');

  if (rounded === 1) return `${formattedNumber} ${unit}`;
  if (unit === 'Portion' && rounded < 1) return `${formattedNumber} ${unit}`;

  return `${formattedNumber} ${UNIT_PLURALS[unit] || unit}`;
}

function formatDateLabel(iso) {
  const [year, month, day] = iso.split('-').map(Number);
  const date = new Date(year, month - 1, day);

  if (iso === getTodayISO()) return 'Heute';
  return date.toLocaleDateString('de-DE', { weekday: 'long', day: 'numeric', month: 'long' });
}

function showToast(message, icon = '✅') {
  const toast = document.getElementById('toast-msg');
  const textElement = document.getElementById('toast-text');
  const iconElement = document.getElementById('toast-icon');
  if (!toast) return;

  if (textElement) textElement.textContent = message;
  if (iconElement) iconElement.textContent = icon;

  toast.classList.remove('opacity-0', 'pointer-events-none');
  toast.classList.add('opacity-100');

  // Ein neuer Toast startet die Anzeigedauer neu, statt vom alten Timer beendet zu werden.
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => {
    toast.classList.remove('opacity-100');
    toast.classList.add('opacity-0', 'pointer-events-none');
  }, TOAST_DURATION_MS);
}

function toggleScoreExplanation() {
  const panel = document.getElementById('score-explanation-panel');
  const icon = document.getElementById('score-exp-icon');
  if (!panel) return;

  const isOpen = panel.classList.toggle('is-open');
  if (icon) icon.textContent = isOpen ? '▲' : '▼';
}



/* ===========================================================================
   3. APP-DIALOG (ersetzt prompt() und confirm())
   onConfirm gibt true/undefined (schließen), false (offen lassen) oder
   { error } (Fehlertext im Eingabedialog) zurück.
   =========================================================================== */

function openAppDialog({
  mode = 'confirm',
  title = 'Bestätigung',
  message = '',
  icon = 'ℹ️',
  inputLabel = 'Name',
  inputPlaceholder = '',
  inputValue = '',
  inputMaxLength = 20,
  confirmText = 'Bestätigen',
  danger = false,
  onConfirm = null
} = {}) {
  const backdrop = document.getElementById('app-dialog-backdrop');
  const titleElement = document.getElementById('app-dialog-title');
  const messageElement = document.getElementById('app-dialog-message');
  const iconElement = document.getElementById('app-dialog-icon');
  const inputWrap = document.getElementById('app-dialog-input-wrap');
  const input = document.getElementById('app-dialog-input');
  const inputLabelElement = document.getElementById('app-dialog-input-label');
  const inputError = document.getElementById('app-dialog-input-error');
  const cancel = document.getElementById('app-dialog-cancel');
  const confirmButton = document.getElementById('app-dialog-confirm');

  if (!backdrop || !titleElement || !messageElement || !cancel || !confirmButton) return;

  if (activeAppDialogCleanup) activeAppDialogCleanup();

  titleElement.textContent = title;
  messageElement.textContent = message;
  iconElement.textContent = icon;
  confirmButton.textContent = confirmText;
  confirmButton.className = `flex-1 py-3 ${danger ? 'bg-red-500 hover:bg-red-600' : 'bg-orange-500 hover:bg-orange-600'} text-white font-bold rounded-xl text-xs btn-anim transition-colors`;

  inputWrap.classList.toggle('hidden', mode !== 'input');
  inputLabelElement.textContent = inputLabel;
  input.value = inputValue;
  input.maxLength = inputMaxLength;
  input.placeholder = inputPlaceholder;
  inputError.classList.add('hidden');
  inputError.textContent = '';

  const handleKeydown = event => {
    if (event.key === 'Escape') close();

    if (event.key === 'Enter' && mode === 'input') {
      event.preventDefault();
      confirmButton.click();
    }
  };

  const cleanup = () => {
    cancel.onclick = null;
    confirmButton.onclick = null;
    backdrop.onclick = null;
    document.removeEventListener('keydown', handleKeydown);
    activeAppDialogCleanup = null;
  };

  // Beim Schließen müssen alle Handler weg, sonst löst Enter später im Hintergrund erneut aus.
  const close = () => {
    backdrop.classList.remove('is-open');
    cleanup();
  };

  cancel.onclick = close;
  backdrop.onclick = event => { if (event.target === backdrop) close(); };

  confirmButton.onclick = () => {
    const result = typeof onConfirm === 'function'
      ? onConfirm(mode === 'input' ? input.value : undefined)
      : true;

    if (result && typeof result === 'object' && result.error) {
      inputError.textContent = result.error;
      inputError.classList.remove('hidden');
      input.focus();
      return;
    }

    if (result !== false) close();
  };

  document.addEventListener('keydown', handleKeydown);
  activeAppDialogCleanup = cleanup;

  requestAnimationFrame(() => {
    backdrop.classList.add('is-open');
    if (mode === 'input') {
      setTimeout(() => {
        input.focus();
        input.select();
      }, 80);
    }
  });
}



/* ===========================================================================
   4. TABS
   =========================================================================== */

function switchTab(index) {
  const chatPane = document.getElementById('chat-tab-pane');

  // Der Chat liegt außerhalb des Sliders und öffnet als Overlay.
  if (index === CHAT_TAB_INDEX) {
    if (chatPane) {
      chatPane.classList.add('chat-pane-open');

      setTimeout(() => {
        const input = document.getElementById('chat-input');
        if (input) input.focus();
        if (typeof scrollChatToBottom === 'function') scrollChatToBottom();
      }, CHAT_FOCUS_DELAY_MS);
    }
    return;
  }

  if (chatPane) chatPane.classList.remove('chat-pane-open');
  if (typeof closeChatDrawer === 'function') closeChatDrawer();

  const previousIndex = currentTabIndex;
  currentTabIndex = index;

  const wrapper = document.getElementById('tabs-wrapper');
  if (wrapper) wrapper.style.transform = `translateX(-${index * (100 / TAB_COUNT)}%)`;

  const indicator = document.getElementById('nav-indicator');
  if (indicator) indicator.style.transform = `translateX(${index * 100}%)`;

  const panes = document.querySelectorAll('.tab-pane');

  for (let i = 0; i < TAB_COUNT; i += 1) {
    const button = document.getElementById(`tab-btn-${i}`);
    const pane = panes[i];

    if (button) {
      button.classList.toggle('text-orange-500', i === index);
      button.classList.toggle('font-bold', i === index);
      button.classList.toggle('text-slate-900', i !== index);
      button.classList.toggle('font-normal', i !== index);
    }

    if (pane) pane.classList.toggle('active-pane', i === index);
  }

  if (index === STATS_TAB_INDEX) updateStatisticsOverview();
  if (index === SETTINGS_TAB_INDEX) renderSettingsUI();

  // Wechselt man den Reiter, beginnt der neue Reiter wieder ganz oben.
  // (Er liegt in diesem Moment noch außerhalb des Bildschirms, es gibt also keinen sichtbaren Sprung.)
  if (index !== previousIndex && panes[index]) panes[index].scrollTop = 0;
}



/* ===========================================================================
   5. DATUM
   =========================================================================== */

function initDateHeader() {
  const element = document.getElementById('current-date-str');
  if (element) element.textContent = formatDateLabel(selectedDate);
  renderDatePicker();
}

function closeDatePicker() {
  const panel = document.getElementById('date-picker-panel');
  const icon = document.getElementById('date-picker-icon');

  if (panel) panel.classList.remove('is-open');
  if (icon) icon.style.transform = 'rotate(0deg)';
}

function toggleDatePicker() {
  const panel = document.getElementById('date-picker-panel');
  const icon = document.getElementById('date-picker-icon');
  if (!panel) return;

  const willOpen = !panel.classList.contains('is-open');

  // Erst Monat festlegen und den Kalender komplett aufbauen, dann erst aufklappen:
  // So erscheinen Titel, Wochentage und Tage im selben Moment.
  if (willOpen) {
    const [year, month] = selectedDate.split('-').map(Number);
    calendarViewYear = year;
    calendarViewMonth = month - 1;
    renderDatePicker();
  }

  panel.classList.toggle('is-open', willOpen);
  if (icon) icon.style.transform = willOpen ? 'rotate(180deg)' : 'rotate(0deg)';
}

/* ISO-Datum (JJJJ-MM-TT) aus Jahr, Monatsindex (0–11) und Tag. */
function calendarDateToISO(year, monthIndex, day) {
  return `${year}-${String(monthIndex + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
}

/* Monat als fortlaufende Zahl (Jahr · 12 + Monatsindex), zum Vergleichen und Begrenzen. */
function monthIndexOfISO(iso) {
  const [year, month] = iso.split('-').map(Number);
  return year * 12 + (month - 1);
}

/*
   Frühester wählbarer Tag. Mit Speicherzeitraum gilt heute minus Speicherzeitraum
   (ältere Tage werden ohnehin gelöscht). Bei "unbegrenzt" gelten mindestens die
   letzten DATE_PICKER_DAYS Tage, bei älteren Einträgen entsprechend weiter zurück.
*/
function getEarliestSelectableISO(store = null) {
  const earliest = new Date();
  earliest.setHours(0, 0, 0, 0);

  const retentionDays = Number(appSettings.retentionDays) || 0;

  if (retentionDays > 0) {
    earliest.setDate(earliest.getDate() - retentionDays);
    return calendarDateToISO(earliest.getFullYear(), earliest.getMonth(), earliest.getDate());
  }

  earliest.setDate(earliest.getDate() - (DATE_PICKER_DAYS - 1));
  let earliestISO = calendarDateToISO(earliest.getFullYear(), earliest.getMonth(), earliest.getDate());

  const dates = (store || getDateFoodStore()).dates;
  Object.keys(dates).forEach(iso => {
    const isValidKey = /^\d{4}-\d{2}-\d{2}$/.test(iso);
    if (isValidKey && iso < earliestISO && Array.isArray(dates[iso]) && dates[iso].length > 0) earliestISO = iso;
  });

  return earliestISO;
}

/*
   Monat im Kalender wechseln (-1 = zurück, +1 = vor), begrenzt auf den wählbaren Zeitraum.
   Animation: Der alte Monat gleitet kurz heraus, der neue gleitet aus der Wechselrichtung
   herein; ändert sich dabei die Zeilenzahl, wächst/schrumpft die Karte weich mit.
*/
function shiftCalendarMonth(delta) {
  const lowest = monthIndexOfISO(getEarliestSelectableISO());
  const highest = monthIndexOfISO(getTodayISO());
  const current = calendarViewYear * 12 + calendarViewMonth;
  const next = Math.min(highest, Math.max(lowest, current + delta));

  if (next === current) return;

  calendarViewYear = Math.floor(next / 12);
  calendarViewMonth = next % 12;

  const content = document.getElementById('date-picker-content');
  const direction = delta > 0 ? 1 : -1;
  const movingParts = content ? content.querySelectorAll('.cal-month, .cal-grid') : [];

  if (!content || movingParts.length === 0) {
    renderDatePicker();
    return;
  }

  movingParts.forEach(part => {
    part.style.setProperty('--cal-shift', `${-direction * CALENDAR_SLIDE_DISTANCE_PX}px`);
    part.classList.add('cal-leave');
  });

  // Schnelles Mehrfach-Tippen: Es zählt nur der zuletzt erreichte Monat.
  clearTimeout(calendarSlideTimer);
  calendarSlideTimer = setTimeout(() => {
    const heightBefore = content.offsetHeight;
    renderDatePicker(direction);
    animateCalendarHeight(content, heightBefore);
  }, CALENDAR_SLIDE_OUT_MS);
}

/* Karte von der alten auf die neue Höhe gleiten lassen (Monate haben 4–6 Wochenzeilen). */
function animateCalendarHeight(content, heightBefore) {
  const heightAfter = content.offsetHeight;
  if (!heightBefore || heightBefore === heightAfter) return;

  clearTimeout(calendarHeightTimer);

  content.style.transition = 'none';
  content.style.overflow = 'hidden';
  content.style.height = `${heightBefore}px`;
  content.getBoundingClientRect(); // Layout erzwingen, damit die Startgröße gilt

  content.style.transition = `height ${CALENDAR_HEIGHT_MS}ms var(--motion-ease)`;
  content.style.height = `${heightAfter}px`;

  calendarHeightTimer = setTimeout(() => {
    content.style.transition = '';
    content.style.overflow = '';
    content.style.height = '';
  }, CALENDAR_HEIGHT_MS + 40);
}

function selectDate(iso) {
  // Nur Tage von heute bis zum Beginn des Speicherzeitraums sind wählbar.
  if (iso > getTodayISO() || iso < getEarliestSelectableISO()) return;

  selectedDate = iso;
  loadLoggedFoods();
  initDateHeader();
  renderLoggedFoods();
  updateStatisticsOverview();

  if (!loggedFoods || loggedFoods.length === 0) {
    showToast('Keine Daten für diesen Tag verfügbar', '⚠️');
  }

  closeDatePicker();
}

const CALENDAR_WEEKDAYS = ['Mo', 'Di', 'Mi', 'Do', 'Fr', 'Sa', 'So'];

/*
   Baut den gesamten Kalender (Titel, Monat, Wochentage, Tage) in einem Schritt auf.
   Grau und nicht wählbar: Tage nach heute und Tage vor Beginn des Speicherzeitraums.
*/
function renderDatePicker(slideDirection = 0) {
  const content = document.getElementById('date-picker-content');
  if (!content) return;

  // Ein normales Neuzeichnen (z. B. Datum gewählt) macht einen noch wartenden Monatswechsel überflüssig.
  if (!slideDirection) clearTimeout(calendarSlideTimer);

  if (calendarViewYear === null || calendarViewMonth === null) {
    const [year, month] = selectedDate.split('-').map(Number);
    calendarViewYear = year;
    calendarViewMonth = month - 1;
  }

  const year = calendarViewYear;
  const month = calendarViewMonth;

  const store = getDateFoodStore();
  const todayISO = getTodayISO();
  const earliestISO = getEarliestSelectableISO(store);

  // Jahr nur anzeigen, wenn es nicht das aktuelle Jahr ist.
  const monthName = new Date(year, month, 1).toLocaleDateString('de-DE', { month: 'long' });
  const monthLabel = year === Number(todayISO.slice(0, 4)) ? monthName : `${monthName} ${year}`;

  const viewIndex = year * 12 + month;
  const canGoBack = viewIndex > monthIndexOfISO(earliestISO);
  const canGoForward = viewIndex < monthIndexOfISO(todayISO);

  // Wochenraster beginnt am Montag.
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const mondayIndex = (new Date(year, month, 1).getDay() + 6) % 7;
  const blanks = '<span></span>'.repeat(mondayIndex);

  const days = Array.from({ length: daysInMonth }, (_, offset) => {
    const day = offset + 1;
    const iso = calendarDateToISO(year, month, day);
    const isSelectable = iso >= earliestISO && iso <= todayISO;
    const hasEntries = Array.isArray(store.dates[iso]) && store.dates[iso].length > 0;

    const classes = ['cal-day'];
    if (!isSelectable) classes.push('is-disabled');
    if (iso === todayISO) classes.push('is-today');
    if (isSelectable && iso === selectedDate) classes.push('is-selected');

    return `<button type="button" class="${classes.join(' ')}" ${isSelectable ? `onclick="selectDate('${iso}')"` : 'disabled'} title="${escapeHtml(formatDateLabel(iso))}"><span>${day}</span>${hasEntries ? '<span class="cal-dot">●</span>' : ''}</button>`;
  }).join('');

  content.innerHTML = `
    <h2 class="cal-title">Tagebuchübersicht</h2>
    <div class="cal-month-row">
      <button type="button" class="cal-nav-btn" onclick="shiftCalendarMonth(-1)" aria-label="Vorheriger Monat" ${canGoBack ? '' : 'disabled'}>‹</button>
      <span class="cal-month">${escapeHtml(monthLabel)}</span>
      <button type="button" class="cal-nav-btn" onclick="shiftCalendarMonth(1)" aria-label="Nächster Monat" ${canGoForward ? '' : 'disabled'}>›</button>
    </div>
    <div class="cal-weekdays">${CALENDAR_WEEKDAYS.map(weekday => `<span>${weekday}</span>`).join('')}</div>
    <div class="cal-grid">${blanks}${days}</div>
  `;

  // Beim Monatswechsel gleitet der neue Monat aus der Wechselrichtung herein.
  if (slideDirection) {
    content.querySelectorAll('.cal-month, .cal-grid').forEach(part => {
      part.style.setProperty('--cal-shift', `${slideDirection * CALENDAR_SLIDE_DISTANCE_PX}px`);
      part.classList.add('cal-enter');
    });
  }
}



/* ===========================================================================
   6. TAGEBUCH
   =========================================================================== */

function renderLoggedFoods() {
  const container = document.getElementById('logged-foods-container');
  const badge = document.getElementById('item-count-badge');
  if (!container) return;

  if (badge) badge.textContent = `${loggedFoods.length} ${loggedFoods.length === 1 ? 'Eintrag' : 'Einträge'}`;

  if (loggedFoods.length === 0) {
    container.innerHTML = `
      <div class="bg-white border border-slate-100 rounded-3xl p-8 text-center shadow-sm my-6 animate-fade-in">
        <div class="w-16 h-16 bg-orange-100 text-orange-500 rounded-2xl flex items-center justify-center text-3xl mx-auto mb-4 shadow-inner">
          🥗
        </div>
        <h2 class="text-base font-bold text-slate-800 mb-1">Noch keine Lebensmittel hinzugefügt</h2>
        <p class="text-xs text-slate-400 mb-6 leading-relaxed max-w-xs mx-auto">Dein Ernährungstagebuch für diesen Tag ist noch leer. Starte jetzt mit deinem ersten Eintrag!</p>
        <button type="button" onclick="switchTab(1)" class="px-6 py-3.5 bg-gradient-to-r from-orange-500 to-amber-500 text-white font-bold text-xs rounded-2xl btn-anim pulse-btn shadow-lg shadow-orange-500/20 inline-flex items-center space-x-2">
          <span>+ Lebensmittel hinzufügen</span>
        </button>
      </div>
    `;
    return;
  }

  container.innerHTML = loggedFoods.map(item => `
    <div class="bg-slate-100/80 hover:bg-slate-100 border border-slate-200/60 p-3.5 rounded-2xl flex items-center justify-between card-anim shadow-sm">
      <div class="flex items-center space-x-3">
        <div class="w-11 h-11 bg-white rounded-xl flex items-center justify-center text-2xl shadow-sm border border-slate-100">
          ${escapeHtml(item.icon || '🍽️')}
        </div>
        <div>
          <h3 class="font-bold text-slate-800 text-sm leading-tight">${escapeHtml(item.name)}</h3>
          <div class="flex items-center space-x-2 text-xs text-slate-500 mt-0.5">
            <span class="font-semibold text-orange-600">${escapeHtml(formatUnit(item.unit, item.quantity))}</span>
            ${item.details ? `<span class="text-slate-400">• ${escapeHtml(item.details)}</span>` : ''}
          </div>
        </div>
      </div>
      <button type="button" onclick="deleteLoggedFoodById(${Number(item.id)})" class="w-8 h-8 text-slate-400 hover:text-red-500 hover:bg-red-50 rounded-xl flex items-center justify-center btn-anim transition-colors" title="Eintrag löschen" aria-label="Eintrag löschen">
        ${TRASH_ICON_SVG}
      </button>
    </div>
  `).join('');
}

/* Nach jeder Änderung am Tagebuch: speichern und alles Abhängige aktualisieren. */
function commitLoggedFoodsChange() {
  saveLoggedFoods();
  renderLoggedFoods();
  renderDatePicker();
  updateStatisticsOverview();
}

/* Eindeutige ID auch bei mehreren Einträgen in derselben Millisekunde. */
function generateEntryId() {
  const highest = loggedFoods.reduce((max, item) => Math.max(max, Number(item.id) || 0), 0);
  return Math.max(Date.now(), highest + 1);
}

/* Tagebuch-Eintrag aus einem Katalog-Lebensmittel (Nährwerte pro 100 g / 100 ml). */
function createLoggedEntry(food, quantity, details = '') {
  return {
    id: generateEntryId(),
    foodId: food.id,
    name: food.name,
    category: food.category,
    quantity,
    unit: food.unit,
    icon: food.icon,
    details,
    healthScore: food.healthScore,
    foodQuality: food.foodQuality ?? food.healthScore,
    waterContribution: food.waterContribution ?? CUSTOM_FOOD_DEFAULTS.waterContribution.solid,
    caloriesPer100: food.caloriesPer100,
    proteinPer100: food.proteinPer100,
    carbsPer100: food.carbsPer100,
    fatPer100: food.fatPer100,
    fiberPer100: food.fiberPer100,
    sugarPer100: food.sugarPer100,
    saturatedFatPer100: food.saturatedFatPer100,
    saltPer100: food.saltPer100,
    foodGroups: food.foodGroups || [],
    processingLevel: food.processingLevel || 'processed',
    isWholeGrain: !!food.isWholeGrain,
    isFruit: !!food.isFruit,
    isVegetable: !!food.isVegetable,
    isLegume: !!food.isLegume,
    isNut: !!food.isNut,
    isFish: !!food.isFish,
    isDairy: !!food.isDairy,
    isSweet: !!food.isSweet,
    isSugaryDrink: !!food.isSugaryDrink
  };
}

function deleteLoggedFoodById(id) {
  loggedFoods = loggedFoods.filter(item => item.id !== id);
  commitLoggedFoodsChange();
  showToast('Eintrag gelöscht', '✓');
}

function clearAllEntries() {
  if (loggedFoods.length === 0) {
    showToast('An diesem Tag sind keine Einträge vorhanden', 'ℹ️');
    return;
  }

  openAppDialog({
    mode: 'confirm',
    title: 'Tagebuch zurücksetzen?',
    message: 'Möchtest du wirklich alle Einträge dieses Tages löschen? Diese Aktion kann nicht rückgängig gemacht werden.',
    icon: '!',
    danger: true,
    confirmText: 'Alle löschen',
    onConfirm: () => {
      loggedFoods = [];
      commitLoggedFoodsChange();
      showToast('Alle Einträge gelöscht', '🧹');
      return true;
    }
  });
}

function quickAddWater() {
  const water = foodCatalog.find(food => food.id === WATER_FOOD_ID) || {
    id: WATER_FOOD_ID,
    name: 'Wasser',
    category: 'Getränke',
    unit: 'ml',
    icon: '💧',
    healthScore: 100,
    foodQuality: 100,
    waterContribution: 1.0,
    caloriesPer100: 0,
    proteinPer100: 0,
    carbsPer100: 0,
    fatPer100: 0,
    fiberPer100: 0,
    sugarPer100: 0,
    saturatedFatPer100: 0,
    saltPer100: 0,
    foodGroups: ['Water'],
    processingLevel: 'unprocessed'
  };

  loggedFoods.unshift(createLoggedEntry(water, QUICK_WATER_ML, 'Schnelleingabe'));
  commitLoggedFoodsChange();
  showToast(`${QUICK_WATER_ML} ml Wasser eingetragen!`);
}



/* ===========================================================================
   7. FAVORITEN
   =========================================================================== */

function isFavorite(foodId) {
  return loadFavorites().includes(foodId);
}

function toggleFavorite(foodId) {
  const food = foodCatalog.find(item => item.id === foodId);
  if (!food) return;

  let favorites = loadFavorites();

  if (favorites.includes(foodId)) {
    favorites = favorites.filter(id => id !== foodId);
    saveFavorites(favorites);
    showToast(`${food.name} aus Favoriten entfernt`, '☆');
  } else {
    if (favorites.length >= MAX_FAVORITES) {
      showToast(`Maximal ${MAX_FAVORITES} Favoriten möglich`, '⭐');
      return;
    }

    favorites.push(foodId);
    saveFavorites(favorites);
    showToast(`${food.name} zu Favoriten hinzugefügt`, '⭐');
  }

  updateFavoritesFilterButton();
  filterFoods();
}

function updateFavoritesFilterButton() {
  const button = document.getElementById('favorites-filter-btn');
  if (!button) return;

  const count = loadFavorites().length;
  button.textContent = `${favoritesOnly ? '★' : '☆'} Favoriten (${count}/${MAX_FAVORITES})`;
  button.className = `mt-2 px-3 py-1.5 rounded-xl text-[11px] font-bold btn-anim ${favoritesOnly ? 'bg-orange-500 text-white' : 'bg-slate-100 text-slate-500'}`;
}

function toggleFavoritesFilter() {
  favoritesOnly = !favoritesOnly;
  updateFavoritesFilterButton();
  filterFoods();
}



/* ===========================================================================
   8. KATALOG: FILTER, SORTIERUNG, SUCHE
   =========================================================================== */

function renderCategoryPills() {
  const container = document.getElementById('category-filter-pills');
  if (!container) return;

  container.innerHTML = [CATEGORY_ALL, ...FOOD_CATEGORIES].map(category => {
    const isActive = category === selectedCategoryFilter;

    return `
      <button type="button" onclick="filterCategory('${escapeHtml(category)}')" class="px-3 py-1.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap btn-anim ${isActive ? 'bg-orange-500 text-white shadow-sm' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}">
        ${escapeHtml(category)}
      </button>
    `;
  }).join('');
}

function filterCategory(category) {
  selectedCategoryFilter = category;
  renderCategoryPills();
  filterFoods();
}

function renderAttributePills() {
  const container = document.getElementById('attribute-filter-pills');
  if (!container) return;

  container.innerHTML = ATTRIBUTE_FILTERS.map(attribute => {
    const isActive = attribute.id === selectedAttributeFilter;

    return `
      <button type="button" onclick="filterAttribute('${attribute.id}')" class="px-2.5 py-1 rounded-lg text-[11px] font-bold transition-all whitespace-nowrap btn-anim ${isActive ? 'bg-orange-500 text-white shadow-sm' : 'bg-white text-slate-600 hover:bg-slate-200/70 border border-slate-200/80'}">
        ${attribute.label}
      </button>
    `;
  }).join('');
}

function filterAttribute(attributeId) {
  selectedAttributeFilter = attributeId;
  renderAttributePills();
  filterFoods();
}

function renderSortButtons() {
  const container = document.getElementById('sort-filter-buttons');
  if (!container) return;

  container.innerHTML = SORT_OPTIONS.map(option => {
    const isActive = option.id === selectedSortOption;

    return `
      <button type="button" onclick="setSortOption('${option.id}')" class="px-2 py-1 rounded-md text-[11px] font-semibold transition-all ${isActive ? 'bg-slate-800 text-white font-bold shadow-xs' : 'bg-white text-slate-600 hover:bg-slate-200 border border-slate-200'}">
        ${option.label}
      </button>
    `;
  }).join('');
}

function setSortOption(optionId) {
  selectedSortOption = optionId;
  renderSortButtons();
  filterFoods();
}

function setFiltersPanelOpen(isOpen) {
  filtersExpanded = isOpen;

  const panel = document.getElementById('filter-options-panel');
  const icon = document.getElementById('filter-toggle-icon');

  if (panel) panel.classList.toggle('is-open', isOpen);
  if (icon) icon.style.transform = isOpen ? 'rotate(180deg)' : 'rotate(0deg)';
}

function toggleFilters() {
  setFiltersPanelOpen(!filtersExpanded);
}

function resetAllSearchFilters() {
  selectedCategoryFilter = CATEGORY_ALL;
  selectedAttributeFilter = 'all';
  selectedSortOption = 'default';

  const searchInput = document.getElementById('food-search-input');
  if (searchInput) searchInput.value = '';

  renderCategoryPills();
  renderAttributePills();
  renderSortButtons();
  setFiltersPanelOpen(filtersExpanded);
  filterFoods();
}

function normalizeSearchText(text) {
  return String(text || '')
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/ß/g, 'ss');
}

function getSearchAliases(term) {
  // Object.hasOwn verhindert Treffer auf Object-Eigenschaften wie "constructor".
  return Object.hasOwn(SEARCH_ALIASES, term) ? SEARCH_ALIASES[term] : [];
}

function getFoodQuality(food) {
  return food.foodQuality || food.healthScore || 0;
}

function isVeggieFood(food) {
  const groups = Array.isArray(food.foodGroups) ? food.foodGroups : [];
  return !groups.some(group => NON_VEGGIE_FOOD_GROUPS.includes(group));
}

function filterFoods() {
  const searchInput = document.getElementById('food-search-input');
  const query = searchInput ? searchInput.value.trim() : '';
  const searchTerms = normalizeSearchText(query).split(/\s+/).filter(Boolean);
  const resetButton = document.getElementById('reset-filters-btn');

  const isFilterActive = selectedCategoryFilter !== CATEGORY_ALL
    || selectedAttributeFilter !== 'all'
    || selectedSortOption !== 'default'
    || query !== '';

  if (resetButton) resetButton.classList.toggle('hidden', !isFilterActive);

  let filtered = [...foodCatalog];

  if (selectedCategoryFilter !== CATEGORY_ALL) {
    filtered = filtered.filter(food => food.category === selectedCategoryFilter);
  }

  if (searchTerms.length > 0) {
    filtered = filtered.filter(food => {
      const searchable = normalizeSearchText([
        food.name, food.category, food.info, ...(food.searchTerms || [])
      ].join(' '));

      return searchTerms.every(term =>
        searchable.includes(term) || getSearchAliases(term).some(alias => searchable.includes(alias))
      );
    });
  }

  if (selectedAttributeFilter === 'veggie') {
    filtered = filtered.filter(isVeggieFood);
  } else if (selectedAttributeFilter === 'protein') {
    filtered = filtered.filter(food => food.proteinPer100 >= FILTER_THRESHOLDS.proteinPer100);
  } else if (selectedAttributeFilter === 'healthy') {
    filtered = filtered.filter(food => getFoodQuality(food) >= FILTER_THRESHOLDS.healthScore);
  } else if (selectedAttributeFilter === 'lowcal') {
    filtered = filtered.filter(food => (food.caloriesPer100 || 0) <= FILTER_THRESHOLDS.caloriesPer100);
  }

  if (selectedSortOption === 'name') {
    filtered.sort((a, b) => a.name.localeCompare(b.name, 'de'));
  } else if (selectedSortOption === 'score') {
    filtered.sort((a, b) => getFoodQuality(b) - getFoodQuality(a));
  } else if (selectedSortOption === 'calories') {
    filtered.sort((a, b) => (a.caloriesPer100 || 0) - (b.caloriesPer100 || 0));
  }

  renderFoodCatalog(filtered);
}

function renderFoodCatalog(filteredList = null) {
  const grid = document.getElementById('food-catalog-grid');
  const countLabel = document.getElementById('catalog-count-label');
  if (!grid) return;

  const favoriteIds = new Set(loadFavorites());

  let items = filteredList || foodCatalog;
  if (favoritesOnly) items = items.filter(food => favoriteIds.has(food.id));

  if (countLabel) countLabel.textContent = `${items.length} Verfügbare Lebensmittel`;

  if (items.length === 0) {
    grid.innerHTML = `
      <div class="text-center py-10 bg-white rounded-3xl border border-slate-100 p-6">
        <p class="text-2xl mb-2">🔍</p>
        <p class="text-sm font-bold text-slate-700">Kein Lebensmittel gefunden</p>
        <p class="text-xs text-slate-400 mt-1 mb-3">Versuche andere Filterkriterien oder erstelle einen eigenen Eintrag.</p>
        <button type="button" onclick="resetAllSearchFilters()" class="px-4 py-2 bg-orange-100 text-orange-600 text-xs font-bold rounded-xl btn-anim">
          Filter zurücksetzen
        </button>
      </div>
    `;
    return;
  }

  grid.innerHTML = items.map(food => {
    const favorite = favoriteIds.has(food.id);

    return `
      <div class="bg-gradient-to-r from-orange-500 to-amber-500 text-white p-3.5 rounded-2xl shadow-md flex items-center justify-between card-anim">
        <div class="flex items-center space-x-3 food-main">
          <div class="w-11 h-11 bg-white/20 backdrop-blur-md rounded-xl flex items-center justify-center text-2xl shadow-inner flex-shrink-0">
            ${escapeHtml(food.icon)}
          </div>
          <div class="food-main">
            <h3 class="font-bold text-white text-sm leading-tight food-name">${escapeHtml(food.name)}</h3>
            <p class="text-[11px] text-orange-100/90 font-medium">${escapeHtml(food.category)} • ca. ${escapeHtml(formatUnit(food.unit, food.defaultQty))}</p>
          </div>
        </div>
        <div class="flex items-center gap-1.5">
          <button type="button" onclick="event.stopPropagation(); toggleFavorite('${food.id}')" aria-label="Favorit umschalten" aria-pressed="${favorite}" class="favorite-star w-9 h-9 rounded-xl ${favorite ? 'bg-white text-orange-500 is-favorite' : 'bg-white/20 text-white'} font-bold text-lg flex items-center justify-center">${favorite ? '★' : '☆'}</button>
          <button type="button" onclick="openAddModal('${food.id}')" class="px-3.5 py-2 bg-white text-orange-600 font-bold text-xs rounded-xl shadow-sm btn-anim hover:bg-orange-50 flex items-center space-x-1">
            <span>+ Hinzufügen</span>
          </button>
        </div>
      </div>
    `;
  }).join('');
}



/* ===========================================================================
   9. MODALE: LEBENSMITTEL HINZUFÜGEN UND EIGENES LEBENSMITTEL
   =========================================================================== */

function openAddModal(foodId) {
  const food = foodCatalog.find(item => item.id === foodId);
  if (!food) return;

  selectedFoodForModal = food;
  currentModalQuantity = food.defaultQty;
  selectedFoodOptions = {};

  document.getElementById('modal-food-title').textContent = food.name;
  document.getElementById('modal-food-icon').textContent = food.icon;
  document.getElementById('modal-food-subtitle').textContent = food.category;
  document.getElementById('modal-quantity-val').textContent = currentModalQuantity;
  document.getElementById('modal-quantity-unit').textContent = food.unit;
  document.getElementById('modal-info-text').textContent = food.info || 'Standardportion für dein Ernährungstagebuch.';

  const quickContainer = document.getElementById('modal-quick-buttons');
  quickContainer.innerHTML = (food.quickOpts || []).map(quantity => `
    <button type="button" onclick="setModalQuantity(${Number(quantity)})" class="px-3 py-1 bg-white border border-slate-200 text-slate-700 rounded-xl text-xs font-bold btn-anim hover:bg-orange-50 hover:border-orange-200">
      ${Number(quantity)} ${escapeHtml(food.unit)}
    </button>
  `).join('');

  const optionsContainer = document.getElementById('modal-options-container');

  if (food.options && food.options.length > 0) {
    optionsContainer.classList.remove('hidden');
    optionsContainer.innerHTML = food.options.map(option => {
      selectedFoodOptions[option.key] = option.choices[0];

      return `
        <div>
          <label class="block text-[11px] font-bold uppercase tracking-wider text-orange-800 mb-1">${escapeHtml(option.name)}</label>
          <select onchange="updateOptionSelection('${option.key}', this.value)" class="w-full bg-white border border-orange-200 text-slate-800 text-xs font-semibold rounded-xl p-2.5 focus:outline-none focus:ring-2 focus:ring-orange-400">
            ${option.choices.map(choice => `<option value="${escapeHtml(choice)}">${escapeHtml(choice)}</option>`).join('')}
          </select>
        </div>
      `;
    }).join('');
  } else {
    optionsContainer.classList.add('hidden');
    optionsContainer.innerHTML = '';
  }

  document.getElementById('add-modal-backdrop').classList.remove('opacity-0', 'pointer-events-none');
  document.getElementById('add-modal-card').classList.remove('translate-y-10');
}

function updateOptionSelection(key, value) {
  selectedFoodOptions[key] = value;
}

function closeAddModal() {
  const backdrop = document.getElementById('add-modal-backdrop');
  const card = document.getElementById('add-modal-card');

  if (backdrop) backdrop.classList.add('opacity-0', 'pointer-events-none');
  if (card) card.classList.add('translate-y-10');

  selectedFoodForModal = null;
}

function adjustQuantity(delta) {
  if (!selectedFoodForModal) return;

  const step = selectedFoodForModal.step || 1;
  const rawValue = currentModalQuantity + delta * step;

  currentModalQuantity = Math.max(step, Math.round(rawValue * 100) / 100);
  document.getElementById('modal-quantity-val').textContent = currentModalQuantity;
}

function setModalQuantity(value) {
  currentModalQuantity = value;
  document.getElementById('modal-quantity-val').textContent = currentModalQuantity;
}

function confirmAddFood() {
  if (!selectedFoodForModal) return;

  // closeAddModal() setzt selectedFoodForModal zurück, daher vorher merken.
  const food = selectedFoodForModal;
  const details = Object.values(selectedFoodOptions).filter(Boolean).join(', ');

  loggedFoods.unshift(createLoggedEntry(food, currentModalQuantity, details));
  commitLoggedFoodsChange();
  closeAddModal();
  showToast(`${food.name} hinzugefügt!`);
}

function openCustomFoodModal() {
  document.getElementById('custom-modal-backdrop').classList.remove('opacity-0', 'pointer-events-none');
  document.getElementById('custom-modal-card').classList.remove('translate-y-10');
}

function closeCustomModal() {
  const backdrop = document.getElementById('custom-modal-backdrop');
  const card = document.getElementById('custom-modal-card');

  if (backdrop) backdrop.classList.add('opacity-0', 'pointer-events-none');
  if (card) card.classList.add('translate-y-10');
}

function showInfoDialog(title, message, icon) {
  openAppDialog({ mode: 'confirm', title, message, icon, confirmText: 'Verstanden', onConfirm: () => true });
}

function confirmCustomFood() {
  const defaults = CUSTOM_FOOD_DEFAULTS;
  const name = document.getElementById('custom-name-input').value.trim();
  const category = document.getElementById('custom-cat-select').value;
  const unit = document.getElementById('custom-unit-select').value;
  const quantity = readNumberInput('custom-qty-input', defaults.quantity);
  const calories = Math.max(0, readNumberInput('custom-kcal-input', defaults.calories));
  const sugar = Math.max(0, readNumberInput('custom-sugar-input', 0));
  const permanent = !!document.getElementById('custom-food-permanent')?.checked;

  if (!name) {
    showInfoDialog('Name fehlt', 'Bitte gib zuerst einen Namen für das Lebensmittel ein.', '✏️');
    return;
  }

  if (quantity <= 0) {
    showInfoDialog('Menge fehlt', 'Die Menge muss größer als 0 sein.', '✏️');
    return;
  }

  const isWeightUnit = unit === 'g' || unit === 'ml';
  const isCountUnit = defaults.countUnits.includes(unit);
  const caloriesPer100 = isWeightUnit ? Math.round((calories / Math.max(1, quantity)) * 100) : calories;

  // Nährwerte: dauerhafte Lebensmittel fragen sie im Formular ab, einmalige nutzen Standardwerte.
  const nutrients = permanent
    ? {
        protein: Math.max(0, readNumberInput('custom-protein-input', 0)),
        carbs: Math.max(0, readNumberInput('custom-carbs-input', 0)),
        fat: Math.max(0, readNumberInput('custom-fat-input', 0)),
        fiber: Math.max(0, readNumberInput('custom-fiber-input', 0))
      }
    : { ...defaults.nutrientsPer100 };

  const customFood = {
    id: permanent ? `custom_food_${Date.now()}` : `custom_${Date.now()}`,
    name,
    category,
    unit,
    defaultQty: quantity,
    step: isCountUnit ? 1 : 10,
    icon: defaults.icon,
    healthScore: defaults.healthScore,
    foodQuality: defaults.healthScore,
    waterContribution: unit === 'ml' ? defaults.waterContribution.liquid : defaults.waterContribution.solid,
    caloriesPer100,
    proteinPer100: nutrients.protein,
    carbsPer100: nutrients.carbs,
    fatPer100: nutrients.fat,
    fiberPer100: nutrients.fiber,
    sugarPer100: sugar,
    saturatedFatPer100: defaults.nutrientsPer100.saturatedFat,
    saltPer100: defaults.nutrientsPer100.salt,
    foodGroups: permanent ? [document.getElementById('custom-food-group').value] : [defaults.foodGroup],
    processingLevel: permanent ? document.getElementById('custom-food-processing').value : defaults.processingLevel
  };

  if (permanent) {
    foodCatalog.push({
      ...customFood,
      info: 'Eigenes, dauerhaft gespeichertes Lebensmittel.',
      quickOpts: isCountUnit ? defaults.quickOptionsCount : defaults.quickOptionsWeight,
      isCustomPersistent: true,
      searchTerms: [name, 'eigenes', 'benutzerdefiniert']
    });
    savePersistentCustomFoods();
  }

  const details = permanent ? 'Eigenes Lebensmittel · dauerhaft gespeichert' : 'Eigenes Lebensmittel';
  loggedFoods.unshift(createLoggedEntry(customFood, quantity, details));
  commitLoggedFoodsChange();

  closeCustomModal();
  document.getElementById('custom-name-input').value = '';

  const permanentBox = document.getElementById('custom-food-permanent');
  if (permanentBox) permanentBox.checked = false;

  const extra = document.getElementById('custom-food-extra');
  if (extra) {
    extra.classList.remove('open');
    extra.setAttribute('aria-hidden', 'true');
  }

  showToast(permanent ? `${name} dauerhaft gespeichert und eingetragen!` : `${name} eingetragen!`, '✓');
  filterFoods();
}



/* ===========================================================================
   10. STATISTIKEN
   =========================================================================== */

function setText(id, text) {
  const element = document.getElementById(id);
  if (element) element.textContent = text;
}

function updateBar(key, value, target, unit) {
  const valueElement = document.getElementById(`bar-val-${key}`);
  const fillElement = document.getElementById(`bar-fill-${key}`);
  if (!valueElement || !fillElement) return;

  valueElement.textContent = `${value} / ${target} ${unit}`;
  const percent = target > 0 ? Math.min(100, Math.round((value / target) * 100)) : 0;
  fillElement.style.width = `${percent}%`;
}

function renderFeedbackList(elementId, list) {
  const element = document.getElementById(elementId);
  if (!element) return;

  element.innerHTML = list.map(item => `<li>${escapeHtml(item)}</li>`).join('');
}

function updateHistoricalStatsDisplay() {
  const stats = getHistoricalScoreStats();
  const format = value => (value === null ? '--' : `${value}%`);

  setText('hist-today-score', format(stats.today));
  setText('hist-7d-score', format(stats.avgShort));
  setText('hist-30d-score', format(stats.avgLong));

  const bestWorst = document.getElementById('hist-best-worst');
  if (!bestWorst) return;

  if (stats.best && stats.worst) {
    bestWorst.textContent = `${stats.best.score}% / ${stats.worst.score}%`;
    bestWorst.title = `Bester Tag: ${formatDateLabel(stats.best.iso)} · Schlechtester Tag: ${formatDateLabel(stats.worst.iso)}`;
  } else {
    bestWorst.textContent = '-- / --';
    bestWorst.title = '';
  }
}

const SCORE_BREAKDOWN_ELEMENT_IDS = {
  quality: 'exp-q-str',
  nutrients: 'exp-n-str',
  variety: 'exp-v-str',
  hydration: 'exp-h-str',
  balance: 'exp-b-str'
};

function updateStatisticsOverview() {
  const statsCard = document.getElementById('stats-gauge-card');
  const emptyCard = document.getElementById('stats-empty-card');
  const statsDataContent = document.getElementById('stats-data-content');

  const targets = getPersonalizedTargets();
  const data = calculateDailyNutritionEngine(loggedFoods, targets);
  const hasData = Array.isArray(loggedFoods) && loggedFoods.length > 0;

  if (emptyCard) emptyCard.classList.toggle('hidden', hasData);
  if (statsDataContent) statsDataContent.classList.toggle('hidden', !hasData);

  const score = data.scores.finalScore;

  const arcPath = document.getElementById('gauge-arc-path');
  if (arcPath) arcPath.style.strokeDashoffset = getGaugeDashOffset(score);

  setText('gauge-score-value', `${score}%`);
  setText('gauge-score-label', data.ratingText);
  setText('gauge-rating-badge', data.ratingText);

  Object.keys(SCORE_CONFIG.weights).forEach(key => {
    setText(`sub-${key}-val`, `${data.scores[key]}%`);
  });

  getScoreBreakdown(data.scores).forEach(line => {
    setText(SCORE_BREAKDOWN_ELEMENT_IDS[line.key], line.text);
  });
  setText('exp-total-str', `${score}%`);

  updateBar('calories', Math.round(data.totalCalories), targets.calories, 'kcal');
  updateBar('protein', Math.round(data.totalProtein), targets.protein, 'g');
  updateBar('carbs', Math.round(data.totalCarbs), targets.carbs, 'g');
  updateBar('fat', Math.round(data.totalFat), targets.fat, 'g');
  updateBar('fiber', Math.round(data.totalFiber), targets.fiber, 'g');
  updateBar('sugar', Math.round(data.totalSugar), targets.sugarMax, 'g');
  updateBar('saturatedFat', Math.round(data.totalSaturatedFat), targets.saturatedFatMax, 'g');
  updateBar('salt', Number(data.totalSalt.toFixed(1)), targets.saltMax, 'g');

  const waterTarget = getTargetValue(targets, 'water');
  const hydrationPercent = Math.min(100, Math.round((data.effectiveWaterMl / waterTarget) * 100));
  setText('hydration-percent-badge', `${hydrationPercent}%`);
  setText('hydration-current-text', `${Math.round(data.effectiveWaterMl)} ml eff.`);

  const hydrationBar = document.getElementById('hydration-bar');
  if (hydrationBar) hydrationBar.style.width = `${hydrationPercent}%`;

  renderFeedbackList('analysis-good-list', data.goodList);
  renderFeedbackList('analysis-missing-list', data.missingList);
  renderFeedbackList('analysis-excess-list', data.excessList);

  updateHistoricalStatsDisplay();
}



/* ===========================================================================
   11. KURZÜBERSICHT
   =========================================================================== */

const OVERVIEW_MINI_BARS = [
  { key: 'quality',   label: 'Qualität', color: '#fbbf24' },
  { key: 'nutrients', label: 'Nährst.',  color: '#34d399' },
  { key: 'variety',   label: 'Vielfalt', color: '#60a5fa' },
  { key: 'hydration', label: 'Wasser',   color: '#22d3ee' },
  { key: 'balance',   label: 'Balance',  color: '#a78bfa' }
];

function showQuickOverviewModal() {
  const backdrop = document.getElementById('overview-modal-backdrop');
  if (!backdrop) return;

  const profileName = userProfile.name;
  const targets = getPersonalizedTargets();
  const hasEntries = Array.isArray(loggedFoods) && loggedFoods.length > 0;
  const data = calculateDailyNutritionEngine(loggedFoods, targets);
  const score = data.scores.finalScore;

  setText('overview-greeting', hasEntries
    ? `Hallo, ${profileName}! 👋`
    : `Hallo, ${profileName}! Noch nichts erfasst heute.`);
  setText('overview-score-value', `${score}%`);
  setText('overview-score-label', data.ratingText);

  const circle = document.getElementById('overview-gauge-circle');
  const stopOne = document.getElementById('overview-gauge-stop-1');
  const stopTwo = document.getElementById('overview-gauge-stop-2');
  const [colorOne, colorTwo] = getOverviewGaugeColors(score);

  if (stopOne) stopOne.setAttribute('stop-color', colorOne);
  if (stopTwo) stopTwo.setAttribute('stop-color', colorTwo);

  if (circle) {
    circle.style.strokeDashoffset = GAUGE_CIRCLE_LENGTH;
    requestAnimationFrame(() => {
      circle.style.strokeDashoffset = GAUGE_CIRCLE_LENGTH - GAUGE_CIRCLE_LENGTH * (score / 100);
    });
  }

  const insight = buildQuickOverviewInsight(data, targets, hasEntries);
  setText('overview-motivation-text', insight.text);
  setText('overview-motivation-icon', insight.icon);

  const miniBars = document.getElementById('overview-mini-bars');
  if (miniBars) {
    miniBars.innerHTML = OVERVIEW_MINI_BARS.map(({ key, label, color }) => `
      <div class="text-center">
        <div class="overview-mini-bar-track"><div class="overview-mini-bar-fill" style="width:${data.scores[key]}%;background:${color};"></div></div>
        <p class="text-[8px] font-bold text-white/60 mt-1">${label}</p>
      </div>
    `).join('');
  }

  backdrop.classList.remove('pointer-events-none');
  requestAnimationFrame(() => backdrop.classList.add('is-open'));
}

function closeQuickOverviewModal() {
  const backdrop = document.getElementById('overview-modal-backdrop');
  if (!backdrop) return;

  backdrop.classList.remove('is-open');
  setTimeout(() => backdrop.classList.add('pointer-events-none'), 320);
}



/* ===========================================================================
   12. EINSTELLUNGEN: MENÜ
   Neue Kategorien: Eintrag in SETTINGS_MENU_ITEMS ergänzen und einen Screen
   mit id="settings-screen-<id>" in index.html anlegen.
   =========================================================================== */

const SETTINGS_MENU_ITEMS = [
  {
    id: 'storage', icon: '💾', color: 'bg-blue-500', title: 'Speicher & Daten',
    subtitle: () => `${formatBytes(getLocalStorageUsageBytes())} belegt · ${appSettings.retentionDays === 0 ? 'unbegrenzt' : `${appSettings.retentionDays} Tage`}`
  },
  {
    id: 'health', icon: '❤️', color: 'bg-red-500', title: 'Gesundheit',
    subtitle: () => 'Tagesziele und Grenzwerte'
  },
  {
    id: 'display', icon: '🎨', color: 'bg-purple-500', title: 'Anzeigen',
    subtitle: () => `${QUICK_OVERVIEW_LABELS[appSettings.quickOverviewMode]} · Dark Mode: ${DARK_MODE_LABELS[appSettings.darkMode]}`
  },
  {
    id: 'ki', icon: '✨', color: 'bg-gradient-to-br from-blue-500 via-purple-500 to-orange-500', title: 'KI-Assistent',
    subtitle: () => (getGeminiApiKey() ? 'Gemini API-Key hinterlegt' : 'Kein API-Key hinterlegt')
  }
];

function renderSettingsRootMenu() {
  const wrap = document.getElementById('settings-root-menu');
  if (!wrap) return;

  wrap.innerHTML = SETTINGS_MENU_ITEMS.map(item => `
    <button type="button" onclick="openSettingsScreen('${item.id}')" class="settings-row-btn w-full flex items-center gap-3 p-4 text-left">
      <span class="w-9 h-9 rounded-xl ${item.color} text-white flex items-center justify-center text-base shrink-0 shadow-sm">${item.icon}</span>
      <span class="flex-1 min-w-0">
        <span class="block text-sm font-bold text-slate-800">${item.title}</span>
        <span class="block text-[11px] text-slate-400 truncate mt-0.5">${escapeHtml(item.subtitle())}</span>
      </span>
      <span class="text-slate-300 text-lg leading-none">›</span>
    </button>
  `).join('');
}

function scrollSettingsToTop() {
  const scroller = document.getElementById('settings-tab-scroll');
  if (scroller) scroller.scrollTo({ top: 0, behavior: 'smooth' });
}

function openSettingsScreen(id) {
  const target = document.getElementById(`settings-screen-${id}`);
  if (!target) return;

  document.querySelectorAll('.settings-screen').forEach(screen => {
    screen.classList.remove('active', 'settings-slide-fwd', 'settings-slide-back');
  });
  target.classList.add('active', 'settings-slide-fwd');

  if (id === 'storage') updateStorageUsageUI();
  if (id === 'health') renderHealthTargetsSettings();
  if (id === 'display') renderDisplaySettingsUI();
  if (id === 'ki') renderApiKeySettings();

  scrollSettingsToTop();
}

function backToSettingsRoot() {
  const root = document.getElementById('settings-screen-root');
  if (!root) return;

  document.querySelectorAll('.settings-screen').forEach(screen => {
    screen.classList.remove('active', 'settings-slide-fwd', 'settings-slide-back');
  });
  root.classList.add('active', 'settings-slide-back');

  renderSettingsRootMenu();
  scrollSettingsToTop();
}

function renderSettingsUI() {
  const retentionInput = document.getElementById('settings-retention-input');

  if (retentionInput) retentionInput.value = appSettings.retentionDays;

  renderHealthTargetsSettings();
  updateStorageUsageUI();
  renderSettingsRootMenu();
  renderDisplaySettingsUI();
  renderApiKeySettings();
}



/* ===========================================================================
   13. EINSTELLUNGEN: SPEICHER
   =========================================================================== */

function saveStorageSettingsFromUI() {
  const retention = Math.round(Number(document.getElementById('settings-retention-input')?.value) || 0);

  appSettings.retentionDays = Math.max(RETENTION_LIMITS.min, Math.min(RETENTION_LIMITS.max, retention));

  saveAppSettings();
  applyRetention();

  loadLoggedFoods();
  renderLoggedFoods();
  renderDatePicker();
  updateStatisticsOverview();
  renderSettingsUI();

  showToast('Speichereinstellungen übernommen', '✓');
}



/* ===========================================================================
   14. EINSTELLUNGEN: GESUNDHEITSZIELE
   =========================================================================== */

/* Die Felder zeigen die Ziele, die tatsächlich gelten (inkl. Aktivitäts-Anpassung). */
function renderHealthTargetsSettings() {
  const wrap = document.getElementById('settings-health-targets');
  const profile = userProfile;
  if (!wrap) return;

  const targets = getPersonalizedTargets(profile);

  wrap.innerHTML = HEALTH_TARGET_FIELDS.map(field => `
    <label class="block">
      <span class="text-[10px] font-bold text-slate-500">${field.label}</span>
      <div class="flex items-center gap-2 mt-1">
        <input data-health-key="${field.key}" type="number" min="${field.min}" max="${field.max}" step="${field.step}" value="${targets[field.key]}" class="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800">
        <span class="text-[9px] font-semibold text-slate-400 whitespace-nowrap">${field.unit}</span>
      </div>
    </label>
  `).join('');
}

/*
   Gespeichert werden nur Werte, die vom aktuell geltenden Ziel abweichen oder
   schon früher selbst gesetzt wurden. So bleibt die Aktivitäts-Anpassung
   erhalten, solange man ein Ziel nicht aktiv ändert.
*/
function saveHealthTargetsFromUI() {
  const profile = userProfile;

  ensureProfileHealthTargets(profile);
  const current = getPersonalizedTargets(profile);

  document.querySelectorAll('#settings-health-targets [data-health-key]').forEach(input => {
    const key = input.dataset.healthKey;
    const field = HEALTH_TARGET_FIELDS.find(item => item.key === key);
    if (!field || String(input.value).trim() === '') return;

    const parsed = Number(input.value);
    if (!Number.isFinite(parsed)) return;

    const value = Math.max(field.min, Math.min(field.max, parsed));
    const alreadyCustom = profile.healthTargets[key] !== undefined;

    if (alreadyCustom || value !== current[key]) profile.healthTargets[key] = value;
  });

  saveProfile();
  updateStatisticsOverview();
  renderHealthTargetsSettings();
  showToast('Gesundheitsziele gespeichert', '✓');
}

function resetHealthTargets() {
  userProfile.healthTargets = {};
  saveProfile();
  renderHealthTargetsSettings();
  updateStatisticsOverview();
  showToast('Gesundheitsziele zurückgesetzt', '↺');
}



/* ===========================================================================
   15. EINSTELLUNGEN: ANZEIGE UND KI-ASSISTENT
   =========================================================================== */

function renderOptionButtons(options, selectedValue, handlerName) {
  return options.map(option => `
    <button type="button" onclick="${handlerName}('${option.value}')" class="settings-segment-btn py-2.5 rounded-xl text-[11px] font-bold border ${selectedValue === option.value ? 'bg-slate-900 text-white border-slate-900' : 'bg-slate-50 text-slate-600 border-slate-200'}">${option.label}</button>
  `).join('');
}

function renderDisplaySettingsUI() {
  const quickWrap = document.getElementById('quick-overview-mode-options');
  if (quickWrap) quickWrap.innerHTML = renderOptionButtons(QUICK_OVERVIEW_OPTIONS, appSettings.quickOverviewMode, 'setQuickOverviewMode');

  const darkWrap = document.getElementById('dark-mode-options');
  if (darkWrap) darkWrap.innerHTML = renderOptionButtons(DARK_MODE_OPTIONS, appSettings.darkMode, 'setDarkModeOption');
}

function setQuickOverviewMode(value) {
  if (!QUICK_OVERVIEW_OPTIONS.some(option => option.value === value)) return;

  appSettings.quickOverviewMode = value;
  saveAppSettings();
  renderDisplaySettingsUI();
  renderSettingsRootMenu();
  showToast('Anzeige-Einstellung gespeichert', '✓');
}

function setDarkModeOption(value) {
  if (!DARK_MODE_OPTIONS.some(option => option.value === value)) return;

  appSettings.darkMode = value;
  saveAppSettings();
  applyDarkMode();
  renderDisplaySettingsUI();
  renderSettingsRootMenu();
  showToast('Dark Mode aktualisiert', '✓');
}

function renderApiKeySettings() {
  const input = document.getElementById('settings-gemini-key-input');
  const status = document.getElementById('settings-gemini-key-status');
  if (!input || !status) return;

  const key = getGeminiApiKey();
  input.value = key;

  if (key) {
    const masked = key.length > 6 ? `••••${key.slice(-4)}` : '••••';
    status.textContent = `✓ Gespeichert (${masked})`;
    status.className = 'text-[10px] font-semibold mt-1.5 text-emerald-600';
  } else {
    status.textContent = 'Kein API-Key hinterlegt';
    status.className = 'text-[10px] font-semibold mt-1.5 text-slate-400';
  }
}

function toggleGeminiKeyVisibility() {
  const input = document.getElementById('settings-gemini-key-input');
  const button = document.getElementById('settings-gemini-key-toggle-btn');
  if (!input) return;

  const isHidden = input.type === 'password';
  input.type = isHidden ? 'text' : 'password';
  if (button) button.textContent = isHidden ? '🙈' : '👁️';
}

function saveGeminiApiKeyFromUI() {
  const input = document.getElementById('settings-gemini-key-input');
  if (!input) return;

  const value = input.value.trim();
  if (!value) {
    showToast('Bitte gib zuerst einen API-Key ein', '⚠️');
    return;
  }

  if (!saveGeminiApiKey(value)) {
    showToast('Speichern fehlgeschlagen', '⚠️');
    return;
  }

  renderApiKeySettings();
  renderSettingsRootMenu();
  showToast('API-Key gespeichert', '✓');
}

function clearGeminiApiKeyFromUI() {
  if (!clearGeminiApiKey()) {
    showToast('Entfernen fehlgeschlagen', '⚠️');
    return;
  }

  renderApiKeySettings();
  renderSettingsRootMenu();
  showToast('API-Key entfernt', '✓');
}



/* ===========================================================================
   16. APP-START
   Reihenfolge wie im Original: Migration → Einstellungen → Dark Mode →
   Profil → Tagebuch → Rendering.
   =========================================================================== */

function initApp() {
  migrateLegacyData();
  loadAppSettings();
  applyDarkMode();
  loadProfile();
  loadLoggedFoods();

  initDateHeader();
  renderLoggedFoods();
  renderCategoryPills();
  renderAttributePills();
  renderSortButtons();
  renderFoodCatalog();
  updateFavoritesFilterButton();
  updateStatisticsOverview();
  renderSettingsUI();

  if (shouldShowQuickOverviewOnLoad()) {
    setTimeout(() => {
      showQuickOverviewModal();
      markQuickOverviewShownToday();
    }, QUICK_OVERVIEW_DELAY_MS);
  }

  // Zusatzfelder für dauerhafte eigene Lebensmittel ein- und ausblenden.
  const permanentBox = document.getElementById('custom-food-permanent');
  if (permanentBox) {
    permanentBox.addEventListener('change', function () {
      const extra = document.getElementById('custom-food-extra');
      if (!extra) return;

      extra.classList.toggle('open', this.checked);
      extra.setAttribute('aria-hidden', String(!this.checked));
    });
  }

  // Modus "System": Wechsel des Betriebssystems live übernehmen.
  const colorScheme = window.matchMedia?.('(prefers-color-scheme: dark)');
  if (colorScheme?.addEventListener) {
    colorScheme.addEventListener('change', () => {
      if (appSettings.darkMode === 'system') applyDarkMode();
    });
  }
}

document.addEventListener('DOMContentLoaded', initApp);
