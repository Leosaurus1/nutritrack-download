/* ===========================================================================
   NutriTrack – js/ai.js

   KI-Ernährungsberater (Google Gemini): Kontext für den System-Prompt,
   Anfrage mit Wiederholung und Fallback-Modell, Chat-Verlauf und Chat-Overlay.
   Wird als letztes Skript geladen (nach config.js, storage.js, engine.js und
   ui.js). Wie die übrigen Skripte ist dies bewusst kein ES-Modul, damit die
   Inline-Handler in index.html (sendMessage, startNewChat, ...) die
   Funktionen finden.

   Benutzt: GEMINI_* und CHAT_MAX_HISTORY_MESSAGES aus config.js,
   getGeminiApiKey() aus storage.js, Berechnung aus engine.js,
   escapeHtml() und formatUnit() aus ui.js.

   Der API-Key wird nie auf ein Format geprüft (Google wechselt von "AIza…"
   auf "AQ.…"). Gesendet wird er im Header, nicht in der URL.
   =========================================================================== */



/* ===========================================================================
   1. CHAT-ZUSTAND
   =========================================================================== */

// Gesprächsverlauf für die Gemini API (nur im Arbeitsspeicher).
// Form: [{ role: 'user' | 'model', parts: [{ text }] }]
let chatConversationHistory = [];
let chatRequestInFlight = false;

// ID des aktuell offenen Chats (null = neuer Chat, der noch nicht gespeichert wurde)
let currentChatId = null;

// Maximale Länge eines Chatnamens (automatischer Name und Umbenennen)
const CHAT_TITLE_MAX_LENGTH = 40;



/* ===========================================================================
   2. KONTEXT FÜR DEN BERATER
   =========================================================================== */

/*
   Mahlzeiten von HEUTE, unabhängig davon, welches Datum der Nutzer gerade im
   Tab "Ernährung" ansieht. Die Einträge werden normalisiert, damit auch ältere
   Einträge ohne Nährwertfelder korrekt gerechnet werden.
*/
function getTodaysLoggedFoodsForChat() {
  try {
    const store = getDateFoodStore();
    const entries = store.dates[getTodayISO()];
    return Array.isArray(entries) ? entries.map(normalizeLoggedFood) : [];
  } catch (error) {
    console.warn('Heutige Mahlzeiten konnten nicht geladen werden:', error);
    return [];
  }
}

function buildGeminiSystemPrompt() {
  const todaysFoods = getTodaysLoggedFoodsForChat();
  const targets = getPersonalizedTargets();
  const totals = calculateDailyNutritionEngine(todaysFoods, targets);
  const personalization = getProfilePersonalization(userProfile);

  const mealsText = todaysFoods.length > 0
    ? todaysFoods.map(food => {
        const grams = getItemGramWeight(food);
        const kcal = Math.round((food.caloriesPer100 || 0) * (grams / 100));
        return `- ${food.name}: ${formatUnit(food.unit, food.quantity)} (≈ ${kcal} kcal)`;
      }).join('\n')
    : 'Heute wurden noch keine Mahlzeiten oder Getränke erfasst.';

  return [
    'Du bist "NutriTrack Ernährungsberater", ein freundlicher, professioneller und empathischer KI-Ernährungsberater innerhalb der App NutriTrack.',
    'Antworte IMMER auf Deutsch, in einem warmen, unterstützenden und leicht verständlichen Ton, aber fachlich fundiert.',
    'Gib konkrete, alltagstaugliche Tipps basierend auf den unten stehenden Nutzerdaten, wenn danach gefragt wird oder es hilfreich ist.',
    'Du stellst keine medizinischen Diagnosen. Bei Hinweisen auf ernsthafte gesundheitliche Anliegen empfiehlst du, ärztlichen oder ernährungsmedizinischen Rat einzuholen.',
    'Halte deine Antworten prägnant (ca. 80–150 Wörter), außer eine ausführlichere Erklärung wird explizit gewünscht.',
    '',
    '## Profil des Nutzers',
    `- Altersgruppe: ${personalization.age.label}`,
    `- Aktivitätslevel: ${personalization.sport.label}`,
    `- Schlaf-/Erholungsqualität: ${personalization.sleep.label}`,
    '',
    '## Tagesziele des Nutzers',
    `- Kalorien: ${targets.calories} kcal`,
    `- Protein: ${targets.protein} g`,
    `- Kohlenhydrate: ${targets.carbs} g`,
    `- Fett: ${targets.fat} g`,
    `- Ballaststoffe: ${targets.fiber} g`,
    `- Zucker (max.): ${targets.sugarMax} g`,
    `- Gesättigte Fette (max.): ${targets.saturatedFatMax} g`,
    `- Salz (max.): ${targets.saltMax} g`,
    `- Wasser: ${targets.water} ml`,
    '',
    '## Heute bereits erfasste Mahlzeiten',
    mealsText,
    '',
    '## Bisherige Ist-Werte des heutigen Tages',
    `- Kalorien: ${Math.round(totals.totalCalories)} / ${targets.calories} kcal`,
    `- Protein: ${Math.round(totals.totalProtein)} / ${targets.protein} g`,
    `- Kohlenhydrate: ${Math.round(totals.totalCarbs)} / ${targets.carbs} g`,
    `- Fett: ${Math.round(totals.totalFat)} / ${targets.fat} g`,
    `- Ballaststoffe: ${Math.round(totals.totalFiber)} / ${targets.fiber} g`,
    `- Zucker: ${Math.round(totals.totalSugar)} / ${targets.sugarMax} g (max.)`,
    `- Wasser (effektiv): ${Math.round(totals.effectiveWaterMl)} / ${targets.water} ml`,
    `- Health-Score heute: ${totals.scores.finalScore}% (${totals.ratingText})`
  ].join('\n');
}



/* ===========================================================================
   3. ANFRAGE AN GEMINI
   Fehlertypen (err.type): NETWORK, TIMEOUT, OVERLOADED, RATE_LIMIT, AUTH,
   MODEL_UNAVAILABLE, BAD_REQUEST, BLOCKED, TRUNCATED, EMPTY, OTHER
   =========================================================================== */

function sleep(milliseconds) {
  return new Promise(resolve => setTimeout(resolve, milliseconds));
}

function geminiEndpointFor(model) {
  return `${GEMINI_API_BASE_URL}/${model}:generateContent`;
}

function createGeminiError(type, message, details = {}) {
  const error = new Error(message);
  error.type = type;
  Object.assign(error, details);
  return error;
}

function shortenErrorText(text) {
  const clean = String(text || '').replace(/\s+/g, ' ').trim();
  if (clean.length <= GEMINI_ERROR_TEXT_MAX_LENGTH) return clean;
  return `${clean.slice(0, GEMINI_ERROR_TEXT_MAX_LENGTH)}…`;
}

/* Die letzten Nachrichten des Verlaufs; die Anfrage beginnt immer mit einer Nutzer-Nachricht. */
function getHistoryForRequest() {
  const recent = chatConversationHistory.slice(-CHAT_MAX_HISTORY_MESSAGES);
  while (recent.length > 0 && recent[0].role !== 'user') recent.shift();
  return recent;
}

function buildGeminiRequestBody(historyPayload, systemPromptText, { withThinking = true } = {}) {
  const generationConfig = { ...GEMINI_GENERATION_CONFIG };
  if (!withThinking) delete generationConfig.thinkingConfig;

  return {
    contents: historyPayload,
    systemInstruction: { parts: [{ text: systemPromptText }] },
    generationConfig
  };
}

/* Texte, die bei einem Fehler im Chat stehen. Immer mit echtem Status und Google-Text. */
function buildAuthErrorMessage(status, apiStatus, apiMessage, apiKey) {
  const code = [`HTTP ${status}`, apiStatus].filter(Boolean).join(', ');
  let hint = 'Prüfe den Key unter Einstellungen → KI-Assistent: vollständig kopiert, ohne Leerzeichen, und die Gemini API im Google-Projekt aktiviert.';

  if (/ACCESS_TOKEN_TYPE_UNSUPPORTED/i.test(`${apiStatus} ${apiMessage}`)) {
    hint = 'Dieser Key-Typ wird von der Schnittstelle nicht akzeptiert. Erzeuge in Google AI Studio einen neuen API-Key.';
  } else if (apiKey.startsWith('AIza')) {
    hint += ' Hinweis: Google schaltet ältere Keys im Format "AIza…" schrittweise ab. Erzeuge im Zweifel in Google AI Studio einen neuen Key.';
  }

  const detail = apiMessage ? ` Details von Google: ${shortenErrorText(apiMessage)}` : '';
  return `Google hat den API-Key abgelehnt (${code}). ${hint}${detail}`;
}

/* EIN Request an EIN Modell. Wirft Fehler mit .type, damit der Aufrufer entscheiden kann. */
async function requestGeminiReply(apiKey, model, historyPayload, systemPromptText) {
  let withThinking = true;

  for (let attempt = 0; attempt < 2; attempt += 1) {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), GEMINI_REQUEST_TIMEOUT_MS);
    let response;

    try {
      response = await fetch(geminiEndpointFor(model), {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          [GEMINI_API_KEY_HEADER]: apiKey
        },
        body: JSON.stringify(buildGeminiRequestBody(historyPayload, systemPromptText, { withThinking })),
        signal: controller.signal
      });
    } catch (networkError) {
      if (networkError && networkError.name === 'AbortError') {
        throw createGeminiError(
          'TIMEOUT',
          `Zeitüberschreitung: ${model} hat nicht innerhalb von ${Math.round(GEMINI_REQUEST_TIMEOUT_MS / 1000)} Sekunden geantwortet.`,
          { model }
        );
      }
      throw createGeminiError('NETWORK', 'Netzwerkfehler', { model });
    } finally {
      clearTimeout(timeoutId);
    }

    if (!response.ok) {
      let apiMessage = '';
      let apiStatus = '';

      try {
        const errorData = await response.json();
        apiMessage = errorData?.error?.message || '';
        apiStatus = errorData?.error?.status || '';
      } catch (parseError) { /* Antwort war kein JSON */ }

      const status = response.status;
      const details = { model, status, apiStatus, apiMessage };

      // Falls die Thinking-Einstellung des Modells nicht passt, einmal ohne sie erneut versuchen.
      if (status === 400 && withThinking && /thinking/i.test(apiMessage) && GEMINI_GENERATION_CONFIG.thinkingConfig) {
        withThinking = false;
        continue;
      }

      if (status === 503 || apiStatus === 'UNAVAILABLE') {
        throw createGeminiError('OVERLOADED', `${model} ist aktuell überlastet.${apiMessage ? ` (${shortenErrorText(apiMessage)})` : ''}`, details);
      }

      if (status === 429) {
        throw createGeminiError('RATE_LIMIT', `Das Anfragelimit der Gemini API wurde erreicht (HTTP 429). Bitte versuche es in Kürze erneut.${apiMessage ? ` Details von Google: ${shortenErrorText(apiMessage)}` : ''}`, details);
      }

      if (status === 401 || status === 403 || (status === 400 && /api key/i.test(apiMessage))) {
        throw createGeminiError('AUTH', buildAuthErrorMessage(status, apiStatus, apiMessage, apiKey), details);
      }

      if (status === 404) {
        throw createGeminiError('MODEL_UNAVAILABLE', `Das Modell ${model} ist nicht erreichbar (HTTP 404).${apiMessage ? ` Details von Google: ${shortenErrorText(apiMessage)}` : ''}`, details);
      }

      if (status === 400) {
        throw createGeminiError('BAD_REQUEST', `Die Anfrage an ${model} wurde abgelehnt (HTTP 400${apiStatus ? `, ${apiStatus}` : ''}). Details von Google: ${shortenErrorText(apiMessage) || 'keine Angabe'}`, details);
      }

      throw createGeminiError('OTHER', `Die Gemini API hat mit HTTP ${status}${apiStatus ? ` (${apiStatus})` : ''} geantwortet.${apiMessage ? ` Details von Google: ${shortenErrorText(apiMessage)}` : ''}`, details);
    }

    const data = await response.json();
    const candidate = data?.candidates?.[0];
    const replyText = (candidate?.content?.parts || [])
      .filter(part => !part.thought)
      .map(part => part.text || '')
      .join('')
      .trim();

    if (replyText) return replyText;

    if (data?.promptFeedback?.blockReason || candidate?.finishReason === 'SAFETY') {
      throw createGeminiError('BLOCKED', 'Die Antwort wurde aus Sicherheitsgründen blockiert. Bitte formuliere deine Frage anders.', { model });
    }

    if (candidate?.finishReason === 'MAX_TOKENS') {
      throw createGeminiError('TRUNCATED', `Die Antwort von ${model} blieb leer, weil das Token-Limit erreicht wurde. Bitte stelle die Frage kürzer oder erhöhe GEMINI_GENERATION_CONFIG.maxOutputTokens in config.js.`, { model });
    }

    throw createGeminiError('EMPTY', `Es konnte keine Antwort von ${model} erzeugt werden${candidate?.finishReason ? ` (${candidate.finishReason})` : ''}.`, { model });
  }

  // Wird nur erreicht, wenn auch der Versuch ohne Thinking-Einstellung nicht beendet wurde.
  throw createGeminiError('OTHER', `Die Anfrage an ${model} ist fehlgeschlagen.`, { model });
}

/* Fehler, bei denen das Fallback-Modell sinnvoll ist (der Key oder die Anfrage sind in Ordnung). */
function isFallbackWorthy(error) {
  return ['OVERLOADED', 'TIMEOUT', 'MODEL_UNAVAILABLE', 'EMPTY', 'TRUNCATED'].includes(error.type);
}

/*
   Bevorzugtes Modell (bei Überlastung mit steigenden Wartezeiten), danach
   einmalig das Fallback-Modell. Schlägt auch das fehl, steht beides in der
   Fehlermeldung, damit die Ursache sichtbar bleibt.
*/
async function requestGeminiReplyWithFallback(apiKey, historyPayload, systemPromptText) {
  let primaryError = null;

  for (let attempt = 0; attempt <= GEMINI_RETRY_DELAYS_MS.length; attempt += 1) {
    try {
      return await requestGeminiReply(apiKey, GEMINI_MODEL_PRIMARY, historyPayload, systemPromptText);
    } catch (error) {
      if (!isFallbackWorthy(error)) throw error;

      primaryError = error;
      if (error.type !== 'OVERLOADED' || attempt === GEMINI_RETRY_DELAYS_MS.length) break;

      await sleep(GEMINI_RETRY_DELAYS_MS[attempt]);
    }
  }

  try {
    return await requestGeminiReply(apiKey, GEMINI_MODEL_FALLBACK, historyPayload, systemPromptText);
  } catch (fallbackError) {
    fallbackError.message = `${fallbackError.message} (Zuvor ${GEMINI_MODEL_PRIMARY}: ${primaryError.message})`;
    throw fallbackError;
  }
}



/* ===========================================================================
   4. CHAT-ANZEIGE
   =========================================================================== */

function scrollChatToBottom() {
  const messages = document.getElementById('chat-messages');
  if (messages) messages.scrollTop = messages.scrollHeight;
}

/* Startansicht (Titel + Vorschlags-Buttons) ein-/ausblenden. */
function setChatWelcomeVisible(visible) {
  const welcome = document.getElementById('chat-welcome');
  if (!welcome) return;

  // hidden-Attribut: damit der space-y-Abstand der Nachrichtenliste die ausgeblendete Startansicht ignoriert.
  welcome.hidden = !visible;
  welcome.style.display = visible ? '' : 'none';
}

function appendChatMessage(sender, text, isError = false) {
  const messages = document.getElementById('chat-messages');
  if (!messages) return;

  // Sobald es eine Nachricht gibt, verschwindet die Startansicht.
  setChatWelcomeVisible(false);

  const safeText = escapeHtml(text).replace(/\n/g, '<br>');
  const wrapper = document.createElement('div');
  wrapper.className = 'chat-bubble-in flex items-end' + (sender === 'user' ? ' justify-end' : '');

  if (sender === 'user') {
    wrapper.innerHTML = `
      <div class="ai-bubble-user text-white rounded-2xl rounded-br-md px-3.5 py-2.5 shadow-sm max-w-[80%]">
        <p class="text-xs leading-relaxed">${safeText}</p>
      </div>
    `;
  } else {
    const bubbleClasses = isError
      ? 'bg-red-50 border border-red-100 rounded-2xl rounded-bl-md px-3.5 py-2.5 shadow-sm max-w-[80%]'
      : 'ai-bubble-ai bg-white border border-slate-100 rounded-2xl rounded-bl-md px-3.5 py-2.5 max-w-[80%]';
    const textClasses = isError ? 'text-xs text-red-600 leading-relaxed' : 'text-xs text-slate-700 leading-relaxed';

    wrapper.innerHTML = `
      <div class="${bubbleClasses}">
        <p class="${textClasses}">${safeText}</p>
      </div>
    `;
  }

  messages.appendChild(wrapper);
  scrollChatToBottom();
}

function showChatTypingIndicator(show) {
  const indicator = document.getElementById('chat-typing-indicator');
  if (!indicator) return;

  indicator.classList.toggle('hidden', !show);
  if (show) scrollChatToBottom();
}

function setChatInputDisabled(disabled) {
  const input = document.getElementById('chat-input');
  const sendButton = document.getElementById('chat-send-btn');

  if (input) input.disabled = disabled;

  if (sendButton) {
    sendButton.disabled = disabled;
    sendButton.classList.toggle('opacity-50', disabled);
    sendButton.classList.toggle('pointer-events-none', disabled);
  }
}

function autoResizeChatInput(element) {
  const input = element || document.getElementById('chat-input');
  if (!input) return;

  input.style.height = 'auto';
  input.style.height = Math.min(input.scrollHeight, 112) + 'px'; // max-height 7rem = 112 px

  // Senden-Pfeil abschwächen, solange nichts eingegeben ist.
  const sendButton = document.getElementById('chat-send-btn');
  if (sendButton) sendButton.classList.toggle('is-empty', input.value.trim() === '');
}

function handleChatInputKeydown(event) {
  // Enter sendet, Shift+Enter fügt einen Zeilenumbruch ein.
  if (event.key === 'Enter' && !event.shiftKey) {
    event.preventDefault();
    sendMessage();
  }
}



/* ===========================================================================
   5. NACHRICHT SENDEN UND VERLAUF
   =========================================================================== */

/*
   presetText: optionaler Text (z. B. von den Vorschlags-Buttons der Startansicht).
   Ohne Argument wird der Inhalt des Eingabefelds gesendet.
*/
async function sendMessage(presetText) {
  const input = document.getElementById('chat-input');
  if (!input || chatRequestInFlight) return;

  const isPreset = typeof presetText === 'string';
  const text = (isPreset ? presetText : input.value).trim();
  if (!text) return;

  appendChatMessage('user', text);

  // Ein Vorschlags-Button lässt einen bereits getippten Entwurf unberührt.
  if (!isPreset) {
    input.value = '';
    autoResizeChatInput(input);
  }

  const apiKey = getGeminiApiKey();

  if (!apiKey) {
    appendChatMessage(
      'ai',
      'Es ist noch kein Gemini API-Key hinterlegt. Bitte trage ihn unter Einstellungen → KI-Assistent ein, damit ich dir antworten kann.',
      true
    );
    return;
  }

  chatConversationHistory.push({ role: 'user', parts: [{ text }] });

  chatRequestInFlight = true;
  setChatInputDisabled(true);
  showChatTypingIndicator(true);

  try {
    const replyText = await requestGeminiReplyWithFallback(apiKey, getHistoryForRequest(), buildGeminiSystemPrompt());

    chatConversationHistory.push({ role: 'model', parts: [{ text: replyText }] });
    appendChatMessage('ai', replyText);
    persistCurrentChat();
  } catch (error) {
    console.error('Gemini API Fehler:', error);

    const isNetworkError = error.type === 'NETWORK' || error instanceof TypeError;
    const message = isNetworkError
      ? 'Netzwerkfehler: Die Verbindung zur Gemini API konnte nicht hergestellt werden. Bitte prüfe deine Internetverbindung.'
      : (error.message || 'Unbekannter Fehler bei der Verbindung zur KI.');

    appendChatMessage('ai', message, true);

    // Die fehlgeschlagene Nachricht aus dem Verlauf nehmen, damit der nächste Versuch sauber startet.
    const last = chatConversationHistory[chatConversationHistory.length - 1];
    if (last && last.role === 'user') chatConversationHistory.pop();
  } finally {
    showChatTypingIndicator(false);
    setChatInputDisabled(false);
    chatRequestInFlight = false;
    input.focus();
  }
}

/* Startet einen neuen, leeren Chat. Der bisherige Chat bleibt im Verlauf gespeichert. */
function startNewChat() {
  if (chatRequestInFlight) return;

  closeChatDrawer();

  chatConversationHistory = [];
  currentChatId = null;
  renderChatMessages([]);
}



/* ===========================================================================
   5b. CHAT-VERLAUF UND SEITENLEISTE
   Gespeichert werden (storage.js) höchstens CHAT_MAX_SAVED_CHATS Chats.
   =========================================================================== */

/* Speichert den aktuellen Chat an erster Stelle der Liste (ältere Chats rücken nach hinten). */
function persistCurrentChat() {
  if (!chatConversationHistory.length) return;

  if (!currentChatId) {
    currentChatId = 'chat_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
  }

  const existingChats = loadSavedChats();
  const existingChat = existingChats.find(chat => chat.id === currentChatId);
  const chats = existingChats.filter(chat => chat.id !== currentChatId);

  chats.unshift({
    id: currentChatId,
    updatedAt: Date.now(),
    // Der Name entsteht einmalig aus dem 1. Prompt; ein umbenannter Name bleibt erhalten.
    title: existingChat?.title || deriveChatTitle(chatConversationHistory),
    messages: chatConversationHistory.map(message => ({ role: message.role, parts: [{ text: message.parts[0].text }] }))
  });

  saveSavedChats(chats);
}

/* Zeichnet die Nachrichten neu (leere Liste = Startansicht anzeigen). */
function renderChatMessages(history) {
  const messages = document.getElementById('chat-messages');
  if (!messages) return;

  // Alle Nachrichten entfernen, nur die Startansicht bleibt im Dokument.
  Array.from(messages.children).forEach(child => {
    if (child.id !== 'chat-welcome') child.remove();
  });

  if (!history.length) {
    setChatWelcomeVisible(true);
    return;
  }

  history.forEach(message => {
    appendChatMessage(message.role === 'user' ? 'user' : 'ai', message.parts[0].text);
  });
}

/* Öffnet einen gespeicherten Chat aus der Seitenleiste. */
function openSavedChat(chatId) {
  if (chatRequestInFlight) return;

  const chat = loadSavedChats().find(item => item.id === chatId);
  if (!chat) {
    closeChatDrawer();
    return;
  }

  currentChatId = chat.id;
  chatConversationHistory = chat.messages.map(message => ({ role: message.role, parts: [{ text: message.parts[0].text }] }));
  renderChatMessages(chatConversationHistory);
  closeChatDrawer();
}

/* Name aus dem Anfang des 1. Prompts (ein Zeilenumbruch wird zu einem Leerzeichen). */
function deriveChatTitle(messages) {
  const firstUserMessage = (messages || []).find(message => message.role === 'user');
  const text = String(firstUserMessage?.parts?.[0]?.text || '').replace(/\s+/g, ' ').trim();
  if (!text) return '';

  return text.length <= CHAT_TITLE_MAX_LENGTH
    ? text
    : `${text.slice(0, CHAT_TITLE_MAX_LENGTH - 1).trimEnd()}…`;
}

/* Gespeicherter (ggf. umbenannter) Name; ältere Chats ohne Namen bekommen ihn aus dem 1. Prompt. */
function getChatDisplayName(chat, position) {
  return chat.title || deriveChatTitle(chat.messages) || `${CHAT_PLACEHOLDER_NAME} ${position}`;
}

/* Benennt einen Chat über den App-Dialog (kein Browser-Eingabefeld) um. */
function renameSavedChat(chatId) {
  const chats = loadSavedChats();
  const position = chats.findIndex(item => item.id === chatId);
  if (position === -1) return;

  openAppDialog({
    mode: 'input',
    title: 'Chat umbenennen',
    message: 'Wähle einen Namen für diesen Chat.',
    inputLabel: 'Name',
    inputValue: getChatDisplayName(chats[position], position + 1),
    inputMaxLength: CHAT_TITLE_MAX_LENGTH,
    confirmText: 'Speichern',
    onConfirm: value => {
      const name = String(value || '').replace(/\s+/g, ' ').trim();
      if (!name) return { error: 'Der Name darf nicht leer sein.' };

      // Frisch laden: Der Chat könnte sich seit dem Öffnen des Dialogs geändert haben.
      const freshChats = loadSavedChats();
      const target = freshChats.find(item => item.id === chatId);
      if (!target) return true;

      target.title = name.slice(0, CHAT_TITLE_MAX_LENGTH);
      saveSavedChats(freshChats);
      renderChatHistoryList();
      return true;
    }
  });
}

function formatChatTimestamp(timestamp) {
  const date = new Date(timestamp);
  if (Number.isNaN(date.getTime())) return '';

  return date.toLocaleString('de-AT', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' });
}

function renderChatHistoryList() {
  const list = document.getElementById('chat-history-list');
  if (!list) return;

  const chats = loadSavedChats();

  if (!chats.length) {
    list.innerHTML = '<p class="chat-history-empty">Noch keine Chats gespeichert.</p>';
    return;
  }

  list.innerHTML = chats.map((chat, index) => {
    const name = getChatDisplayName(chat, index + 1);

    return `
      <div class="chat-history-item${chat.id === currentChatId ? ' is-active' : ''}">
        <button type="button" class="chat-history-open btn-anim" data-chat-id="${escapeHtml(chat.id)}" onclick="openSavedChat(this.dataset.chatId)">
          <span class="chat-history-item-title">${escapeHtml(name)}</span>
          <span class="chat-history-item-meta">${escapeHtml(formatChatTimestamp(chat.updatedAt))}</span>
        </button>
        <button type="button" class="chat-history-edit btn-anim" data-chat-id="${escapeHtml(chat.id)}" onclick="renameSavedChat(this.dataset.chatId)" aria-label="Chat umbenennen: ${escapeHtml(name)}" title="Umbenennen">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
            <path d="M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z"/>
            <path d="m15 5 4 4"/>
          </svg>
        </button>
      </div>
    `;
  }).join('');
}

function openChatDrawer() {
  const drawer = document.getElementById('chat-drawer');
  if (!drawer) return;

  const input = document.getElementById('chat-input');
  if (input) input.blur();

  renderChatHistoryList();
  drawer.classList.add('is-open');
  drawer.setAttribute('aria-hidden', 'false');

  const menuButton = document.getElementById('chat-menu-btn');
  if (menuButton) menuButton.setAttribute('aria-expanded', 'true');
}

function closeChatDrawer() {
  const drawer = document.getElementById('chat-drawer');
  if (!drawer) return;

  drawer.classList.remove('is-open');
  drawer.setAttribute('aria-hidden', 'true');

  const menuButton = document.getElementById('chat-menu-btn');
  if (menuButton) menuButton.setAttribute('aria-expanded', 'false');
}

/* ===========================================================================
   6. START
   =========================================================================== */

function initChat() {
  // Das Modell-Label steht nur in config.js; hier wird es in die Badges eingetragen.
  document.querySelectorAll('.ai-cta-badge, .ai-model-chip').forEach(element => {
    element.textContent = GEMINI_MODEL_LABEL;
  });

  // Neutraler Platzhalter: Der Key wird nicht auf ein Format geprüft.
  const keyInput = document.getElementById('settings-gemini-key-input');
  if (keyInput) keyInput.placeholder = 'Gemini API-Key einfügen';

  // Escape schließt die Seitenleiste mit dem Chat-Verlauf (nicht, solange ein App-Dialog offen ist).
  document.addEventListener('keydown', event => {
    if (event.key !== 'Escape') return;

    const dialog = document.getElementById('app-dialog-backdrop');
    if (dialog && dialog.classList.contains('is-open')) return;

    closeChatDrawer();
  });
}

document.addEventListener('DOMContentLoaded', initChat);
