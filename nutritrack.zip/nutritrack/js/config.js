/* ==========================================================================
   NutriTrack – js/config.js

   Reine Konfiguration: Konstanten, Standardwerte, Auswahllisten, Score-
   Parameter, Gemini-Einstellungen und der Lebensmittelkatalog.

   Regeln für diese Datei:
   - Wird als ERSTE Datei geladen und darf von keiner anderen Datei abhängen.
   - Kein DOM-Zugriff, kein localStorage, keine Aufrufe von Funktionen aus
     anderen Dateien. Veränderlicher Zustand (let) gehört NICHT hierher.
   - Normale Skripte (kein import/export): Alles hier Definierte ist in den
     folgenden Dateien global verfügbar.

   Inhalt:
    1. Hilfsfunktion deepFreeze
    2. localStorage-Schlüssel
    3. Grenzen & Standardwerte (Profil, Speicher, Kalender)
    4. Gesundheitsziele & Personalisierung
    5. Einstellungs-Optionen
    6. Tabs
    7. Einheiten
    8. Katalog-Filter, Sortierung, Suche
    9. Lebensmittelkatalog + Prüfung
   10. Score-Engine
   11. Kurzübersicht & Tacho
   12. KI-Berater (Gemini)
   ========================================================================== */



/* ==========================================================================
   1. HILFSFUNKTION
   ========================================================================== */

// Friert ein Objekt samt Unterobjekten ein, damit Konfigurationswerte nicht
// versehentlich zur Laufzeit verändert werden. (Kopien per { ...OBJ } bleiben
// normal veränderbar.)
function deepFreeze(obj) {
  Object.values(obj).forEach(value => {
    if (value && typeof value === 'object' && !Object.isFrozen(value)) deepFreeze(value);
  });
  return Object.freeze(obj);
}



/* ==========================================================================
   2. LOCALSTORAGE-SCHLÜSSEL
   ========================================================================== */

// Alle NutriTrack-Schlüssel beginnen damit ("Alle Daten löschen" entfernt sie anhand des Präfixes)
const STORAGE_KEY_PREFIX = 'nutritrack_';

// Das einzige Profil ("Du"): Altersgruppe, Bewegung, Erholung und eigene Gesundheitsziele
const PROFILE_STORAGE_KEY = 'nutritrack_profile';

// Frühere Schlüssel aus der Zeit mit mehreren Profilen (nur zum Übernehmen und Aufräumen)
const LEGACY_PROFILES_STORAGE_KEY = 'nutritrack_profiles';
const LEGACY_ACTIVE_PROFILE_STORAGE_KEY = 'nutritrack_active_profile';
const SETTINGS_STORAGE_KEY = 'nutritrack_app_settings';
const CUSTOM_FOODS_STORAGE_KEY = 'nutritrack_custom_foods';
const GEMINI_API_KEY_STORAGE_KEY = 'nutritrack_gemini_api_key';
const QUICK_OVERVIEW_LAST_SHOWN_KEY = 'nutritrack_quick_overview_last_shown';

// Schlüssel mit DEFAULT_PROFILE_ID als Endung: PREFIX + DEFAULT_PROFILE_ID
// (so bleiben die bisherigen Daten des Profils "Du" erhalten)
const FOODS_STORAGE_PREFIX = 'nutritrack_logged_foods__';
const FAVORITES_STORAGE_PREFIX = 'nutritrack_favorites__';
const CHAT_HISTORY_STORAGE_PREFIX = 'nutritrack_chat_history__';

// Alter Schlüssel aus der Zeit vor den Profilen (nur für die Migration)
const LEGACY_FOODS_KEY = 'nutritrack_logged_foods';



/* ==========================================================================
   3. GRENZEN & STANDARDWERTE
   ========================================================================== */

const DEFAULT_PROFILE_ID = 'profile_default';
const DEFAULT_PROFILE_NAME = 'Du';

// Startwerte des Profils
const DEFAULT_PROFILE_ATTRIBUTES = deepFreeze({
  ageGroup: '18-29',
  sportiness: 3,
  sleepQuality: 3
});

// Aufbewahrungsdauer der Tagebuch-Einträge in Tagen (0 = unbegrenzt)
const RETENTION_LIMITS = deepFreeze({ min: 0, max: 90, default: 0 });

const MAX_FAVORITES = 25;

// Richtwert für den Browser-Speicher (nur für die Anzeige in den Einstellungen)
const STORAGE_BUDGET_BYTES = 5 * 1024 * 1024;

// Mindestens so viele Tage (inkl. heute) bleiben im Kalender wählbar, wenn der Speicherzeitraum
// unbegrenzt ist. Mit Speicherzeitraum gilt dieser; ältere Einträge erweitern den Bereich.
const DATE_PICKER_DAYS = 30;

// Zeiträume (in Tagen, inkl. heute) für den Historischen Verlauf in den Statistiken
const HISTORY_SHORT_DAYS = 7;
const HISTORY_LONG_DAYS = 30;

// Schnelleingabe "Wasser"
const WATER_FOOD_ID = 'wasser';
const QUICK_WATER_ML = 250;



/* ==========================================================================
   4. GESUNDHEITSZIELE & PERSONALISIERUNG
   ========================================================================== */

// Tagesziele ohne Personalisierung (Einheit: kcal bzw. g, Wasser in ml).
// Die Werte mit "Max" sind Obergrenzen, alle anderen Zielwerte.
const DEFAULT_HEALTH_TARGETS = deepFreeze({
  calories: 2000,
  protein: 80,
  carbs: 250,
  fat: 70,
  fiber: 30,
  sugarMax: 50,
  saturatedFatMax: 20,
  saltMax: 6,
  water: 2500
});

// Eingabefelder in Einstellungen → Gesundheit
const HEALTH_TARGET_FIELDS = deepFreeze([
  { key: 'calories',        label: 'Kalorienziel',             unit: 'kcal/Tag', min: 0, max: 10000, step: 50 },
  { key: 'protein',         label: 'Protein-Ziel',             unit: 'g/Tag',    min: 0, max: 1000,  step: 1 },
  { key: 'carbs',           label: 'Kohlenhydrat-Ziel',        unit: 'g/Tag',    min: 0, max: 1500,  step: 1 },
  { key: 'fat',             label: 'Fett-Ziel',                unit: 'g/Tag',    min: 0, max: 500,   step: 1 },
  { key: 'fiber',           label: 'Ballaststoff-Ziel',        unit: 'g/Tag',    min: 0, max: 200,   step: 1 },
  { key: 'sugarMax',        label: 'Zucker maximal',           unit: 'g/Tag',    min: 0, max: 500,   step: 1 },
  { key: 'saturatedFatMax', label: 'Gesättigte Fette maximal', unit: 'g/Tag',    min: 0, max: 200,   step: 1 },
  { key: 'saltMax',         label: 'Salz maximal',             unit: 'g/Tag',    min: 0, max: 100,   step: 0.1 },
  { key: 'water',           label: 'Wasserziel',               unit: 'ml/Tag',   min: 0, max: 10000, step: 50 }
]);

// Aktivitätsstufe, bei der die Standardziele unverändert gelten
const NEUTRAL_ACTIVITY_LEVEL = 3;

// Anpassung der Ziele pro Aktivitätsstufe über/unter NEUTRAL_ACTIVITY_LEVEL,
// z. B. calories: 0.05 → +5 % je Stufe darüber, −5 % je Stufe darunter.
// (Zucker-, Fett- und Salzgrenzen werden nicht angepasst.)
const ACTIVITY_TARGET_SCALING = deepFreeze({
  calories: 0.05,
  protein: 0.06,
  carbs: 0.05,
  fat: 0.04,
  fiber: 0.03,
  water: 0.06
});

// Alters-, Aktivitäts- und Schlaf-Faktor wirken zusammen leicht auf den Score.
// Das Produkt der drei Faktoren wird auf diesen Bereich begrenzt.
const PERSONALIZATION_MULTIPLIER_RANGE = deepFreeze({ min: 0.96, max: 1.04 });

const AGE_GROUPS = deepFreeze([
  { id: '8-11',  label: '8–11 Jahre',  factor: 0.92 },
  { id: '12-14', label: '12–14 Jahre', factor: 0.95 },
  { id: '15-17', label: '15–17 Jahre', factor: 0.98 },
  { id: '18-29', label: '18–29 Jahre', factor: 1.00 },
  { id: '30-44', label: '30–44 Jahre', factor: 1.00 },
  { id: '45-59', label: '45–59 Jahre', factor: 0.98 },
  { id: '60-74', label: '60–74 Jahre', factor: 0.96 },
  { id: '75+',   label: '75+ Jahre',   factor: 0.94 }
]);

const SPORTINESS_LEVELS = deepFreeze([
  { value: 1, label: '1 – sehr wenig aktiv',      factor: 0.94, desc: 'Fast keine geplante Bewegung' },
  { value: 2, label: '2 – wenig aktiv',           factor: 0.97, desc: 'Gelegentliche Bewegung, etwa 1–2× pro Woche' },
  { value: 3, label: '3 – durchschnittlich aktiv', factor: 1.00, desc: 'Regelmäßige Bewegung, etwa 3× pro Woche' },
  { value: 4, label: '4 – sehr aktiv',            factor: 1.03, desc: 'Häufiges Training oder viel Bewegung im Alltag' },
  { value: 5, label: '5 – extrem aktiv',          factor: 1.06, desc: 'Sehr häufiges/intensives Training oder körperlich aktiver Alltag' }
]);

const SLEEP_LEVELS = deepFreeze([
  { value: 1, label: '1 – sehr schlechte Erholung',    factor: 0.95, desc: 'Sehr unregelmäßiger oder deutlich zu kurzer Schlaf' },
  { value: 2, label: '2 – eher schlechte Erholung',    factor: 0.97, desc: 'Häufig unruhiger oder zu kurzer Schlaf' },
  { value: 3, label: '3 – durchschnittliche Erholung', factor: 1.00, desc: 'Meist ausreichender und halbwegs regelmäßiger Schlaf' },
  { value: 4, label: '4 – gute Erholung',              factor: 1.02, desc: 'Überwiegend erholsamer und regelmäßiger Schlaf' },
  { value: 5, label: '5 – sehr gute Erholung',         factor: 1.04, desc: 'Sehr regelmäßiger und erholsamer Schlaf' }
]);



/* ==========================================================================
   5. EINSTELLUNGS-OPTIONEN
   ========================================================================== */

const QUICK_OVERVIEW_OPTIONS = deepFreeze([
  { value: 'onOpen',       label: 'Beim Öffnen' },
  { value: 'never',        label: 'Nie' },
  { value: 'personalized', label: 'Personalisiert' }
]);

const DARK_MODE_OPTIONS = deepFreeze([
  { value: 'on',     label: 'An' },
  { value: 'off',    label: 'Aus' },
  { value: 'system', label: 'System' }
]);

// Wert → Beschriftung, automatisch aus den Optionen abgeleitet
const QUICK_OVERVIEW_LABELS = deepFreeze(Object.fromEntries(QUICK_OVERVIEW_OPTIONS.map(o => [o.value, o.label])));
const DARK_MODE_LABELS = deepFreeze(Object.fromEntries(DARK_MODE_OPTIONS.map(o => [o.value, o.label])));

// Startwerte der App-Einstellungen. Zum Verändern immer kopieren: { ...DEFAULT_APP_SETTINGS }
const DEFAULT_APP_SETTINGS = deepFreeze({
  retentionDays: RETENTION_LIMITS.default,
  quickOverviewMode: 'onOpen',
  darkMode: 'system'
});



/* ==========================================================================
   6. TABS
   ========================================================================== */

const TAB_COUNT = 4;              // Slider-Tabs: Ernährung, Hinzufügen, Statistiken, Einstellungen
const STATS_TAB_INDEX = 2;
const SETTINGS_TAB_INDEX = 3;
const CHAT_TAB_INDEX = 4;         // Ernährungsberater: Overlay, kein Slider-Tab, kein Nav-Button

// Wartezeit, bevor das Chat-Eingabefeld Fokus bekommt (passend zur Overlay-Animation in styles.css)
const CHAT_FOCUS_DELAY_MS = 350;



/* ==========================================================================
   7. EINHEITEN
   ========================================================================== */

// Umrechnung in Gramm (für ml gilt vereinfacht 1 ml = 1 g)
const UNIT_GRAMS = deepFreeze({
  g: 1,
  ml: 1,
  'Stück': 100,
  Portion: 250,
  Teller: 300,
  Tasse: 200,
  Glas: 250
});

// Für unbekannte Einheiten (z. B. eigene Lebensmittel)
const DEFAULT_UNIT_GRAMS = 100;

// Mehrzahl bei Mengen ungleich 1
const UNIT_PLURALS = deepFreeze({
  Tasse: 'Tassen',
  Glas: 'Gläser',
  Teller: 'Teller',
  Portion: 'Portionen',
  'Stück': 'Stück'
});



/* ==========================================================================
   8. KATALOG-FILTER, SORTIERUNG, SUCHE
   ========================================================================== */

const CATEGORY_ALL = 'Alle';

// Reihenfolge = Reihenfolge der Filter-Pillen und der Auswahl bei "Eigenes Lebensmittel"
const FOOD_CATEGORIES = deepFreeze([
  'Getränke',
  'Brot & Frühstück',
  'Hauptspeisen',
  'Nudeln & Beilagen',
  'Milchprodukte & Eiweiß',
  'Obst & Gemüse',
  'Snacks & Süßes'
]);

// Schwellenwerte der Attribut-Filter (alle Werte pro 100 g / 100 ml bzw. in Punkten)
const FILTER_THRESHOLDS = deepFreeze({
  proteinPer100: 10,     // "Eiweißreich": mindestens
  healthScore: 80,       // "Score": mindestens
  caloriesPer100: 100    // "Kalorienarm": höchstens
});

const ATTRIBUTE_FILTERS = deepFreeze([
  { id: 'all',     label: 'Alle' },
  { id: 'veggie',  label: '🌱 Veggie / Pflanzen' },
  { id: 'protein', label: '💪 Eiweißreich' },
  { id: 'healthy', label: `🥗 Score ≥ ${FILTER_THRESHOLDS.healthScore}%` },
  { id: 'lowcal',  label: '🔥 Kalorienarm' }
]);

// "Veggie": alle Lebensmittel OHNE eine dieser Lebensmittelgruppen
const NON_VEGGIE_FOOD_GROUPS = deepFreeze(['Meat', 'Fish']);

const SORT_OPTIONS = deepFreeze([
  { id: 'default',  label: 'Standard' },
  { id: 'name',     label: '🔤 A-Z' },
  { id: 'score',    label: '⭐ Score' },
  { id: 'calories', label: '🔥 kcal' }
]);

// Suchbegriff → zusätzliche Treffer-Begriffe (ohne Umlaute, kleingeschrieben,
// wie nach normalizeSearchText())
const SEARCH_ALIASES = deepFreeze({
  kaffee:   ['kaffee', 'cafe', 'espresso', 'americano', 'verlangerter', 'melange', 'cappuccino', 'latte', 'macchiato', 'lattemacchiato', 'maccialatte', 'matchalatte'],
  latte:    ['latte', 'lattemacchiato', 'cappuccino', 'melange', 'macchiato'],
  espresso: ['espresso', 'kaffee', 'cappuccino', 'melange', 'latte', 'macchiato'],
  tee:      ['tee', 'matcha', 'matchalatte'],
  cola:     ['cola', 'softdrink', 'limonade'],
  wasser:   ['wasser', 'mineralwasser', 'hydration', 'getraenk'],
  brot:     ['brot', 'semmel', 'weckerl', 'kornspitz', 'stangerl', 'brezel', 'kipferl', 'croissant'],
  nudeln:   ['nudeln', 'pasta', 'spaghetti', 'penne', 'gnocchi'],
  fleisch:  ['fleisch', 'schnitzel', 'braten', 'hendl', 'hahnchen', 'rind', 'schwein', 'wurst'],
  suess:    ['suess', 'kuchen', 'torte', 'schokolade', 'krapfen', 'dessert']
});



/* ==========================================================================
   9. LEBENSMITTELKATALOG
   Werte pro 100 g bzw. 100 ml. Eigene Lebensmittel (isCustomPersistent) werden
   erst beim App-Start aus dem localStorage angehängt (siehe storage.js) –
   dieses Array ist daher bewusst NICHT eingefroren.

   Pflichtfelder siehe FOOD_REQUIRED_FIELDS. Optionale Felder: options,
   isDairy, isSugaryDrink, isFruit, isSweet, isWholeGrain, isNut, isVegetable,
   isFish, isLegume, searchTerms.
   ========================================================================== */

// Startwerte für "Eigenes Lebensmittel" (Eingabefelder, die leer bleiben, und nicht abgefragte Nährwerte)
const CUSTOM_FOOD_DEFAULTS = deepFreeze({
  quantity: 100,
  calories: 150,
  healthScore: 70,
  icon: '✏️',
  waterContribution: { liquid: 0.9, solid: 0.3 },
  nutrientsPer100: { protein: 5, carbs: 20, fat: 5, fiber: 1.5, saturatedFat: 1.5, salt: 0.5 },
  processingLevel: 'processed',
  foodGroup: 'Custom',
  countUnits: ['Stück', 'Portion', 'Tasse'],   // Einheiten mit Schritt 1 statt 10
  quickOptionsCount: [1, 2],
  quickOptionsWeight: [50, 100, 150]
});

const FOOD_REQUIRED_FIELDS = deepFreeze([
  'id', 'name', 'category', 'unit', 'defaultQty', 'step', 'icon',
  'healthScore', 'caloriesPer100', 'proteinPer100', 'carbsPer100', 'fatPer100',
  'fiberPer100', 'sugarPer100', 'saturatedFatPer100', 'saltPer100',
  'foodQuality', 'waterContribution', 'foodGroups', 'processingLevel', 'info', 'quickOpts'
]);

const foodCatalog = [

  // 1. GETRÄNKE (22)
  { id: 'wasser', name: 'Wasser', category: 'Getränke', unit: 'ml', defaultQty: 250, step: 50, icon: '💧', healthScore: 100, caloriesPer100: 0, proteinPer100: 0, carbsPer100: 0, fatPer100: 0, fiberPer100: 0, sugarPer100: 0, saturatedFatPer100: 0, saltPer100: 0, foodQuality: 100, waterContribution: 1.0, foodGroups: ['Water'], processingLevel: 'unprocessed', info: 'Reines Quell- oder Leitungswasser.', quickOpts: [100, 250, 500], options: [{ name: 'Kohlensäure', key: 'sparkling', choices: ['Still (Ohne)', 'Prickelnd / Mild'] }] },
  { id: 'mineralwasser', name: 'Mineralwasser Prickelnd', category: 'Getränke', unit: 'ml', defaultQty: 250, step: 50, icon: '🫧', healthScore: 100, caloriesPer100: 0, proteinPer100: 0, carbsPer100: 0, fatPer100: 0, fiberPer100: 0, sugarPer100: 0, saturatedFatPer100: 0, saltPer100: 0.01, foodQuality: 100, waterContribution: 1.0, foodGroups: ['Water'], processingLevel: 'unprocessed', info: 'Erfrischendes Mineralwasser mit Mineralstoffen.', quickOpts: [200, 250, 500] },
  { id: 'milch', name: 'Milch (Kuhmilch / Vollmilch)', category: 'Getränke', unit: 'ml', defaultQty: 250, step: 50, icon: '🥛', healthScore: 82, caloriesPer100: 64, proteinPer100: 3.4, carbsPer100: 4.7, fatPer100: 3.5, fiberPer100: 0, sugarPer100: 4.7, saturatedFatPer100: 2.3, saltPer100: 0.1, foodQuality: 82, waterContribution: 0.8, foodGroups: ['Dairy'], processingLevel: 'minimally_processed', isDairy: true, info: 'Österreichische Frische- oder Haltbarmilch.', quickOpts: [150, 250, 500], options: [{ name: 'Sorte / Fettgehalt', key: 'fat', choices: ['Vollmilch (3,5% Fett)', 'Leichtmilch (1,5% Fett)', 'Magermilch (0,5% Fett)', 'Laktosefreie Milch'] }, { name: 'Verwendung', key: 'prep', choices: ['Pur gekühlt', 'Erwärmt / Heiß', 'Mit Kakao', 'Im Kaffee'] }] },
  { id: 'almdudler', name: 'Almdudler / Kräuterlimo', category: 'Getränke', unit: 'ml', defaultQty: 330, step: 50, icon: '🌿', healthScore: 40, caloriesPer100: 33, proteinPer100: 0, carbsPer100: 7.9, fatPer100: 0, fiberPer100: 0, sugarPer100: 7.9, saturatedFatPer100: 0, saltPer100: 0.01, foodQuality: 40, waterContribution: 0.6, foodGroups: ['Sweets'], processingLevel: 'ultra_processed', isSugaryDrink: true, info: 'Österreichische Kräuterlimonade.', quickOpts: [250, 330, 500], options: [{ name: 'Zuckergehalt', key: 'sugar', choices: ['Klassisch (Mit Zucker)', 'Zuckerfrei / Light', 'Gespritzt mit Wasser (50/50)'] }] },
  { id: 'saft', name: 'Fruchtsaft / Gespritzter Saft', category: 'Getränke', unit: 'ml', defaultQty: 250, step: 50, icon: '🧃', healthScore: 65, caloriesPer100: 42, proteinPer100: 0.5, carbsPer100: 10, fatPer100: 0.1, fiberPer100: 0.2, sugarPer100: 9.5, saturatedFatPer100: 0, saltPer100: 0.01, foodQuality: 65, waterContribution: 0.7, foodGroups: ['Fruit'], processingLevel: 'processed', isFruit: true, info: 'Apfelsaft, Johannisbeersaft oder Orangensaft.', quickOpts: [150, 250, 500], options: [{ name: 'Zubereitung', key: 'variant', choices: ['Gespritzt mit Wasser (Schorle)', '100% PUR Direktsaft', 'Fruchtsaftgetränk'] }] },
  { id: 'orangensaft_frisch', name: 'Orangensaft, frisch gepresst', category: 'Getränke', unit: 'ml', defaultQty: 250, step: 50, icon: '🍊', healthScore: 88, caloriesPer100: 45, proteinPer100: 0.7, carbsPer100: 10.4, fatPer100: 0.2, fiberPer100: 0.2, sugarPer100: 8.4, saturatedFatPer100: 0, saltPer100: 0.01, foodQuality: 88, waterContribution: 0.88, foodGroups: ['Fruit'], processingLevel: 'minimally_processed', isFruit: true, info: 'Frisch gepresster Orangensaft.', quickOpts: [150, 250, 400] },
  { id: 'orangensaft_nicht_frisch', name: 'Orangensaft, nicht frisch gepresst', category: 'Getränke', unit: 'ml', defaultQty: 250, step: 50, icon: '🧃', healthScore: 76, caloriesPer100: 45, proteinPer100: 0.6, carbsPer100: 10.2, fatPer100: 0.1, fiberPer100: 0.1, sugarPer100: 8.8, saturatedFatPer100: 0, saltPer100: 0.01, foodQuality: 76, waterContribution: 0.82, foodGroups: ['Fruit'], processingLevel: 'processed', isFruit: true, info: 'Orangensaft aus dem Handel, z. B. Direktsaft oder aus Konzentrat.', quickOpts: [150, 250, 500] },
  { id: 'softdrink', name: 'Softdrink / Cola', category: 'Getränke', unit: 'ml', defaultQty: 330, step: 50, icon: '🥤', healthScore: 30, caloriesPer100: 42, proteinPer100: 0, carbsPer100: 10.6, fatPer100: 0, fiberPer100: 0, sugarPer100: 10.6, saturatedFatPer100: 0, saltPer100: 0.01, foodQuality: 30, waterContribution: 0.6, foodGroups: ['Sweets'], processingLevel: 'ultra_processed', isSugaryDrink: true, isSweet: true, info: 'Erfrischungsgetränk oder Limonade.', quickOpts: [250, 330, 500], options: [{ name: 'Zuckergehalt', key: 'sugar', choices: ['Mit Zucker (Original)', 'Zero / Light (Zuckerfrei)'] }] },
  { id: 'eistee', name: 'Eistee', category: 'Getränke', unit: 'ml', defaultQty: 300, step: 50, icon: '🧋', healthScore: 40, caloriesPer100: 30, proteinPer100: 0, carbsPer100: 7.2, fatPer100: 0, fiberPer100: 0, sugarPer100: 7.2, saturatedFatPer100: 0, saltPer100: 0.02, foodQuality: 40, waterContribution: 0.6, foodGroups: ['Sweets'], processingLevel: 'ultra_processed', isSugaryDrink: true, isSweet: true, info: 'Kühles Teegetränk Pfirsich oder Zitrone.', quickOpts: [200, 300, 500], options: [{ name: 'Zuckergehalt', key: 'sugar', choices: ['Klassisch Gesüßt', 'Zero / Zuckerfrei'] }] },
  { id: 'kaffee', name: 'Verlängerter / Kaffee', category: 'Getränke', unit: 'Tasse', defaultQty: 1, step: 1, icon: '☕', healthScore: 75, caloriesPer100: 2, proteinPer100: 0.1, carbsPer100: 0.3, fatPer100: 0, fiberPer100: 0, sugarPer100: 0, saturatedFatPer100: 0, saltPer100: 0, foodQuality: 75, waterContribution: 0.9, foodGroups: ['Beverage'], processingLevel: 'minimally_processed', info: 'Österreichischer Verlängerter oder Filterkaffee.', quickOpts: [1, 2, 3], options: [{ name: 'Milchzusatz', key: 'milk', choices: ['Schwarz (Ohne Milch)', 'Mit Vollmilch', 'Mit Haferdrink', 'Mit Mandeldrink', 'Mit Leichtmilch'] }, { name: 'Süße', key: 'sugar', choices: ['Kein Zucker', '1 TL Zucker', '2 TL Zucker', 'Süßstoff'] }] },
  { id: 'cappuccino', name: 'Melange / Cappuccino', category: 'Getränke', unit: 'Tasse', defaultQty: 1, step: 1, icon: '☕', healthScore: 70, caloriesPer100: 45, proteinPer100: 2.1, carbsPer100: 3.2, fatPer100: 2.2, fiberPer100: 0, sugarPer100: 3.1, saturatedFatPer100: 1.4, saltPer100: 0.08, foodQuality: 70, waterContribution: 0.85, foodGroups: ['Dairy'], processingLevel: 'minimally_processed', isDairy: true, info: 'Wiener Melange mit Milchschaum.', quickOpts: [1, 2, 3], options: [{ name: 'Milchsorte', key: 'milk', choices: ['Vollmilch', 'Haferdrink', 'Leichtmilch', 'Mandeldrink'] }, { name: 'Zucker', key: 'sugar', choices: ['Ohne Zucker', '1 TL Zucker', 'Mit Sirup (Vanille/Karamell)'] }] },
  { id: 'lattemacchiato', name: 'Latte Macchiato', category: 'Getränke', unit: 'Glas', defaultQty: 1, step: 1, icon: '🥛', healthScore: 68, caloriesPer100: 55, proteinPer100: 2.8, carbsPer100: 4.1, fatPer100: 2.8, fiberPer100: 0, sugarPer100: 4.0, saturatedFatPer100: 1.8, saltPer100: 0.09, foodQuality: 68, waterContribution: 0.8, foodGroups: ['Dairy'], processingLevel: 'minimally_processed', isDairy: true, info: 'Viel Milchschaum mit Espresso.', quickOpts: [1, 2], options: [{ name: 'Milchsorte', key: 'milk', choices: ['Vollmilch', 'Haferdrink', 'Sojadrink', 'Mandeldrink'] }, { name: 'Süße', key: 'sugar', choices: ['Ohne Zucker', '1 TL Zucker', 'Aromasirup'] }] },
  { id: 'matchalatte', name: 'Matcha Latte', category: 'Getränke', unit: 'Tasse', defaultQty: 1, step: 1, icon: '🍵', healthScore: 85, caloriesPer100: 40, proteinPer100: 2.0, carbsPer100: 3.5, fatPer100: 1.8, fiberPer100: 0.5, sugarPer100: 3.2, saturatedFatPer100: 1.1, saltPer100: 0.05, foodQuality: 85, waterContribution: 0.9, foodGroups: ['Beverage'], processingLevel: 'minimally_processed', info: 'Grüner Matcha-Tee mit Milchschaum.', quickOpts: [1, 2] },
  { id: 'tee', name: 'Tee (Kräuter / Grün)', category: 'Getränke', unit: 'Tasse', defaultQty: 1, step: 1, icon: '🫖', healthScore: 95, caloriesPer100: 1, proteinPer100: 0, carbsPer100: 0.2, fatPer100: 0, fiberPer100: 0, sugarPer100: 0, saturatedFatPer100: 0, saltPer100: 0, foodQuality: 95, waterContribution: 1.0, foodGroups: ['Water'], processingLevel: 'unprocessed', info: 'Kamille, Pfefferminze, Grün- oder Früchtetee.', quickOpts: [1, 2, 3], options: [{ name: 'Süßung', key: 'sugar', choices: ['Ungesüßt', 'Mit Honig', '1 TL Zucker', 'Zitrone'] }] },
  { id: 'kakao', name: 'Heiße Schokolade mit Obers', category: 'Getränke', unit: 'Tasse', defaultQty: 1, step: 1, icon: '☕', healthScore: 50, caloriesPer100: 90, proteinPer100: 3.2, carbsPer100: 10.5, fatPer100: 3.8, fiberPer100: 0.8, sugarPer100: 9.8, saturatedFatPer100: 2.4, saltPer100: 0.12, foodQuality: 50, waterContribution: 0.75, foodGroups: ['Sweets'], processingLevel: 'processed', isSweet: true, info: 'Cremiger Kakao mit optionalem Schlagobers.', quickOpts: [1, 2], options: [{ name: 'Haube', key: 'topping', choices: ['Mit Schlagobers', 'Ohne Schlagobers'] }] },
  { id: 'smoothie', name: 'Smoothie', category: 'Getränke', unit: 'ml', defaultQty: 250, step: 50, icon: '🥤', healthScore: 82, caloriesPer100: 55, proteinPer100: 0.8, carbsPer100: 12.0, fatPer100: 0.2, fiberPer100: 1.5, sugarPer100: 10.2, saturatedFatPer100: 0, saltPer100: 0.01, foodQuality: 82, waterContribution: 0.75, foodGroups: ['Fruit'], processingLevel: 'processed', isFruit: true, info: 'Pürierte Früchte oder grünes Gemüse.', quickOpts: [150, 250, 400] },
  { id: 'bier', name: 'Bier / Märzen', category: 'Getränke', unit: 'ml', defaultQty: 500, step: 100, icon: '🍺', healthScore: 30, caloriesPer100: 43, proteinPer100: 0.5, carbsPer100: 3.5, fatPer100: 0, fiberPer100: 0, sugarPer100: 0.1, saturatedFatPer100: 0, saltPer100: 0.01, foodQuality: 30, waterContribution: 0.6, foodGroups: ['Alcohol'], processingLevel: 'processed', info: 'Österreichisches Märzen oder Vollbier.', quickOpts: [330, 500], options: [{ name: 'Variante', key: 'variant', choices: ['Märzen / Vollbier', 'Alkoholfrei', 'Radler (Naturtrüb)'] }] },
  { id: 'radler', name: 'Radler (Zitrone / Kräuter)', category: 'Getränke', unit: 'ml', defaultQty: 500, step: 100, icon: '🍺', healthScore: 35, caloriesPer100: 38, proteinPer100: 0.3, carbsPer100: 5.5, fatPer100: 0, fiberPer100: 0, sugarPer100: 3.8, saturatedFatPer100: 0, saltPer100: 0.01, foodQuality: 35, waterContribution: 0.6, foodGroups: ['Alcohol'], processingLevel: 'ultra_processed', info: 'Bier gemischt mit Kräuter- oder Zitronenlimo.', quickOpts: [330, 500] },
  { id: 'wein', name: 'Gespritzter / G\'spritzter', category: 'Getränke', unit: 'ml', defaultQty: 250, step: 50, icon: '🍷', healthScore: 40, caloriesPer100: 35, proteinPer100: 0.1, carbsPer100: 1.2, fatPer100: 0, fiberPer100: 0, sugarPer100: 0.5, saturatedFatPer100: 0, saltPer100: 0.01, foodQuality: 40, waterContribution: 0.6, foodGroups: ['Alcohol'], processingLevel: 'processed', info: 'Grüner Veltliner oder Weißer G\'spritzter.', quickOpts: [125, 250, 500], options: [{ name: 'Sorte', key: 'type', choices: ['Weißer G\'spritzter (50/50)', 'Grüner Veltliner (Pur)', 'Zweigelt (Rotwein)', 'Sauer G\'spritzter'] }] },
  { id: 'sturm', name: 'Sturm / Most', category: 'Getränke', unit: 'ml', defaultQty: 250, step: 50, icon: '🍇', healthScore: 45, caloriesPer100: 60, proteinPer100: 0.2, carbsPer100: 6.8, fatPer100: 0, fiberPer100: 0, sugarPer100: 5.5, saturatedFatPer100: 0, saltPer100: 0.01, foodQuality: 45, waterContribution: 0.6, foodGroups: ['Alcohol'], processingLevel: 'processed', info: 'Österreichischer Traubensturm oder Fruchtmost.', quickOpts: [125, 250, 500] },
  { id: 'proteinshake', name: 'Eiweiß-Shake / Protein-Drink', category: 'Getränke', unit: 'ml', defaultQty: 300, step: 50, icon: '🥤', healthScore: 88, caloriesPer100: 75, proteinPer100: 11.5, carbsPer100: 2.8, fatPer100: 1.2, fiberPer100: 0.5, sugarPer100: 1.5, saturatedFatPer100: 0.6, saltPer100: 0.15, foodQuality: 88, waterContribution: 0.8, foodGroups: ['Protein'], processingLevel: 'processed', info: 'Whey- oder Pflanzliches Protein.', quickOpts: [200, 300, 400], options: [{ name: 'Flüssigkeit', key: 'base', choices: ['Mit Wasser', 'Mit Milch (3.5%)', 'Mit Haferdrink'] }] },
  { id: 'kokoswasser', name: 'Kokoswasser', category: 'Getränke', unit: 'ml', defaultQty: 250, step: 50, icon: '🥥', healthScore: 85, caloriesPer100: 19, proteinPer100: 0.7, carbsPer100: 3.7, fatPer100: 0.2, fiberPer100: 1.1, sugarPer100: 2.6, saturatedFatPer100: 0.1, saltPer100: 0.05, foodQuality: 85, waterContribution: 0.95, foodGroups: ['Water'], processingLevel: 'minimally_processed', info: 'Isotonisches natürliches Kokoswasser.', quickOpts: [200, 250, 500] },

  // 2. BROT, GEBÄCK & FRÜHSTÜCK (18)
  { id: 'schwarzbrot', name: 'Bauernbrot / Roggenbrot', category: 'Brot & Frühstück', unit: 'g', defaultQty: 50, step: 25, icon: '🍞', healthScore: 90, caloriesPer100: 220, proteinPer100: 6.8, carbsPer100: 43.0, fatPer100: 1.2, fiberPer100: 6.5, sugarPer100: 1.5, saturatedFatPer100: 0.2, saltPer100: 1.2, foodQuality: 90, waterContribution: 0.3, foodGroups: ['WholeGrain'], processingLevel: 'minimally_processed', isWholeGrain: true, info: 'Herzhaftes österreichisches Roggenbrot.', quickOpts: [25, 50, 100], options: [{ name: 'Aufstrich & Belag', key: 'spread', choices: ['Ohne Aufstrich', 'Mit Teebutter', 'Mit Liptauer', 'Mit Frischkäse', 'Mit Marillenmarmelade', 'Mit Käse / Schinken'] }] },
  { id: 'semmel', name: 'Kaisersemmel / Handsemmel', category: 'Brot & Frühstück', unit: 'Stück', defaultQty: 1, step: 1, icon: '🥖', healthScore: 65, caloriesPer100: 270, proteinPer100: 8.5, carbsPer100: 53.0, fatPer100: 1.5, fiberPer100: 2.8, sugarPer100: 2.0, saturatedFatPer100: 0.3, saltPer100: 1.3, foodQuality: 65, waterContribution: 0.2, foodGroups: ['Grains'], processingLevel: 'processed', info: 'Frische krosse Wiener Kaisersemmel.', quickOpts: [1, 2, 3], options: [{ name: 'Bestrichen mit', key: 'spread', choices: ['Ohne Aufstrich', 'Mit Butter', 'Mit Liptauer', 'Mit Frischkäse', 'Mit Extrawurst'] }] },
  { id: 'weckerl', name: 'Kornspitz / Kornweckerl', category: 'Brot & Frühstück', unit: 'Stück', defaultQty: 1, step: 1, icon: '🥖', healthScore: 85, caloriesPer100: 260, proteinPer100: 9.5, carbsPer100: 45.0, fatPer100: 3.8, fiberPer100: 5.8, sugarPer100: 2.2, saturatedFatPer100: 0.6, saltPer100: 1.2, foodQuality: 85, waterContribution: 0.25, foodGroups: ['WholeGrain', 'Nuts'], processingLevel: 'minimally_processed', isWholeGrain: true, info: 'Ballaststoffreiches Gebäck mit Saaten.', quickOpts: [1, 2], options: [{ name: 'Belag', key: 'topping', choices: ['Natur (Pur)', 'Mit Butter & Käse', 'Mit Schinken & Gurkerl', 'Mit Topfen'] }] },
  { id: 'salzstangerl', name: 'Salzstangerl / Wachauer', category: 'Brot & Frühstück', unit: 'Stück', defaultQty: 1, step: 1, icon: '🥖', healthScore: 68, caloriesPer100: 265, proteinPer100: 8.2, carbsPer100: 52.0, fatPer100: 1.8, fiberPer100: 3.0, sugarPer100: 1.8, saturatedFatPer100: 0.4, saltPer100: 2.1, foodQuality: 68, waterContribution: 0.2, foodGroups: ['Grains'], processingLevel: 'processed', info: 'Würziges Gebäck mit Kümmel & Salz.', quickOpts: [1, 2] },
  { id: 'vinschgerl', name: 'Vinschgerl / Schüttelbrot', category: 'Brot & Frühstück', unit: 'Stück', defaultQty: 1, step: 1, icon: '🥐', healthScore: 82, caloriesPer100: 240, proteinPer100: 8.0, carbsPer100: 47.0, fatPer100: 1.6, fiberPer100: 5.2, sugarPer100: 1.6, saturatedFatPer100: 0.3, saltPer100: 1.4, foodQuality: 82, waterContribution: 0.25, foodGroups: ['WholeGrain'], processingLevel: 'minimally_processed', isWholeGrain: true, info: 'Südtiroler/Österreichisches Fladenbrot.', quickOpts: [1, 2] },
  { id: 'brezel', name: 'Laugenbrezel / Laugenstange', category: 'Brot & Frühstück', unit: 'Stück', defaultQty: 1, step: 1, icon: '🥨', healthScore: 60, caloriesPer100: 280, proteinPer100: 9.0, carbsPer100: 54.0, fatPer100: 2.2, fiberPer100: 3.2, sugarPer100: 2.1, saturatedFatPer100: 0.5, saltPer100: 2.5, foodQuality: 60, waterContribution: 0.2, foodGroups: ['Grains'], processingLevel: 'processed', info: 'Frisches Laugengebäck.', quickOpts: [1, 2], options: [{ name: 'Variante', key: 'type', choices: ['Natur (Ohne Butter)', 'Butterbrezel', 'Laugenstange mit Käse'] }] },
  { id: 'croissant', name: 'Croissant / Kipferl', category: 'Brot & Frühstück', unit: 'Stück', defaultQty: 1, step: 1, icon: '🥐', healthScore: 40, caloriesPer100: 406, proteinPer100: 8.2, carbsPer100: 45.0, fatPer100: 21.0, fiberPer100: 2.6, sugarPer100: 11.0, saturatedFatPer100: 12.0, saltPer100: 1.0, foodQuality: 40, waterContribution: 0.15, foodGroups: ['Sweets'], processingLevel: 'ultra_processed', isSweet: true, info: 'Butterzartes Gebäck oder Nusskipferl.', quickOpts: [1, 2] },
  { id: 'topfengolatsche', name: 'Topfengolatsche', category: 'Brot & Frühstück', unit: 'Stück', defaultQty: 1, step: 1, icon: '🥮', healthScore: 45, caloriesPer100: 310, proteinPer100: 7.5, carbsPer100: 38.0, fatPer100: 14.0, fiberPer100: 1.8, sugarPer100: 15.0, saturatedFatPer100: 7.8, saltPer100: 0.6, foodQuality: 45, waterContribution: 0.2, foodGroups: ['Sweets', 'Dairy'], processingLevel: 'ultra_processed', isSweet: true, isDairy: true, info: 'Plundergebäck gefüllt mit süßem Topfen.', quickOpts: [1, 2] },
  { id: 'nussschnecke', name: 'Nussschnecke / Zimtschnecke', category: 'Brot & Frühstück', unit: 'Stück', defaultQty: 1, step: 1, icon: '🥮', healthScore: 38, caloriesPer100: 380, proteinPer100: 6.5, carbsPer100: 48.0, fatPer100: 18.0, fiberPer100: 3.1, sugarPer100: 22.0, saturatedFatPer100: 6.5, saltPer100: 0.5, foodQuality: 38, waterContribution: 0.15, foodGroups: ['Sweets', 'Nuts'], processingLevel: 'ultra_processed', isSweet: true, isNut: true, info: 'Feines Hefeteiggebäck mit Haselnuss.', quickOpts: [1, 2] },
  { id: 'palatschinken', name: 'Palatschinken', category: 'Brot & Frühstück', unit: 'Portion', defaultQty: 1, step: 1, icon: '🥞', healthScore: 50, caloriesPer100: 220, proteinPer100: 6.2, carbsPer100: 28.0, fatPer100: 9.0, fiberPer100: 1.2, sugarPer100: 12.0, saturatedFatPer100: 3.5, saltPer100: 0.4, foodQuality: 50, waterContribution: 0.3, foodGroups: ['Grains', 'Sweets'], processingLevel: 'processed', isSweet: true, info: 'Dünne österreichische Palatschinken.', quickOpts: [1, 2], options: [{ name: 'Füllung', key: 'topping', choices: ['Mit Marillenmarmelade', 'Mit Haselnusscreme / Nutella', 'Mit Topfenfüllung', 'Mit Eis & Schlagobers'] }] },
  { id: 'haferflocken', name: 'Porridge / Haferflocken', category: 'Brot & Frühstück', unit: 'g', defaultQty: 50, step: 10, icon: '🥣', healthScore: 95, caloriesPer100: 370, proteinPer100: 13.5, carbsPer100: 58.7, fatPer100: 7.0, fiberPer100: 10.0, sugarPer100: 1.1, saturatedFatPer100: 1.25, saltPer100: 0.02, foodQuality: 95, waterContribution: 0.4, foodGroups: ['WholeGrain'], processingLevel: 'unprocessed', isWholeGrain: true, info: 'Vollkornhafer für langanhaltende Energie.', quickOpts: [30, 50, 80], options: [{ name: 'Flüssigkeit', key: 'liquid', choices: ['Mit Wasser', 'Mit Kuhmilch', 'Mit Haferdrink', 'Mit Mandeldrink'] }] },
  { id: 'muesli', name: 'Müsli / Knuspermüsli', category: 'Brot & Frühstück', unit: 'g', defaultQty: 60, step: 10, icon: '🌾', healthScore: 80, caloriesPer100: 380, proteinPer100: 10.0, carbsPer100: 62.0, fatPer100: 8.5, fiberPer100: 7.5, sugarPer100: 14.0, saturatedFatPer100: 2.0, saltPer100: 0.1, foodQuality: 80, waterContribution: 0.2, foodGroups: ['WholeGrain', 'Nuts'], processingLevel: 'minimally_processed', isWholeGrain: true, info: 'Getreidemischung mit Nüssen oder Früchten.', quickOpts: [40, 60, 100] },
  { id: 'granola', name: 'Bio-Granola / Beerenmüsli', category: 'Brot & Frühstück', unit: 'g', defaultQty: 50, step: 10, icon: '🥣', healthScore: 85, caloriesPer100: 420, proteinPer100: 11.0, carbsPer100: 56.0, fatPer100: 14.0, fiberPer100: 8.0, sugarPer100: 12.0, saturatedFatPer100: 2.8, saltPer100: 0.08, foodQuality: 85, waterContribution: 0.2, foodGroups: ['WholeGrain', 'Fruit'], processingLevel: 'minimally_processed', isWholeGrain: true, info: 'Geröstete Haferflocken mit Honig & Beeren.', quickOpts: [30, 50, 80] },
  { id: 'eierspeis_kernöl', name: 'Eierspeis mit Kernöl', category: 'Brot & Frühstück', unit: 'Portion', defaultQty: 1, step: 1, icon: '🍳', healthScore: 88, caloriesPer100: 190, proteinPer100: 11.5, carbsPer100: 1.2, fatPer100: 15.5, fiberPer100: 0, sugarPer100: 0.8, saturatedFatPer100: 4.2, saltPer100: 0.8, foodQuality: 88, waterContribution: 0.4, foodGroups: ['Protein'], processingLevel: 'minimally_processed', info: 'Steirische Eierspeise mit dunklem Kürbiskernöl.', quickOpts: [1, 2] },
  { id: 'ham_eggs', name: 'Ham and Eggs / Spiegeleier', category: 'Brot & Frühstück', unit: 'Portion', defaultQty: 1, step: 1, icon: '🍳', healthScore: 78, caloriesPer100: 210, proteinPer100: 14.0, carbsPer100: 1.0, fatPer100: 16.5, fiberPer100: 0, sugarPer100: 0.5, saturatedFatPer100: 5.5, saltPer100: 1.4, foodQuality: 78, waterContribution: 0.35, foodGroups: ['Protein'], processingLevel: 'processed', info: 'Gebratener Beinschinken mit 2 Ei Spiegeleiern.', quickOpts: [1, 2] },
  { id: 'marillenbrot', name: 'Brot mit Marillenmarmelade', category: 'Brot & Frühstück', unit: 'Stück', defaultQty: 1, step: 1, icon: '🍞', healthScore: 70, caloriesPer100: 230, proteinPer100: 4.5, carbsPer100: 44.0, fatPer100: 3.5, fiberPer100: 3.2, sugarPer100: 18.0, saturatedFatPer100: 1.8, saltPer100: 0.7, foodQuality: 70, waterContribution: 0.3, foodGroups: ['Grains', 'Fruit'], processingLevel: 'processed', info: 'Bauernbrot mit Butter und Marillenmarmelade.', quickOpts: [1, 2] },
  { id: 'waffeln', name: 'Waffeln mit Puderzucker', category: 'Brot & Frühstück', unit: 'Stück', defaultQty: 1, step: 1, icon: '🧇', healthScore: 42, caloriesPer100: 350, proteinPer100: 6.0, carbsPer100: 46.0, fatPer100: 15.5, fiberPer100: 1.5, sugarPer100: 20.0, saturatedFatPer100: 8.5, saltPer100: 0.6, foodQuality: 42, waterContribution: 0.2, foodGroups: ['Sweets'], processingLevel: 'ultra_processed', isSweet: true, info: 'Frische Herzwaffeln.', quickOpts: [1, 2] },
  { id: 'marmelade', name: 'Marillenmarmelade / Honig', category: 'Brot & Frühstück', unit: 'g', defaultQty: 20, step: 10, icon: '🍯', healthScore: 55, caloriesPer100: 250, proteinPer100: 0.4, carbsPer100: 60.0, fatPer100: 0.1, fiberPer100: 1.1, sugarPer100: 56.0, saturatedFatPer100: 0, saltPer100: 0.02, foodQuality: 55, waterContribution: 0.2, foodGroups: ['Sweets', 'Fruit'], processingLevel: 'processed', isSweet: true, info: 'Süßer Aufstrich.', quickOpts: [10, 20, 40] },

  // 3. ÖSTERREICHISCHE SPEZIALITÄTEN & HAUPTSPEISEN (30)
  { id: 'schnitzel', name: 'Wiener Schnitzel', category: 'Hauptspeisen', unit: 'Stück', defaultQty: 1, step: 1, icon: '🥩', healthScore: 52, caloriesPer100: 260, proteinPer100: 18.5, carbsPer100: 12.0, fatPer100: 15.0, fiberPer100: 0.8, sugarPer100: 0.5, saturatedFatPer100: 3.5, saltPer100: 1.2, foodQuality: 52, waterContribution: 0.4, foodGroups: ['Meat'], processingLevel: 'processed', info: 'Klassisches golden paniertes Schnitzel.', quickOpts: [1, 2], options: [{ name: 'Fleischart', key: 'meat', choices: ['Kalbs-Schnitzel (Original)', 'Puten- / Hähnchenschnitzel', 'Schweineschnitzel'] }, { name: 'Beilage', key: 'side', choices: ['Mit Erdäpfelsalat', 'Mit Petersilerdäpfeln', 'Mit Pommes', 'Ohne Beilage'] }] },
  { id: 'kaiserschmarrn', name: 'Kaiserschmarrn', category: 'Hauptspeisen', unit: 'Portion', defaultQty: 1, step: 1, icon: '🥞', healthScore: 45, caloriesPer100: 230, proteinPer100: 6.5, carbsPer100: 32.0, fatPer100: 8.5, fiberPer100: 1.2, sugarPer100: 16.0, saturatedFatPer100: 4.2, saltPer100: 0.4, foodQuality: 45, waterContribution: 0.35, foodGroups: ['Sweets', 'Grains'], processingLevel: 'processed', isSweet: true, info: 'Fluffiger Schmarrn aus der Pfanne.', quickOpts: [0.5, 1, 2], options: [{ name: 'Beilage', key: 'side', choices: ['Mit Zwetschkenröster', 'Mit Apfelmus', 'Mit Staubzucker Pur'] }] },
  { id: 'schweinsbraten', name: 'Schweinsbraten mit Knödel', category: 'Hauptspeisen', unit: 'Portion', defaultQty: 1, step: 1, icon: '🍖', healthScore: 42, caloriesPer100: 240, proteinPer100: 15.0, carbsPer100: 14.0, fatPer100: 14.0, fiberPer100: 1.5, sugarPer100: 1.2, saturatedFatPer100: 5.2, saltPer100: 1.6, foodQuality: 42, waterContribution: 0.45, foodGroups: ['Meat', 'Grains'], processingLevel: 'processed', info: 'Krustenschweinsbraten mit Semmelknödel & Sauerkraut.', quickOpts: [1, 2] },
  { id: 'kaspressknoedel', name: 'Kaspressknödel', category: 'Hauptspeisen', unit: 'Stück', defaultQty: 2, step: 1, icon: '🧆', healthScore: 68, caloriesPer100: 210, proteinPer100: 9.8, carbsPer100: 20.0, fatPer100: 9.5, fiberPer100: 1.8, sugarPer100: 1.1, saturatedFatPer100: 5.0, saltPer100: 1.4, foodQuality: 68, waterContribution: 0.4, foodGroups: ['Dairy', 'Grains'], processingLevel: 'processed', isDairy: true, info: 'Herzhafte Knödel mit würzigem Bergkäse.', quickOpts: [1, 2, 3], options: [{ name: 'Serviert in/auf', key: 'served', choices: ['In kräftiger Rindssuppe', 'Auf frischem Blattsalat', 'Pur / Aus der Pfanne'] }] },
  { id: 'frittatensuppe', name: 'Frittatensuppe', category: 'Hauptspeisen', unit: 'Teller', defaultQty: 1, step: 1, icon: '🍲', healthScore: 80, caloriesPer100: 65, proteinPer100: 3.8, carbsPer100: 6.5, fatPer100: 2.5, fiberPer100: 0.3, sugarPer100: 0.5, saturatedFatPer100: 0.9, saltPer100: 0.9, foodQuality: 80, waterContribution: 0.9, foodGroups: ['Water', 'Grains'], processingLevel: 'minimally_processed', info: 'Rindssuppe mit feinen Palatschinkenstreifen.', quickOpts: [1, 2] },
  { id: 'griessnockerlsuppe', name: 'Grießnockerlsuppe', category: 'Hauptspeisen', unit: 'Teller', defaultQty: 1, step: 1, icon: '🍲', healthScore: 82, caloriesPer100: 75, proteinPer100: 3.2, carbsPer100: 8.0, fatPer100: 3.0, fiberPer100: 0.4, sugarPer100: 0.4, saturatedFatPer100: 1.2, saltPer100: 0.85, foodQuality: 82, waterContribution: 0.9, foodGroups: ['Water', 'Grains'], processingLevel: 'minimally_processed', info: 'Kräftige Suppe mit fluffigen Grießnockerln.', quickOpts: [1, 2] },
  { id: 'tafelspitz', name: 'Tafelspitz mit Kren & Erdäpfeln', category: 'Hauptspeisen', unit: 'Portion', defaultQty: 1, step: 1, icon: '🥩', healthScore: 85, caloriesPer100: 180, proteinPer100: 21.0, carbsPer100: 8.0, fatPer100: 6.5, fiberPer100: 1.2, sugarPer100: 1.0, saturatedFatPer100: 2.6, saltPer100: 1.1, foodQuality: 85, waterContribution: 0.6, foodGroups: ['Meat', 'Vegetables'], processingLevel: 'minimally_processed', info: 'Gekochtes mageres Rindfleisch mit Apfelkren.', quickOpts: [1, 2] },
  { id: 'gulasch', name: 'Rindsgulasch / Fiaker Gulasch', category: 'Hauptspeisen', unit: 'Teller', defaultQty: 1, step: 1, icon: '🥘', healthScore: 65, caloriesPer100: 160, proteinPer100: 14.5, carbsPer100: 5.5, fatPer100: 8.8, fiberPer100: 1.5, sugarPer100: 2.2, saturatedFatPer100: 3.2, saltPer100: 1.3, foodQuality: 65, waterContribution: 0.65, foodGroups: ['Meat', 'Vegetables'], processingLevel: 'processed', info: 'Herzhaftes Rindsgulasch mit Paprikasoße.', quickOpts: [1, 2], options: [{ name: 'Extras', key: 'extra', choices: ['Klassisch mit Semmel', 'Fiaker (mit Spiegelei & Würstel)'] }] },
  { id: 'marillenknoedel', name: 'Marillenknödel', category: 'Hauptspeisen', unit: 'Stück', defaultQty: 2, step: 1, icon: '🍑', healthScore: 50, caloriesPer100: 190, proteinPer100: 5.0, carbsPer100: 30.0, fatPer100: 5.2, fiberPer100: 2.1, sugarPer100: 14.0, saturatedFatPer100: 2.5, saltPer100: 0.3, foodQuality: 50, waterContribution: 0.45, foodGroups: ['Fruit', 'Dairy', 'Sweets'], processingLevel: 'processed', isFruit: true, isSweet: true, info: 'Topfenteigknödel mit frischen Marillen.', quickOpts: [1, 2, 3] },
  { id: 'germknoedel', name: 'Germknödel mit Mohn', category: 'Hauptspeisen', unit: 'Stück', defaultQty: 1, step: 1, icon: '🥟', healthScore: 42, caloriesPer100: 250, proteinPer100: 6.2, carbsPer100: 42.0, fatPer100: 6.0, fiberPer100: 2.8, sugarPer100: 18.0, saturatedFatPer100: 2.8, saltPer100: 0.4, foodQuality: 42, waterContribution: 0.35, foodGroups: ['Sweets', 'Grains'], processingLevel: 'processed', isSweet: true, info: 'Hefeknödel gefüllt mit Powidl & Mohn-Zucker.', quickOpts: [1, 2], options: [{ name: 'Soße / Butter', key: 'topping', choices: ['Zerlassene Butter', 'Vanillesoße'] }] },
  { id: 'apfelstrudel', name: 'Wiener Apfelstrudel', category: 'Hauptspeisen', unit: 'Stück', defaultQty: 1, step: 1, icon: '🥧', healthScore: 48, caloriesPer100: 210, proteinPer100: 3.0, carbsPer100: 35.0, fatPer100: 6.5, fiberPer100: 2.5, sugarPer100: 20.0, saturatedFatPer100: 2.5, saltPer100: 0.2, foodQuality: 48, waterContribution: 0.4, foodGroups: ['Fruit', 'Sweets'], processingLevel: 'processed', isFruit: true, isSweet: true, info: 'Strudelteig mit Äpfeln, Rosinen & Zimt.', quickOpts: [1, 2], options: [{ name: 'Serviert mit', key: 'topping', choices: ['Pur (Warm)', 'Mit Vanillesoße', 'Mit Schlagobers', 'Mit Vanilleeis'] }] },
  { id: 'topfenstrudel', name: 'Topfenstrudel (Warm)', category: 'Hauptspeisen', unit: 'Stück', defaultQty: 1, step: 1, icon: '🥧', healthScore: 52, caloriesPer100: 230, proteinPer100: 7.2, carbsPer100: 28.0, fatPer100: 9.8, fiberPer100: 1.2, sugarPer100: 16.0, saturatedFatPer100: 5.1, saltPer100: 0.35, foodQuality: 52, waterContribution: 0.4, foodGroups: ['Dairy', 'Sweets'], processingLevel: 'processed', isDairy: true, isSweet: true, info: 'Ofenfrischer Strudel mit süßem Topfen.', quickOpts: [1, 2] },
  { id: 'sachertorte', name: 'Sachertorte', category: 'Hauptspeisen', unit: 'Stück', defaultQty: 1, step: 1, icon: '🍰', healthScore: 30, caloriesPer100: 380, proteinPer100: 5.2, carbsPer100: 48.0, fatPer100: 18.5, fiberPer100: 3.0, sugarPer100: 36.0, saturatedFatPer100: 10.2, saltPer100: 0.3, foodQuality: 30, waterContribution: 0.2, foodGroups: ['Sweets'], processingLevel: 'ultra_processed', isSweet: true, info: 'Wiener Schokoladentorte mit Marillenmarmelade.', quickOpts: [1, 2], options: [{ name: 'Beilage', key: 'topping', choices: ['Mit Schlagobers', 'Ohne Schlagobers'] }] },
  { id: 'stelze', name: 'Schweinsstelze / Stelze', category: 'Hauptspeisen', unit: 'Portion', defaultQty: 1, step: 1, icon: '🍖', healthScore: 38, caloriesPer100: 290, proteinPer100: 22.0, carbsPer100: 0.5, fatPer100: 22.0, fiberPer100: 0, sugarPer100: 0, saturatedFatPer100: 8.5, saltPer100: 1.8, foodQuality: 38, waterContribution: 0.4, foodGroups: ['Meat'], processingLevel: 'processed', info: 'Knusprig gebratene Schweinshaxe mit Kren.', quickOpts: [0.5, 1] },
  { id: 'faschierte_laibchen', name: 'Faschierte Laibchen', category: 'Hauptspeisen', unit: 'Stück', defaultQty: 2, step: 1, icon: '🧆', healthScore: 62, caloriesPer100: 230, proteinPer100: 16.0, carbsPer100: 8.0, fatPer100: 14.5, fiberPer100: 0.8, sugarPer100: 1.0, saturatedFatPer100: 5.2, saltPer100: 1.4, foodQuality: 62, waterContribution: 0.4, foodGroups: ['Meat'], processingLevel: 'processed', info: 'Österreichische Frikadellen aus Hackfleisch.', quickOpts: [1, 2, 3] },
  { id: 'kasnocken', name: 'Kasnocken / Kässpätzle', category: 'Hauptspeisen', unit: 'Portion', defaultQty: 1, step: 1, icon: '🧀', healthScore: 50, caloriesPer100: 270, proteinPer100: 12.0, carbsPer100: 26.0, fatPer100: 13.0, fiberPer100: 1.5, sugarPer100: 1.2, saturatedFatPer100: 7.5, saltPer100: 1.5, foodQuality: 50, waterContribution: 0.35, foodGroups: ['Dairy', 'Grains'], processingLevel: 'processed', isDairy: true, info: 'Nockerl mit schmelzendem Bergkäse & Röstzwiebeln.', quickOpts: [1, 2] },
  { id: 'zwiebelrostbraten', name: 'Zwiebelrostbraten', category: 'Hauptspeisen', unit: 'Portion', defaultQty: 1, step: 1, icon: '🥩', healthScore: 72, caloriesPer100: 210, proteinPer100: 19.0, carbsPer100: 7.0, fatPer100: 11.5, fiberPer100: 1.0, sugarPer100: 1.5, saturatedFatPer100: 4.2, saltPer100: 1.2, foodQuality: 72, waterContribution: 0.5, foodGroups: ['Meat', 'Vegetables'], processingLevel: 'minimally_processed', info: 'Rumpsteak mit Röstzwiebeln & Braterdäpfeln.', quickOpts: [1, 2] },
  { id: 'eierschwammerlgulasch', name: 'Eierschwammerlgulasch', category: 'Hauptspeisen', unit: 'Portion', defaultQty: 1, step: 1, icon: '🍄', healthScore: 82, caloriesPer100: 110, proteinPer100: 3.5, carbsPer100: 6.0, fatPer100: 7.5, fiberPer100: 3.2, sugarPer100: 1.8, saturatedFatPer100: 3.8, saltPer100: 1.1, foodQuality: 82, waterContribution: 0.7, foodGroups: ['Vegetables'], processingLevel: 'minimally_processed', isVegetable: true, info: 'Pfifferling-Rahmgulasch mit Semmelknödel.', quickOpts: [1, 2] },
  { id: 'tiroler_groestl', name: 'Tiroler Gröstl mit Spiegelei', category: 'Hauptspeisen', unit: 'Portion', defaultQty: 1, step: 1, icon: '🍳', healthScore: 58, caloriesPer100: 230, proteinPer100: 9.5, carbsPer100: 18.0, fatPer100: 13.5, fiberPer100: 1.8, sugarPer100: 1.0, saturatedFatPer100: 4.8, saltPer100: 1.5, foodQuality: 58, waterContribution: 0.4, foodGroups: ['Meat', 'Grains'], processingLevel: 'processed', info: 'Gebratene Erdäpfel mit Fleisch & Ei.', quickOpts: [1, 2] },
  { id: 'backhendl', name: 'Wiener Backhendl', category: 'Hauptspeisen', unit: 'Portion', defaultQty: 1, step: 1, icon: '🍗', healthScore: 55, caloriesPer100: 240, proteinPer100: 21.0, carbsPer100: 10.0, fatPer100: 12.5, fiberPer100: 0.6, sugarPer100: 0.3, saturatedFatPer100: 2.8, saltPer100: 1.1, foodQuality: 55, waterContribution: 0.45, foodGroups: ['Meat'], processingLevel: 'processed', info: 'Knusprig paniertes Hähnchen.', quickOpts: [1, 2] },
  { id: 'krautwickler', name: 'Krautwickler / Roulade', category: 'Hauptspeisen', unit: 'Stück', defaultQty: 2, step: 1, icon: '🥬', healthScore: 78, caloriesPer100: 140, proteinPer100: 9.2, carbsPer100: 6.5, fatPer100: 8.0, fiberPer100: 2.4, sugarPer100: 2.5, saturatedFatPer100: 3.1, saltPer100: 1.2, foodQuality: 78, waterContribution: 0.65, foodGroups: ['Vegetables', 'Meat'], processingLevel: 'minimally_processed', isVegetable: true, info: 'Kohlblätter gefüllt mit Faschiertem.', quickOpts: [1, 2] },
  { id: 'kasnudeln', name: 'Kärntner Kasnudeln', category: 'Hauptspeisen', unit: 'Stück', defaultQty: 3, step: 1, icon: '🥟', healthScore: 68, caloriesPer100: 190, proteinPer100: 7.5, carbsPer100: 25.0, fatPer100: 6.8, fiberPer100: 1.8, sugarPer100: 1.5, saturatedFatPer100: 3.8, saltPer100: 1.1, foodQuality: 68, waterContribution: 0.45, foodGroups: ['Dairy', 'Grains'], processingLevel: 'processed', isDairy: true, info: 'Teigtaschen gefüllt mit Topfen & Minze.', quickOpts: [2, 3, 4] },
  { id: 'bosna', name: 'Bosna / Currywurst', category: 'Hauptspeisen', unit: 'Stück', defaultQty: 1, step: 1, icon: '🌭', healthScore: 35, caloriesPer100: 280, proteinPer100: 11.0, carbsPer100: 22.0, fatPer100: 16.5, fiberPer100: 1.5, sugarPer100: 4.5, saturatedFatPer100: 6.2, saltPer100: 2.2, foodQuality: 35, waterContribution: 0.3, foodGroups: ['Meat', 'Sweets'], processingLevel: 'ultra_processed', info: 'Grillwurst im Weckerl mit Zwiebeln & Curry.', quickOpts: [1, 2] },
  { id: 'fischstaebchen', name: 'Fischstäbchen mit Erdäpfelpüree', category: 'Hauptspeisen', unit: 'Portion', defaultQty: 1, step: 1, icon: '🐟', healthScore: 65, caloriesPer100: 170, proteinPer100: 9.5, carbsPer100: 18.0, fatPer100: 6.5, fiberPer100: 1.4, sugarPer100: 1.1, saturatedFatPer100: 1.8, saltPer100: 0.95, foodQuality: 65, waterContribution: 0.5, foodGroups: ['Fish', 'Grains'], processingLevel: 'processed', isFish: true, info: 'Paniertes Fischfilet.', quickOpts: [1, 2] },
  { id: 'grillhendl', name: 'Grillhendl (Halbes Hähnchen)', category: 'Hauptspeisen', unit: 'Portion', defaultQty: 0.5, step: 0.5, icon: '🍗', healthScore: 82, caloriesPer100: 210, proteinPer100: 24.0, carbsPer100: 0.2, fatPer100: 12.5, fiberPer100: 0, sugarPer100: 0, saturatedFatPer100: 3.6, saltPer100: 1.2, foodQuality: 82, waterContribution: 0.55, foodGroups: ['Meat'], processingLevel: 'minimally_processed', info: 'Saftig gegrilltes Hendl mit Gewürzen.', quickOpts: [0.5, 1] },
  { id: 'linsen_speck', name: 'Linsen mit Speck & Knödel', category: 'Hauptspeisen', unit: 'Teller', defaultQty: 1, step: 1, icon: '🍲', healthScore: 80, caloriesPer100: 150, proteinPer100: 8.5, carbsPer100: 17.5, fatPer100: 4.8, fiberPer100: 4.5, sugarPer100: 1.5, saturatedFatPer100: 1.8, saltPer100: 1.2, foodQuality: 80, waterContribution: 0.65, foodGroups: ['Legumes', 'Meat'], processingLevel: 'minimally_processed', isLegume: true, info: 'Herzhafte Linsen in dunkler Soße.', quickOpts: [1, 2] },
  { id: 'erdaepfelgulasch', name: 'Erdäpfelgulasch mit Würstel', category: 'Hauptspeisen', unit: 'Teller', defaultQty: 1, step: 1, icon: '🥘', healthScore: 70, caloriesPer100: 140, proteinPer100: 5.2, carbsPer100: 14.0, fatPer100: 6.8, fiberPer100: 2.1, sugarPer100: 1.8, saturatedFatPer100: 2.5, saltPer100: 1.3, foodQuality: 70, waterContribution: 0.65, foodGroups: ['Grains', 'Meat'], processingLevel: 'processed', info: 'Würziges Kartoffeltopf-Gulasch.', quickOpts: [1, 2] },
  { id: 'blutwurst', name: 'Blutwurst / Blunzen', category: 'Hauptspeisen', unit: 'g', defaultQty: 150, step: 50, icon: '🌭', healthScore: 48, caloriesPer100: 300, proteinPer100: 14.0, carbsPer100: 2.5, fatPer100: 26.0, fiberPer100: 0, sugarPer100: 0.5, saturatedFatPer100: 10.5, saltPer100: 2.1, foodQuality: 48, waterContribution: 0.35, foodGroups: ['Meat'], processingLevel: 'ultra_processed', info: 'Gebratene Blunzen mit Sauerkraut.', quickOpts: [100, 150, 250] },
  { id: 'gemueseauflauf', name: 'Gemüseauflauf mit Käse', category: 'Hauptspeisen', unit: 'Portion', defaultQty: 1, step: 1, icon: '🥦', healthScore: 85, caloriesPer100: 130, proteinPer100: 6.5, carbsPer100: 8.5, fatPer100: 7.5, fiberPer100: 3.2, sugarPer100: 2.8, saturatedFatPer100: 4.2, saltPer100: 0.8, foodQuality: 85, waterContribution: 0.7, foodGroups: ['Vegetables', 'Dairy'], processingLevel: 'minimally_processed', isVegetable: true, isDairy: true, info: 'Überbackenes Ofengemüse.', quickOpts: [1, 2] },
  { id: 'falafel_wrap', name: 'Falafel Wrap / Veggie', category: 'Hauptspeisen', unit: 'Stück', defaultQty: 1, step: 1, icon: '🌯', healthScore: 82, caloriesPer100: 190, proteinPer100: 6.8, carbsPer100: 26.0, fatPer100: 6.5, fiberPer100: 4.2, sugarPer100: 2.5, saturatedFatPer100: 1.0, saltPer100: 1.1, foodQuality: 82, waterContribution: 0.5, foodGroups: ['Legumes', 'Vegetables', 'Grains'], processingLevel: 'minimally_processed', isLegume: true, isVegetable: true, info: 'Kichererbsenbällchen mit Salat im Fladenbrot.', quickOpts: [1, 2] },

  // 4. NUDELN, REIS & BEILAGEN (12)
  { id: 'nudeln', name: 'Nudeln / Pasta', category: 'Nudeln & Beilagen', unit: 'g', defaultQty: 200, step: 50, icon: '🍝', healthScore: 72, caloriesPer100: 150, proteinPer100: 5.5, carbsPer100: 30.0, fatPer100: 0.9, fiberPer100: 1.8, sugarPer100: 0.6, saturatedFatPer100: 0.2, saltPer100: 0.01, foodQuality: 72, waterContribution: 0.6, foodGroups: ['Grains'], processingLevel: 'processed', info: 'Gekochte Pasta (Spaghetti, Penne).', quickOpts: [150, 200, 300], options: [{ name: 'Soße & Pesto', key: 'sauce', choices: ['Pesto Verde (Basilikum)', 'Pesto Rosso (Tomate)', 'Paradeisersoße / Sugo', 'Bolognese (Faschiertes)', 'Aglio e Olio (Knoblauch/Öl)', 'Carbonara (Sahne/Speck)', 'Pur mit Butter'] }] },
  { id: 'gnocchi', name: 'Gnocchi / Erdäpfelnockerl', category: 'Nudeln & Beilagen', unit: 'g', defaultQty: 200, step: 50, icon: '🥟', healthScore: 70, caloriesPer100: 160, proteinPer100: 3.5, carbsPer100: 34.0, fatPer100: 0.8, fiberPer100: 2.0, sugarPer100: 0.8, saturatedFatPer100: 0.2, saltPer100: 0.9, foodQuality: 70, waterContribution: 0.55, foodGroups: ['Grains'], processingLevel: 'processed', info: 'Erdäpfelnockerl aus der Pfanne.', quickOpts: [150, 200, 250], options: [{ name: 'Soße', key: 'sauce', choices: ['In Butter & Salbei', 'Mit Pesto Verde', 'In Paradeisersugo'] }] },
  { id: 'reis', name: 'Reis (Basmati / Natur)', category: 'Nudeln & Beilagen', unit: 'g', defaultQty: 150, step: 25, icon: '🍚', healthScore: 82, caloriesPer100: 130, proteinPer100: 2.7, carbsPer100: 28.0, fatPer100: 0.3, fiberPer100: 1.0, sugarPer100: 0.1, saturatedFatPer100: 0.1, saltPer100: 0, foodQuality: 82, waterContribution: 0.65, foodGroups: ['Grains'], processingLevel: 'minimally_processed', info: 'Gekochter Basmati-, Jasmin- oder Naturreis.', quickOpts: [100, 150, 250] },
  { id: 'erdaepfel', name: 'Erdäpfel (Kartoffeln)', category: 'Nudeln & Beilagen', unit: 'g', defaultQty: 200, step: 50, icon: '🥔', healthScore: 88, caloriesPer100: 85, proteinPer100: 2.0, carbsPer100: 17.5, fatPer100: 0.1, fiberPer100: 2.1, sugarPer100: 0.8, saturatedFatPer100: 0, saltPer100: 0.01, foodQuality: 88, waterContribution: 0.75, foodGroups: ['Vegetables'], processingLevel: 'unprocessed', isVegetable: true, info: 'Salzerdäpfel, Petersilerdäpfel oder Ofenerdäpfel.', quickOpts: [100, 200, 300], options: [{ name: 'Zubereitungsart', key: 'prep', choices: ['Salzerdäpfel / Gekocht', 'Petersilerdäpfel', 'Erdäpfelpüree', 'Braterdäpfel (in Öl)'] }] },
  { id: 'pommes', name: 'Pommes Frites', category: 'Nudeln & Beilagen', unit: 'Portion', defaultQty: 1, step: 1, icon: '🍟', healthScore: 30, caloriesPer100: 290, proteinPer100: 3.4, carbsPer100: 36.0, fatPer100: 14.5, fiberPer100: 3.5, sugarPer100: 0.4, saturatedFatPer100: 2.2, saltPer100: 1.1, foodQuality: 30, waterContribution: 0.3, foodGroups: ['Sweets'], processingLevel: 'ultra_processed', info: 'Krosse frittierte Erdäpfelstäbchen.', quickOpts: [1, 2], options: [{ name: 'Dips', key: 'dip', choices: ['Mit Ketchup', 'Mit Mayonnaise', 'Heißluftfritteuse (Mager)', 'Ohne Soße'] }] },
  { id: 'pizza', name: 'Pizza', category: 'Nudeln & Beilagen', unit: 'Stück', defaultQty: 1, step: 1, icon: '🍕', healthScore: 35, caloriesPer100: 260, proteinPer100: 10.5, carbsPer100: 30.0, fatPer100: 10.5, fiberPer100: 2.2, sugarPer100: 2.8, saturatedFatPer100: 4.5, saltPer100: 1.5, foodQuality: 35, waterContribution: 0.35, foodGroups: ['Dairy', 'Grains'], processingLevel: 'ultra_processed', isDairy: true, info: 'Steinofen-Pizza nach Wahl.', quickOpts: [1, 2, 4], options: [{ name: 'Sorte', key: 'topping', choices: ['Margherita / Veggie', 'Salami / Schinken', 'Prosciutto & Rucola', 'Quattro Formaggi'] }] },
  { id: 'burger', name: 'Burger', category: 'Nudeln & Beilagen', unit: 'Stück', defaultQty: 1, step: 1, icon: '🍔', healthScore: 35, caloriesPer100: 250, proteinPer100: 13.0, carbsPer100: 24.0, fatPer100: 11.5, fiberPer100: 1.8, sugarPer100: 5.0, saturatedFatPer100: 4.8, saltPer100: 1.4, foodQuality: 35, waterContribution: 0.4, foodGroups: ['Meat', 'Grains'], processingLevel: 'ultra_processed', info: 'Burger mit Rindfleisch oder Veggie-Patty.', quickOpts: [1, 2] },
  { id: 'doener', name: 'Döner / Kebab / Kebap', category: 'Nudeln & Beilagen', unit: 'Stück', defaultQty: 1, step: 1, icon: '🥙', healthScore: 55, caloriesPer100: 210, proteinPer100: 12.5, carbsPer100: 20.0, fatPer100: 8.8, fiberPer100: 2.2, sugarPer100: 2.0, saturatedFatPer100: 2.8, saltPer100: 1.3, foodQuality: 55, waterContribution: 0.5, foodGroups: ['Meat', 'Vegetables', 'Grains'], processingLevel: 'processed', isVegetable: true, info: 'Fladenbrot mit Hendl/Lamm & Knacksalat.', quickOpts: [0.5, 1] },
  { id: 'salat', name: 'Gemischter Blattsalat', category: 'Nudeln & Beilagen', unit: 'Portion', defaultQty: 1, step: 1, icon: '🥗', healthScore: 95, caloriesPer100: 45, proteinPer100: 1.2, carbsPer100: 2.5, fatPer100: 3.2, fiberPer100: 1.8, sugarPer100: 1.8, saturatedFatPer100: 0.5, saltPer100: 0.3, foodQuality: 95, waterContribution: 0.9, foodGroups: ['Vegetables'], processingLevel: 'unprocessed', isVegetable: true, info: 'Knackiger Salat mit Rohkost.', quickOpts: [1, 2], options: [{ name: 'Dressing', key: 'dressing', choices: ['Kernöl & Essig (Steirisch)', 'Balsamico & Olivenöl', 'Joghurt-Dressing', 'Ohne Dressing'] }] },
  { id: 'erdaepfelsalat', name: 'Österreichischer Erdäpfelsalat', category: 'Nudeln & Beilagen', unit: 'g', defaultQty: 150, step: 50, icon: '🥗', healthScore: 75, caloriesPer100: 120, proteinPer100: 1.8, carbsPer100: 15.0, fatPer100: 5.5, fiberPer100: 1.8, sugarPer100: 2.5, saturatedFatPer100: 0.8, saltPer100: 0.9, foodQuality: 75, waterContribution: 0.7, foodGroups: ['Vegetables'], processingLevel: 'minimally_processed', isVegetable: true, info: 'Klassischer Erdäpfelsalat mit Rinderbrühe & Essig.', quickOpts: [100, 150, 250] },
  { id: 'ofengemuese', name: 'Ofengemüse (Zucchini, Paprika)', category: 'Nudeln & Beilagen', unit: 'g', defaultQty: 200, step: 50, icon: '🫑', healthScore: 96, caloriesPer100: 60, proteinPer100: 1.5, carbsPer100: 6.0, fatPer100: 3.0, fiberPer100: 2.8, sugarPer100: 3.8, saturatedFatPer100: 0.4, saltPer100: 0.4, foodQuality: 96, waterContribution: 0.85, foodGroups: ['Vegetables'], processingLevel: 'unprocessed', isVegetable: true, info: 'Bunt geröstetes Gemüse mit Olivenöl.', quickOpts: [100, 200, 300] },
  { id: 'semmelknoedel', name: 'Semmelknödel / Serviettenknödel', category: 'Nudeln & Beilagen', unit: 'Stück', defaultQty: 1, step: 1, icon: '🧆', healthScore: 62, caloriesPer100: 210, proteinPer100: 6.8, carbsPer100: 34.0, fatPer100: 5.2, fiberPer100: 2.1, sugarPer100: 2.2, saturatedFatPer100: 1.8, saltPer100: 1.2, foodQuality: 62, waterContribution: 0.4, foodGroups: ['Grains'], processingLevel: 'processed', info: 'Traditioneller Wiener Semmelknödel.', quickOpts: [1, 2] },

  // 5. MILCHPRODUKTE & EIWEISS (10)
  { id: 'topfen', name: 'Magertopfen / Topfen', category: 'Milchprodukte & Eiweiß', unit: 'g', defaultQty: 200, step: 50, icon: '🥛', healthScore: 95, caloriesPer100: 70, proteinPer100: 12.0, carbsPer100: 3.5, fatPer100: 0.2, fiberPer100: 0, sugarPer100: 3.5, saturatedFatPer100: 0.1, saltPer100: 0.1, foodQuality: 95, waterContribution: 0.8, foodGroups: ['Dairy'], processingLevel: 'minimally_processed', isDairy: true, info: 'Österreichischer Eiweiß-Klassiker.', quickOpts: [100, 200, 250], options: [{ name: 'Verfeinerung', key: 'sweet', choices: ['Natur Pur', 'Mit Honig / Früchten', 'Kräutertopfen (Herzhaft)'] }] },
  { id: 'joghurt', name: 'Naturjoghurt (3,5% / Mager)', category: 'Milchprodukte & Eiweiß', unit: 'g', defaultQty: 150, step: 25, icon: '🥣', healthScore: 88, caloriesPer100: 60, proteinPer100: 3.8, carbsPer100: 4.6, fatPer100: 3.5, fiberPer100: 0, sugarPer100: 4.6, saturatedFatPer100: 2.3, saltPer100: 0.12, foodQuality: 88, waterContribution: 0.85, foodGroups: ['Dairy'], processingLevel: 'minimally_processed', isDairy: true, info: 'Frisches Naturjoghurt.', quickOpts: [100, 150, 250] },
  { id: 'fruchtjoghurt', name: 'Fruchtjoghurt (Marille/Erdbeere)', category: 'Milchprodukte & Eiweiß', unit: 'g', defaultQty: 150, step: 25, icon: '🍓', healthScore: 70, caloriesPer100: 95, proteinPer100: 3.2, carbsPer100: 13.5, fatPer100: 2.8, fiberPer100: 0.3, sugarPer100: 12.8, saturatedFatPer100: 1.8, saltPer100: 0.1, foodQuality: 70, waterContribution: 0.8, foodGroups: ['Dairy', 'Fruit'], processingLevel: 'processed', isDairy: true, info: 'Cremiges Fruchtjoghurt.', quickOpts: [100, 150, 200] },
  { id: 'kaese', name: 'Gouda / Bergkäse / Emmentaler', category: 'Milchprodukte & Eiweiß', unit: 'g', defaultQty: 40, step: 20, icon: '🧀', healthScore: 70, caloriesPer100: 380, proteinPer100: 25.0, carbsPer100: 0.1, fatPer100: 31.0, fiberPer100: 0, sugarPer100: 0.1, saturatedFatPer100: 20.0, saltPer100: 1.6, foodQuality: 70, waterContribution: 0.35, foodGroups: ['Dairy'], processingLevel: 'processed', isDairy: true, info: 'Herzhafter österreichischer Käse.', quickOpts: [20, 40, 80] },
  { id: 'liptauer', name: 'Liptauer Aufstrich', category: 'Milchprodukte & Eiweiß', unit: 'g', defaultQty: 40, step: 10, icon: '🧈', healthScore: 72, caloriesPer100: 220, proteinPer100: 7.5, carbsPer100: 3.2, fatPer100: 19.5, fiberPer100: 0.5, sugarPer100: 2.8, saturatedFatPer100: 12.0, saltPer100: 1.2, foodQuality: 72, waterContribution: 0.5, foodGroups: ['Dairy'], processingLevel: 'processed', isDairy: true, info: 'Würziger Topfenaufstrich mit Paprika.', quickOpts: [20, 40, 60] },
  { id: 'schinken', name: 'Beinschinken / Saftschinken', category: 'Milchprodukte & Eiweiß', unit: 'g', defaultQty: 50, step: 25, icon: '🥓', healthScore: 78, caloriesPer100: 120, proteinPer100: 19.5, carbsPer100: 1.0, fatPer100: 4.2, fiberPer100: 0, sugarPer100: 0.8, saturatedFatPer100: 1.6, saltPer100: 2.2, foodQuality: 78, waterContribution: 0.6, foodGroups: ['Meat'], processingLevel: 'processed', info: 'Magerer österreichischer Schinken.', quickOpts: [25, 50, 100] },
  { id: 'ei', name: 'Gekochtes Ei / Eierspeis', category: 'Milchprodukte & Eiweiß', unit: 'Stück', defaultQty: 2, step: 1, icon: '🥚', healthScore: 88, caloriesPer100: 155, proteinPer100: 12.6, carbsPer100: 1.1, fatPer100: 11.2, fiberPer100: 0, sugarPer100: 1.1, saturatedFatPer100: 3.3, saltPer100: 0.3, foodQuality: 88, waterContribution: 0.75, foodGroups: ['Protein'], processingLevel: 'unprocessed', info: 'Frisches Hühnerei.', quickOpts: [1, 2, 3], options: [{ name: 'Zubereitung', key: 'prep', choices: ['Gekocht (Weich/Hart)', 'Eierspeis (Rührei)', 'Spiegelei'] }] },
  { id: 'hendl', name: 'Hendlbrust / Hähnchen', category: 'Milchprodukte & Eiweiß', unit: 'g', defaultQty: 150, step: 25, icon: '🍗', healthScore: 92, caloriesPer100: 110, proteinPer100: 23.0, carbsPer100: 0, fatPer100: 1.8, fiberPer100: 0, sugarPer100: 0, saturatedFatPer100: 0.5, saltPer100: 0.15, foodQuality: 92, waterContribution: 0.7, foodGroups: ['Meat'], processingLevel: 'unprocessed', info: 'Mageres Hendlfleisch gegrillt.', quickOpts: [100, 150, 250] },
  { id: 'lachs', name: 'Lachsfilet / Räucherlachs', category: 'Milchprodukte & Eiweiß', unit: 'g', defaultQty: 120, step: 30, icon: '🐟', healthScore: 94, caloriesPer100: 200, proteinPer100: 20.0, carbsPer100: 0, fatPer100: 13.0, fiberPer100: 0, sugarPer100: 0, saturatedFatPer100: 2.5, saltPer100: 0.1, foodQuality: 94, waterContribution: 0.65, foodGroups: ['Fish'], processingLevel: 'unprocessed', isFish: true, info: 'Omega-3 reicher Fisch.', quickOpts: [80, 120, 200] },
  { id: 'thunfisch', name: 'Thunfisch im eigenen Saft', category: 'Milchprodukte & Eiweiß', unit: 'g', defaultQty: 100, step: 25, icon: '🐟', healthScore: 90, caloriesPer100: 115, proteinPer100: 25.5, carbsPer100: 0, fatPer100: 1.0, fiberPer100: 0, sugarPer100: 0, saturatedFatPer100: 0.3, saltPer100: 0.8, foodQuality: 90, waterContribution: 0.7, foodGroups: ['Fish'], processingLevel: 'minimally_processed', isFish: true, info: 'Magerer Thunfisch.', quickOpts: [50, 100, 150] },

  // 6. OBST & GEMÜSE (8)
  { id: 'apfel', name: 'Heimischer Apfel', category: 'Obst & Gemüse', unit: 'Stück', defaultQty: 1, step: 1, icon: '🍎', healthScore: 96, caloriesPer100: 52, proteinPer100: 0.3, carbsPer100: 11.4, fatPer100: 0.2, fiberPer100: 2.4, sugarPer100: 10.3, saturatedFatPer100: 0, saltPer100: 0, foodQuality: 96, waterContribution: 0.85, foodGroups: ['Fruit'], processingLevel: 'unprocessed', isFruit: true, info: 'Knackiger Apfel aus der Region.', quickOpts: [1, 2] },
  { id: 'banane', name: 'Banane', category: 'Obst & Gemüse', unit: 'Stück', defaultQty: 1, step: 1, icon: '🍌', healthScore: 90, caloriesPer100: 89, proteinPer100: 1.1, carbsPer100: 20.2, fatPer100: 0.3, fiberPer100: 2.6, sugarPer100: 12.2, saturatedFatPer100: 0.1, saltPer100: 0, foodQuality: 90, waterContribution: 0.75, foodGroups: ['Fruit'], processingLevel: 'unprocessed', isFruit: true, info: 'Kaliumreiche Frucht.', quickOpts: [1, 2] },
  { id: 'beeren', name: 'Beeren-Mix (Erdbeeren, Himbeeren)', category: 'Obst & Gemüse', unit: 'g', defaultQty: 100, step: 25, icon: '🫐', healthScore: 98, caloriesPer100: 40, proteinPer100: 0.9, carbsPer100: 7.5, fatPer100: 0.3, fiberPer100: 4.5, sugarPer100: 5.2, saturatedFatPer100: 0, saltPer100: 0, foodQuality: 98, waterContribution: 0.88, foodGroups: ['Fruit'], processingLevel: 'unprocessed', isFruit: true, info: 'Frische Beeren voller Antioxidantien.', quickOpts: [50, 100, 200] },
  { id: 'marille', name: 'Marille / Zwetschke', category: 'Obst & Gemüse', unit: 'Stück', defaultQty: 2, step: 1, icon: '🍑', healthScore: 95, caloriesPer100: 48, proteinPer100: 0.9, carbsPer100: 10.0, fatPer100: 0.2, fiberPer100: 2.0, sugarPer100: 8.5, saturatedFatPer100: 0, saltPer100: 0, foodQuality: 95, waterContribution: 0.85, foodGroups: ['Fruit'], processingLevel: 'unprocessed', isFruit: true, info: 'Süße österreichische Marillen oder Zwetschken.', quickOpts: [1, 2, 4] },
  { id: 'paradeiser', name: 'Paradeiser (Tomaten) & Gurken', category: 'Obst & Gemüse', unit: 'g', defaultQty: 150, step: 50, icon: '🥒', healthScore: 98, caloriesPer100: 18, proteinPer100: 0.8, carbsPer100: 3.2, fatPer100: 0.2, fiberPer100: 1.2, sugarPer100: 2.5, saturatedFatPer100: 0, saltPer100: 0, foodQuality: 98, waterContribution: 0.95, foodGroups: ['Vegetables'], processingLevel: 'unprocessed', isVegetable: true, info: 'Frische Gurkenscheiben & Paradeiser.', quickOpts: [100, 150, 250] },
  { id: 'radieschen', name: 'Radieschen & Paprika', category: 'Obst & Gemüse', unit: 'g', defaultQty: 100, step: 25, icon: '🫑', healthScore: 97, caloriesPer100: 20, proteinPer100: 0.9, carbsPer100: 3.8, fatPer100: 0.2, fiberPer100: 1.8, sugarPer100: 2.8, saturatedFatPer100: 0, saltPer100: 0, foodQuality: 97, waterContribution: 0.92, foodGroups: ['Vegetables'], processingLevel: 'unprocessed', isVegetable: true, info: 'Knackige Rohkost.', quickOpts: [50, 100, 200] },
  { id: 'weintrauben', name: 'Weintrauben', category: 'Obst & Gemüse', unit: 'g', defaultQty: 120, step: 30, icon: '🍇', healthScore: 88, caloriesPer100: 67, proteinPer100: 0.6, carbsPer100: 16.0, fatPer100: 0.3, fiberPer100: 1.0, sugarPer100: 15.2, saturatedFatPer100: 0, saltPer100: 0, foodQuality: 88, waterContribution: 0.8, foodGroups: ['Fruit'], processingLevel: 'unprocessed', isFruit: true, info: 'Süße Trauben.', quickOpts: [80, 120, 200] },
  { id: 'orange', name: 'Orange / Mandarine', category: 'Obst & Gemüse', unit: 'Stück', defaultQty: 1, step: 1, icon: '🍊', healthScore: 94, caloriesPer100: 47, proteinPer100: 0.9, carbsPer100: 9.3, fatPer100: 0.1, fiberPer100: 2.2, sugarPer100: 8.5, saturatedFatPer100: 0, saltPer100: 0, foodQuality: 94, waterContribution: 0.87, foodGroups: ['Fruit'], processingLevel: 'unprocessed', isFruit: true, info: 'Saftige Zitrusfrucht.', quickOpts: [1, 2] },

  // 7. SNACKS & SÜSSES (4)
  { id: 'nuesse', name: 'Nüsse / Mandeln', category: 'Snacks & Süßes', unit: 'g', defaultQty: 30, step: 10, icon: '🥜', healthScore: 92, caloriesPer100: 600, proteinPer100: 20.0, carbsPer100: 14.0, fatPer100: 52.0, fiberPer100: 8.5, sugarPer100: 4.0, saturatedFatPer100: 4.5, saltPer100: 0.01, foodQuality: 92, waterContribution: 0.05, foodGroups: ['Nuts'], processingLevel: 'unprocessed', isNut: true, info: 'Walnüsse, Mandeln oder Cashews.', quickOpts: [20, 30, 50] },
  { id: 'schokolade', name: 'Schokolade', category: 'Snacks & Süßes', unit: 'g', defaultQty: 25, step: 5, icon: '🍫', healthScore: 35, caloriesPer100: 530, proteinPer100: 6.2, carbsPer100: 56.0, fatPer100: 31.0, fiberPer100: 3.2, sugarPer100: 52.0, saturatedFatPer100: 18.5, saltPer100: 0.15, foodQuality: 35, waterContribution: 0.05, foodGroups: ['Sweets'], processingLevel: 'ultra_processed', isSweet: true, info: 'Feine Schokolade.', quickOpts: [15, 25, 50], options: [{ name: 'Sorte', key: 'type', choices: ['Vollmilch', 'Dunkel (>70% Kakao)', 'Weiss'] }] },
  { id: 'mannerschnitten', name: 'Manner-Schnitten', category: 'Snacks & Süßes', unit: 'Stück', defaultQty: 2, step: 1, icon: '🧇', healthScore: 32, caloriesPer100: 490, proteinPer100: 5.5, carbsPer100: 65.0, fatPer100: 23.0, fiberPer100: 2.5, sugarPer100: 46.0, saturatedFatPer100: 15.0, saltPer100: 0.1, foodQuality: 32, waterContribution: 0.05, foodGroups: ['Sweets', 'Nuts'], processingLevel: 'ultra_processed', isSweet: true, isNut: true, info: 'Österreichische Neapolitaner Waffeln.', quickOpts: [1, 2, 4] },
  { id: 'krapfen', name: 'Faschingskrapfen / Krapfen', category: 'Snacks & Süßes', unit: 'Stück', defaultQty: 1, step: 1, icon: '🍩', healthScore: 30, caloriesPer100: 340, proteinPer100: 6.5, carbsPer100: 45.0, fatPer100: 14.5, fiberPer100: 1.8, sugarPer100: 18.0, saturatedFatPer100: 6.2, saltPer100: 0.5, foodQuality: 30, waterContribution: 0.2, foodGroups: ['Sweets'], processingLevel: 'ultra_processed', isSweet: true, info: 'Hefegebäck gefüllt mit Marillenmarmelade.', quickOpts: [1, 2] },

  // 8. ZUSÄTZLICHE LEBENSMITTEL (26)
  { id: 'heidelbeeren', name: 'Heidelbeeren', category: 'Obst & Gemüse', unit: 'g', defaultQty: 100, step: 25, icon: '🫐', healthScore: 94, caloriesPer100: 57, proteinPer100: 0.7, carbsPer100: 14.5, fatPer100: 0.3, fiberPer100: 2.4, sugarPer100: 10.0, saturatedFatPer100: 0, saltPer100: 0, foodQuality: 94, waterContribution: 0.84, foodGroups: ['Fruit'], processingLevel: 'unprocessed', isFruit: true, info: 'Heidelbeeren mit vielen natürlichen Pflanzenstoffen.', quickOpts: [75, 100, 150] },
  { id: 'himbeeren', name: 'Himbeeren', category: 'Obst & Gemüse', unit: 'g', defaultQty: 100, step: 25, icon: '🍓', healthScore: 96, caloriesPer100: 52, proteinPer100: 1.2, carbsPer100: 11.9, fatPer100: 0.7, fiberPer100: 6.5, sugarPer100: 4.4, saturatedFatPer100: 0, saltPer100: 0, foodQuality: 96, waterContribution: 0.85, foodGroups: ['Fruit'], processingLevel: 'unprocessed', isFruit: true, info: 'Ballaststoffreiche Beerenfrüchte.', quickOpts: [75, 100, 150] },
  { id: 'kiwi', name: 'Kiwi', category: 'Obst & Gemüse', unit: 'Stück', defaultQty: 1, step: 1, icon: '🥝', healthScore: 95, caloriesPer100: 61, proteinPer100: 1.1, carbsPer100: 14.7, fatPer100: 0.5, fiberPer100: 3.0, sugarPer100: 9.0, saturatedFatPer100: 0, saltPer100: 0, foodQuality: 95, waterContribution: 0.83, foodGroups: ['Fruit'], processingLevel: 'unprocessed', isFruit: true, info: 'Frucht mit Vitamin C und Ballaststoffen.', quickOpts: [1, 2, 3] },
  { id: 'paprika', name: 'Paprika', category: 'Obst & Gemüse', unit: 'g', defaultQty: 100, step: 25, icon: '🫑', healthScore: 96, caloriesPer100: 31, proteinPer100: 1.0, carbsPer100: 6.0, fatPer100: 0.3, fiberPer100: 2.1, sugarPer100: 4.2, saturatedFatPer100: 0, saltPer100: 0, foodQuality: 96, waterContribution: 0.92, foodGroups: ['Vegetables'], processingLevel: 'unprocessed', isVegetable: true, info: 'Knackiges Gemüse, roh oder gegart.', quickOpts: [75, 100, 150] },
  { id: 'spinat', name: 'Spinat', category: 'Obst & Gemüse', unit: 'g', defaultQty: 100, step: 25, icon: '🥬', healthScore: 98, caloriesPer100: 23, proteinPer100: 2.9, carbsPer100: 3.6, fatPer100: 0.4, fiberPer100: 2.2, sugarPer100: 0.4, saturatedFatPer100: 0, saltPer100: 0.2, foodQuality: 98, waterContribution: 0.91, foodGroups: ['Vegetables'], processingLevel: 'unprocessed', isVegetable: true, info: 'Blattgemüse mit vielen Mikronährstoffen.', quickOpts: [75, 100, 150] },
  { id: 'zucchini', name: 'Zucchini', category: 'Obst & Gemüse', unit: 'g', defaultQty: 150, step: 25, icon: '🥒', healthScore: 95, caloriesPer100: 17, proteinPer100: 1.2, carbsPer100: 3.1, fatPer100: 0.3, fiberPer100: 1.0, sugarPer100: 2.5, saturatedFatPer100: 0, saltPer100: 0.01, foodQuality: 95, waterContribution: 0.94, foodGroups: ['Vegetables'], processingLevel: 'unprocessed', isVegetable: true, info: 'Mildes, wasserreiches Gemüse.', quickOpts: [100, 150, 200] },
  { id: 'blumenkohl', name: 'Blumenkohl', category: 'Obst & Gemüse', unit: 'g', defaultQty: 150, step: 25, icon: '🥦', healthScore: 96, caloriesPer100: 25, proteinPer100: 1.9, carbsPer100: 5.0, fatPer100: 0.3, fiberPer100: 2.0, sugarPer100: 1.9, saturatedFatPer100: 0, saltPer100: 0.03, foodQuality: 96, waterContribution: 0.92, foodGroups: ['Vegetables'], processingLevel: 'unprocessed', isVegetable: true, info: 'Mildes Kreuzblütlergemüse.', quickOpts: [100, 150, 250] },
  { id: 'suesskartoffel', name: 'Süßkartoffel', category: 'Nudeln & Beilagen', unit: 'g', defaultQty: 200, step: 50, icon: '🍠', healthScore: 88, caloriesPer100: 86, proteinPer100: 1.6, carbsPer100: 20.1, fatPer100: 0.1, fiberPer100: 3.0, sugarPer100: 4.2, saturatedFatPer100: 0, saltPer100: 0.04, foodQuality: 88, waterContribution: 0.72, foodGroups: ['WholeGrain'], processingLevel: 'unprocessed', isVegetable: true, info: 'Sättigende Knolle mit komplexen Kohlenhydraten.', quickOpts: [150, 200, 300] },
  { id: 'quinoa', name: 'Quinoa, gekocht', category: 'Nudeln & Beilagen', unit: 'g', defaultQty: 150, step: 25, icon: '🌾', healthScore: 91, caloriesPer100: 120, proteinPer100: 4.4, carbsPer100: 21.3, fatPer100: 1.9, fiberPer100: 2.8, sugarPer100: 0.9, saturatedFatPer100: 0.2, saltPer100: 0.01, foodQuality: 91, waterContribution: 0.68, foodGroups: ['WholeGrain'], processingLevel: 'minimally_processed', info: 'Gekochtes Quinoa als vielseitige Beilage.', quickOpts: [100, 150, 200] },
  { id: 'couscous', name: 'Couscous, gekocht', category: 'Nudeln & Beilagen', unit: 'g', defaultQty: 150, step: 25, icon: '🍚', healthScore: 78, caloriesPer100: 112, proteinPer100: 3.8, carbsPer100: 23.2, fatPer100: 0.2, fiberPer100: 1.4, sugarPer100: 0.1, saturatedFatPer100: 0.1, saltPer100: 0.01, foodQuality: 78, waterContribution: 0.67, foodGroups: ['Grains'], processingLevel: 'minimally_processed', info: 'Gekochter Hartweizengrieß als Beilage.', quickOpts: [100, 150, 200] },
  { id: 'buchweizen', name: 'Buchweizen, gekocht', category: 'Nudeln & Beilagen', unit: 'g', defaultQty: 150, step: 25, icon: '🌾', healthScore: 89, caloriesPer100: 92, proteinPer100: 3.4, carbsPer100: 19.9, fatPer100: 0.6, fiberPer100: 2.7, sugarPer100: 0.9, saturatedFatPer100: 0.1, saltPer100: 0.01, foodQuality: 89, waterContribution: 0.72, foodGroups: ['WholeGrain'], processingLevel: 'minimally_processed', info: 'Glutenfreies Pseudogetreide mit herzhaftem Geschmack.', quickOpts: [100, 150, 200] },
  { id: 'linsen', name: 'Linsen, gekocht', category: 'Milchprodukte & Eiweiß', unit: 'g', defaultQty: 150, step: 25, icon: '🫘', healthScore: 94, caloriesPer100: 116, proteinPer100: 9.0, carbsPer100: 20.1, fatPer100: 0.4, fiberPer100: 7.9, sugarPer100: 1.8, saturatedFatPer100: 0.1, saltPer100: 0.01, foodQuality: 94, waterContribution: 0.70, foodGroups: ['Legumes'], processingLevel: 'minimally_processed', info: 'Eiweiß- und ballaststoffreiche Hülsenfrucht.', quickOpts: [100, 150, 200] },
  { id: 'kichererbsen', name: 'Kichererbsen, gekocht', category: 'Milchprodukte & Eiweiß', unit: 'g', defaultQty: 150, step: 25, icon: '🫘', healthScore: 92, caloriesPer100: 164, proteinPer100: 8.9, carbsPer100: 27.4, fatPer100: 2.6, fiberPer100: 7.6, sugarPer100: 4.8, saturatedFatPer100: 0.3, saltPer100: 0.01, foodQuality: 92, waterContribution: 0.65, foodGroups: ['Legumes'], processingLevel: 'minimally_processed', info: 'Sättigende Hülsenfrucht für Salate und warme Gerichte.', quickOpts: [100, 150, 200] },
  { id: 'tofu', name: 'Tofu, natur', category: 'Milchprodukte & Eiweiß', unit: 'g', defaultQty: 150, step: 25, icon: '🍱', healthScore: 90, caloriesPer100: 144, proteinPer100: 15.7, carbsPer100: 2.8, fatPer100: 8.7, fiberPer100: 0.3, sugarPer100: 0.6, saturatedFatPer100: 1.3, saltPer100: 0.02, foodQuality: 90, waterContribution: 0.72, foodGroups: ['Protein'], processingLevel: 'minimally_processed', info: 'Pflanzliche Proteinquelle aus Sojabohnen.', quickOpts: [100, 150, 200] },
  { id: 'ei_gekocht', name: 'Ei, gekocht', category: 'Milchprodukte & Eiweiß', unit: 'Stück', defaultQty: 2, step: 1, icon: '🥚', healthScore: 87, caloriesPer100: 155, proteinPer100: 13.0, carbsPer100: 1.1, fatPer100: 11.0, fiberPer100: 0, sugarPer100: 1.1, saturatedFatPer100: 3.3, saltPer100: 0.31, foodQuality: 87, waterContribution: 0.74, foodGroups: ['Protein'], processingLevel: 'minimally_processed', info: 'Gekochtes Ei als vielseitige Proteinquelle.', quickOpts: [1, 2, 3] },
  { id: 'truthahn', name: 'Putenbrust, gebraten', category: 'Milchprodukte & Eiweiß', unit: 'g', defaultQty: 150, step: 25, icon: '🍗', healthScore: 88, caloriesPer100: 135, proteinPer100: 29.0, carbsPer100: 0, fatPer100: 2.0, fiberPer100: 0, sugarPer100: 0, saturatedFatPer100: 0.6, saltPer100: 0.12, foodQuality: 88, waterContribution: 0.68, foodGroups: ['Meat', 'Protein'], processingLevel: 'minimally_processed', info: 'Mageres Geflügelfleisch mit hohem Eiweißanteil.', quickOpts: [100, 150, 200] },
  { id: 'thunfisch_eigenersaft', name: 'Thunfisch im eigenen Saft', category: 'Milchprodukte & Eiweiß', unit: 'g', defaultQty: 120, step: 20, icon: '🐟', healthScore: 80, caloriesPer100: 116, proteinPer100: 26.0, carbsPer100: 0, fatPer100: 1.0, fiberPer100: 0, sugarPer100: 0, saturatedFatPer100: 0.3, saltPer100: 0.9, foodQuality: 80, waterContribution: 0.65, foodGroups: ['Fish', 'Protein'], processingLevel: 'processed', isFish: true, info: 'Proteinreicher Thunfisch, konserviert im eigenen Saft.', quickOpts: [80, 120, 160] },
  { id: 'skyr', name: 'Skyr natur', category: 'Milchprodukte & Eiweiß', unit: 'g', defaultQty: 200, step: 50, icon: '🥣', healthScore: 92, caloriesPer100: 63, proteinPer100: 11.0, carbsPer100: 4.0, fatPer100: 0.2, fiberPer100: 0, sugarPer100: 4.0, saturatedFatPer100: 0.1, saltPer100: 0.1, foodQuality: 92, waterContribution: 0.82, foodGroups: ['Dairy', 'Protein'], processingLevel: 'minimally_processed', isDairy: true, info: 'Proteinreicher fermentierter Milchsnack ohne zugesetzten Zucker.', quickOpts: [150, 200, 300] },
  { id: 'kefir', name: 'Kefir natur', category: 'Milchprodukte & Eiweiß', unit: 'ml', defaultQty: 250, step: 50, icon: '🥛', healthScore: 89, caloriesPer100: 55, proteinPer100: 3.3, carbsPer100: 4.0, fatPer100: 3.0, fiberPer100: 0, sugarPer100: 4.0, saturatedFatPer100: 1.9, saltPer100: 0.1, foodQuality: 89, waterContribution: 0.84, foodGroups: ['Dairy'], processingLevel: 'minimally_processed', isDairy: true, info: 'Fermentiertes Milchgetränk mit natürlichem Milchzucker.', quickOpts: [150, 250, 400] },
  { id: 'kuerbiskerne', name: 'Kürbiskerne', category: 'Snacks & Süßes', unit: 'g', defaultQty: 30, step: 10, icon: '🌰', healthScore: 91, caloriesPer100: 559, proteinPer100: 30.2, carbsPer100: 10.7, fatPer100: 49.1, fiberPer100: 6.0, sugarPer100: 1.4, saturatedFatPer100: 8.7, saltPer100: 0.02, foodQuality: 91, waterContribution: 0.05, foodGroups: ['Nuts', 'Protein'], processingLevel: 'unprocessed', isNut: true, info: 'Mineralstoffreiche Kerne als Topping oder Snack.', quickOpts: [15, 30, 45] },
  { id: 'koettbullar', name: 'Köttbullar', category: 'Hauptspeisen', unit: 'g', defaultQty: 200, step: 50, icon: '🍽️', healthScore: 70, caloriesPer100: 215, proteinPer100: 12.5, carbsPer100: 9.0, fatPer100: 14.0, fiberPer100: 0.8, sugarPer100: 1.2, saturatedFatPer100: 5.0, saltPer100: 1.1, foodQuality: 70, waterContribution: 0.55, foodGroups: ['Protein'], processingLevel: 'processed', info: 'Schwedische Fleischbällchen; optional mit Beilage.', quickOpts: [150, 200, 300], options: [{ name: 'Beilage', key: 'side', choices: ['Ohne Beilage', 'Mit Reis', 'Mit Kartoffeln', 'Mit Preiselbeeren'] }] },
  { id: 'pudding_vanille', name: 'Vanillepudding', category: 'Snacks & Süßes', unit: 'g', defaultQty: 150, step: 50, icon: '🍮', healthScore: 58, caloriesPer100: 118, proteinPer100: 3.2, carbsPer100: 18.0, fatPer100: 3.5, fiberPer100: 0.2, sugarPer100: 13.0, saturatedFatPer100: 2.1, saltPer100: 0.12, foodQuality: 58, waterContribution: 0.78, foodGroups: ['Dairy', 'Sweets'], processingLevel: 'processed', isDairy: true, isSweet: true, info: 'Cremiger Vanillepudding.', quickOpts: [125, 150, 200] },
  { id: 'pudding_schoko', name: 'Schokopudding', category: 'Snacks & Süßes', unit: 'g', defaultQty: 150, step: 50, icon: '🍮', healthScore: 52, caloriesPer100: 130, proteinPer100: 3.2, carbsPer100: 20.0, fatPer100: 4.0, fiberPer100: 1.0, sugarPer100: 15.0, saturatedFatPer100: 2.3, saltPer100: 0.13, foodQuality: 52, waterContribution: 0.76, foodGroups: ['Dairy', 'Sweets'], processingLevel: 'processed', isDairy: true, isSweet: true, info: 'Cremiger Schokopudding.', quickOpts: [125, 150, 200] },
  { id: 'pudding_karamell', name: 'Karamellpudding', category: 'Snacks & Süßes', unit: 'g', defaultQty: 150, step: 50, icon: '🍮', healthScore: 50, caloriesPer100: 125, proteinPer100: 3.0, carbsPer100: 19.5, fatPer100: 4.0, fiberPer100: 0.1, sugarPer100: 15.0, saturatedFatPer100: 2.4, saltPer100: 0.13, foodQuality: 50, waterContribution: 0.76, foodGroups: ['Dairy', 'Sweets'], processingLevel: 'processed', isDairy: true, isSweet: true, info: 'Süßer Karamellpudding.', quickOpts: [125, 150, 200] },
  { id: 'pudding_erdbeer', name: 'Erdbeerpudding', category: 'Snacks & Süßes', unit: 'g', defaultQty: 150, step: 50, icon: '🍮', healthScore: 54, caloriesPer100: 120, proteinPer100: 3.0, carbsPer100: 19.0, fatPer100: 3.5, fiberPer100: 0.4, sugarPer100: 14.0, saturatedFatPer100: 2.0, saltPer100: 0.12, foodQuality: 54, waterContribution: 0.78, foodGroups: ['Dairy', 'Fruit', 'Sweets'], processingLevel: 'processed', isDairy: true, isFruit: true, isSweet: true, info: 'Fruchtiger Erdbeerpudding.', quickOpts: [125, 150, 200] },
  { id: 'pudding_sahne', name: 'Sahnepudding', category: 'Snacks & Süßes', unit: 'g', defaultQty: 150, step: 50, icon: '🍮', healthScore: 46, caloriesPer100: 165, proteinPer100: 3.0, carbsPer100: 17.0, fatPer100: 9.0, fiberPer100: 0.1, sugarPer100: 14.0, saturatedFatPer100: 5.7, saltPer100: 0.12, foodQuality: 46, waterContribution: 0.72, foodGroups: ['Dairy', 'Sweets'], processingLevel: 'processed', isDairy: true, isSweet: true, info: 'Cremiger Pudding mit höherem Sahneanteil.', quickOpts: [125, 150, 200] },
];


// Prüft den Katalog beim Laden und meldet Fehler in der Browser-Konsole (F12),
// damit Tippfehler beim Erweitern des Katalogs sofort auffallen.
// Gibt die Liste der gefundenen Probleme zurück (leer = alles in Ordnung).
function validateFoodCatalog(catalog) {
  const problems = [];
  const seenIds = new Set();

  catalog.forEach((food, index) => {
    const label = food && food.id ? food.id : `Eintrag ${index + 1}`;

    if (!food || !food.id) { problems.push(`${label}: id fehlt`); return; }
    if (seenIds.has(food.id)) problems.push(`${label}: id kommt doppelt vor`);
    seenIds.add(food.id);

    FOOD_REQUIRED_FIELDS.forEach(field => {
      if (food[field] === undefined) problems.push(`${label}: Feld "${field}" fehlt`);
    });

    if (!FOOD_CATEGORIES.includes(food.category)) problems.push(`${label}: unbekannte Kategorie "${food.category}"`);
    if (UNIT_GRAMS[food.unit] === undefined) problems.push(`${label}: unbekannte Einheit "${food.unit}"`);
  });

  if (problems.length) console.warn('NutriTrack – Probleme im Lebensmittelkatalog:\n' + problems.join('\n'));
  return problems;
}

validateFoodCatalog(foodCatalog);



/* ==========================================================================
   10. SCORE-ENGINE
   Alle Zahlen der Tagesbewertung (0–100). Die Berechnung selbst steht in
   engine.js. Fehlt ein Tagesziel, gilt der Wert aus DEFAULT_HEALTH_TARGETS.
   ========================================================================== */

const SCORE_CONFIG = deepFreeze({

  // Gewichtung der fünf Teilbewertungen (Summe = 1)
  weights: { quality: 0.30, nutrients: 0.35, variety: 0.15, hydration: 0.10, balance: 0.10 },

  // Qualität: Startwert ist healthScore/foodQuality des Lebensmittels, dann
  // Zu- und Abschläge (Ergebnis wird auf 0–100 begrenzt).
  defaultQuality: 50,
  qualityBonus:   { isVegetable: 10, isFruit: 8, isWholeGrain: 8, isLegume: 8, isNut: 6, isFish: 6 },
  qualityPenalty: { ultraProcessed: 15, isSweet: 10, isSugaryDrink: 15 },

  // Wasseranteil, falls ein Eintrag keinen eigenen waterContribution-Wert hat
  defaultWaterContribution: { liquid: 0.8, solid: 0.3 },

  // Nährstoffe: Abzug = Überschreitung (Anteil am Grenzwert) × perExcessRatio, höchstens maxPenalty
  nutrientPenalties: {
    sugar:        { perExcessRatio: 30, maxPenalty: 40 },
    saturatedFat: { perExcessRatio: 25, maxPenalty: 30 },
    salt:         { perExcessRatio: 25, maxPenalty: 30 }
  },

  // Vielfalt: Punkte je Lebensmittelgruppe und je verschiedenem Lebensmittel (jeweils mit Obergrenze)
  variety: { pointsPerGroup: 14, maxGroupPoints: 70, pointsPerDistinctFood: 6, maxDistinctPoints: 30 },

  // Balance (Kalorien): zwischen lowRatio und highRatio des Tagesziels = 100 Punkte.
  // Darunter: lowBaseScore + Anteil × lowSpan. Darüber: 100 − Überschreitung × highPenaltyPerRatio (mind. highFloor).
  // Danach fließen Kalorien- und Nährstoff-Score im Verhältnis calorieWeight : nutrientWeight ein.
  balance: {
    lowRatio: 0.6, lowBaseScore: 60, lowSpan: 40,
    highRatio: 1.2, highPenaltyPerRatio: 100, highFloor: 20,
    calorieWeight: 0.6, nutrientWeight: 0.4
  },

  // Schwellen für die Texte "Gut gelaufen / Es fehlt / Zu viel"
  feedback: {
    goodWaterShare: 0.8,      // ab 80 % des Wasserziels: Hydration gelobt
    goodVarietyScore: 60,
    goodProduceCount: 2,      // so viele Gemüse- ODER Obst-Einträge für das Lob
    goodQualityScore: 75,
    lowProteinShare: 0.7      // unter 70 % des Proteinziels: Hinweis
  },

  // Verbale Bewertung: erste Stufe, deren Mindestwert erreicht wird
  ratingLevels: [
    { min: 85, label: 'Exzellent' },
    { min: 75, label: 'Sehr gut' },
    { min: 60, label: 'Gut' },
    { min: 45, label: 'Ausgewogen' }
  ],
  ratingFallback: 'Ausbaufähig'
});



/* ==========================================================================
   11. KURZÜBERSICHT & TACHO
   ========================================================================== */

// Ab diesem Score zeigt die Kurzübersicht "Starke Bilanz"
const QUICK_OVERVIEW_STRONG_SCORE = 85;

// Farbverlauf des Tachos in der Kurzübersicht: erste Stufe mit score < below, sonst GAUGE_COLOR_TOP
const GAUGE_COLOR_STEPS = deepFreeze([
  { below: 40, colors: ['#f87171', '#fb923c'] },
  { below: 55, colors: ['#fb923c', '#fbbf24'] },
  { below: 70, colors: ['#fbbf24', '#facc15'] },
  { below: 85, colors: ['#a3e635', '#34d399'] }
]);
const GAUGE_COLOR_TOP = deepFreeze(['#34d399', '#22d3ee']);

// Länge des Halbkreis-Pfads im Tacho (muss zu stroke-dasharray in index.html passen)
const GAUGE_ARC_LENGTH = 251.2;

// Umfang des Kreises im Tacho der Kurzübersicht (2 · π · r, muss zu stroke-dasharray in index.html passen)
const GAUGE_CIRCLE_LENGTH = 439.8;

// Verzögerung, bis die Kurzübersicht nach dem App-Start eingeblendet wird
const QUICK_OVERVIEW_DELAY_MS = 350;

// Anzeigedauer der Toast-Meldungen
const TOAST_DURATION_MS = 2200;



/* ==========================================================================
   12. KI-BERATER (GEMINI)
   Stand der Modelle: November 2026. Google ersetzt Modelle regelmäßig
   (Übersicht: ai.google.dev/gemini-api/docs/deprecations). Ist ein Modell
   nicht mehr erreichbar (HTTP 404), wechselt ai.js automatisch auf das Fallback.
   ========================================================================== */

// Bevorzugtes Modell + automatischer Fallback bei Überlastung (503), Zeitüberschreitung
// oder nicht erreichbarem Modell (404). Bei jeder neuen Nachricht wird zuerst wieder
// das bevorzugte Modell versucht.
const GEMINI_MODEL_PRIMARY = 'gemini-3.7-flash-lite';
const GEMINI_MODEL_FALLBACK = 'gemini-3.5-flash-lite';

// Anzeigetext in den Badges ("3.8 Flash") – an EINER Stelle pflegen, ai.js trägt ihn ins Markup ein
const GEMINI_MODEL_LABEL = '3.7 Flash';

// Anfrage-URL: GEMINI_API_BASE_URL/<modell>:generateContent
const GEMINI_API_BASE_URL = 'https://generativelanguage.googleapis.com/v1beta/models';

// Der Key wird im Header gesendet (nicht in der URL). Eine Formatprüfung des Keys gibt es
// bewusst nicht: Google stellt von "AIza…" auf "AQ.…" um, künftige Formate bleiben so nutzbar.
const GEMINI_API_KEY_HEADER = 'x-goog-api-key';

// Steigende Wartezeiten zwischen den Versuchen beim bevorzugten Modell (nur bei Überlastung)
const GEMINI_RETRY_DELAYS_MS = deepFreeze([5000, 10000, 20000, 40000]);

// Maximale Wartezeit pro Einzelversuch (verhindert minutenlang "hängende" Anfragen)
const GEMINI_REQUEST_TIMEOUT_MS = 30000;

// Hinweis: temperature, topP und topK sind bei neuen Gemini-Modellen veraltet (werden ignoriert,
// künftig HTTP 400) und stehen deshalb NICHT mehr hier. maxOutputTokens zählt auch die
// "Denk"-Token mit, daher großzügig. thinkingLevel "low" hält die Antworten schnell.
const GEMINI_GENERATION_CONFIG = deepFreeze({
  maxOutputTokens: 2048,
  thinkingConfig: { thinkingLevel: 'none' }
});

// Obergrenze für den mitgeschickten Gesprächsverlauf (Nachrichten, nicht Paare).
// Ohne Grenze wächst jede Anfrage mit dem Chat und wird langsamer und teurer.
const CHAT_MAX_HISTORY_MESSAGES = 30;

// Wie viele Chats gespeichert und in der Seitenleiste aufgelistet werden (älteste fallen weg)
const CHAT_MAX_SAVED_CHATS = 10;

// Platzhalter für Chatnamen, bis echte Namen vergeben werden (siehe getChatDisplayName in ai.js)
const CHAT_PLACEHOLDER_NAME = 'Chatname';

// Längster Teil einer Google-Fehlermeldung, der im Chat angezeigt wird
const GEMINI_ERROR_TEXT_MAX_LENGTH = 300;
