/* ===========================================================================
   NutriTrack – js/engine.js

   Berechnungen ohne DOM-Zugriff: Gewichte, Personalisierung, Tagesziele,
   Nährwert-Summen, Score (0–100), Auswertungstexte, Verlaufsstatistik und
   Kurzübersicht-Texte. Die Anzeige übernimmt ui.js.

   Wird nach config.js und storage.js geladen. Aus storage.js werden benutzt:
   userProfile, getBaseHealthTargets, getDateFoodStore,
   normalizeLoggedFood. Alle Parameter stammen aus config.js (SCORE_CONFIG,
   ACTIVITY_TARGET_SCALING, PERSONALIZATION_MULTIPLIER_RANGE, ...).
   Wie die übrigen Skripte ist dies bewusst kein ES-Modul.
   =========================================================================== */



/* ===========================================================================
   1. EINHEITEN UND DATUM
   =========================================================================== */

/* Gewicht eines Eintrags in Gramm bzw. Milliliter (1 ml = 1 g). */
function getItemGramWeight(item) {
  const quantity = Number(item?.quantity) || 0;
  const gramsPerUnit = UNIT_GRAMS[item?.unit] ?? DEFAULT_UNIT_GRAMS;
  return quantity * gramsPerUnit;
}

/* ISO-Datum (YYYY-MM-DD, lokale Zeit) von heute minus daysAgo Tagen. */
function getISODaysAgo(daysAgo = 0) {
  const date = new Date();
  date.setHours(12, 0, 0, 0);
  date.setDate(date.getDate() - daysAgo);

  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}



/* ===========================================================================
   2. PERSONALISIERUNG UND TAGESZIELE
   =========================================================================== */

function getProfilePersonalization(profile = userProfile) {
  const ageGroupId = profile?.ageGroup || DEFAULT_PROFILE_ATTRIBUTES.ageGroup;
  const sportiness = Number(profile?.sportiness || DEFAULT_PROFILE_ATTRIBUTES.sportiness);
  const sleepQuality = Number(profile?.sleepQuality || DEFAULT_PROFILE_ATTRIBUTES.sleepQuality);

  const age = AGE_GROUPS.find(group => group.id === ageGroupId)
    || AGE_GROUPS.find(group => group.id === DEFAULT_PROFILE_ATTRIBUTES.ageGroup);
  const sport = SPORTINESS_LEVELS.find(level => level.value === sportiness)
    || SPORTINESS_LEVELS.find(level => level.value === DEFAULT_PROFILE_ATTRIBUTES.sportiness);
  const sleep = SLEEP_LEVELS.find(level => level.value === sleepQuality)
    || SLEEP_LEVELS.find(level => level.value === DEFAULT_PROFILE_ATTRIBUTES.sleepQuality);

  return { age, sport, sleep };
}

/* Leichter Einfluss von Alter, Aktivität und Schlaf auf den Gesamtscore. */
function getPersonalizationMultiplier(profile = userProfile) {
  const { age, sport, sleep } = getProfilePersonalization(profile);
  const product = age.factor * sport.factor * sleep.factor;

  return Math.max(
    PERSONALIZATION_MULTIPLIER_RANGE.min,
    Math.min(PERSONALIZATION_MULTIPLIER_RANGE.max, product)
  );
}

/*
   Tagesziele des Profils. Selbst gesetzte Werte (profile.healthTargets)
   gelten unverändert. Alle anderen Ziele werden anhand der Aktivitätsstufe
   skaliert, sofern ACTIVITY_TARGET_SCALING dafür einen Faktor enthält
   (Zucker-, Fett- und Salzgrenzen bleiben stehen).
*/
function getPersonalizedTargets(profile = userProfile) {
  const base = getBaseHealthTargets(profile);
  const activity = getProfilePersonalization(profile).sport.value;
  const targets = {};

  Object.keys(DEFAULT_HEALTH_TARGETS).forEach(key => {
    const isCustom = profile?.healthTargets?.[key] !== undefined;
    const scaling = ACTIVITY_TARGET_SCALING[key];

    if (isCustom || scaling === undefined) {
      targets[key] = base[key];
    } else {
      targets[key] = Math.round(
        DEFAULT_HEALTH_TARGETS[key] * (1 + (activity - NEUTRAL_ACTIVITY_LEVEL) * scaling)
      );
    }
  });

  return targets;
}

/* Ziel mit Rückfall auf den Standardwert (verhindert Division durch 0). */
function getTargetValue(targets, key) {
  return Number(targets?.[key]) || DEFAULT_HEALTH_TARGETS[key];
}



/* ===========================================================================
   3. TAGESANALYSE UND SCORE
   =========================================================================== */

function getRatingText(score) {
  const level = SCORE_CONFIG.ratingLevels.find(item => score >= item.min);
  return level ? level.label : SCORE_CONFIG.ratingFallback;
}

function createEmptyDailyAnalysis() {
  return {
    totalCalories: 0,
    totalProtein: 0,
    totalCarbs: 0,
    totalFat: 0,
    totalFiber: 0,
    totalSugar: 0,
    totalSaturatedFat: 0,
    totalSalt: 0,
    effectiveWaterMl: 0,
    scores: { quality: 0, nutrients: 0, variety: 0, hydration: 0, balance: 0, finalScore: 0 },
    ratingText: SCORE_CONFIG.ratingFallback,
    goodList: ['Noch keine Mahlzeiten für heute erfasst.'],
    missingList: ['Trage Lebensmittel oder Getränke ein.'],
    excessList: ['Keine Überschreitungen.']
  };
}

/* Qualitätswert eines einzelnen Eintrags (0–100) und Zähler für die Auswertung. */
function getEntryQualityScore(entry) {
  const cfg = SCORE_CONFIG;
  let score = entry.foodQuality ?? entry.healthScore ?? cfg.defaultQuality;

  Object.keys(cfg.qualityBonus).forEach(flag => {
    if (entry[flag]) score += cfg.qualityBonus[flag];
  });

  if (entry.processingLevel === 'ultra_processed') score -= cfg.qualityPenalty.ultraProcessed;
  if (entry.isSweet) score -= cfg.qualityPenalty.isSweet;
  if (entry.isSugaryDrink) score -= cfg.qualityPenalty.isSugaryDrink;

  return Math.max(0, Math.min(100, score));
}

function getNutrientExcessPenalty(total, limit, rule) {
  const excessRatio = Math.max(0, (total - limit) / limit);
  return Math.min(rule.maxPenalty, excessRatio * rule.perExcessRatio);
}

function calculateDailyNutritionEngine(entries, targets = getPersonalizedTargets()) {
  if (!Array.isArray(entries) || entries.length === 0) return createEmptyDailyAnalysis();

  const cfg = SCORE_CONFIG;

  let totalCalories = 0, totalProtein = 0, totalCarbs = 0, totalFat = 0;
  let totalFiber = 0, totalSugar = 0, totalSaturatedFat = 0, totalSalt = 0;
  let effectiveWaterMl = 0;
  let qualityWeightedSum = 0;
  let totalWeightGrams = 0;
  let vegCount = 0, fruitCount = 0;

  const foodGroups = new Set();
  const distinctFoods = new Set();

  entries.forEach(entry => {
    const grams = getItemGramWeight(entry);
    const factor = grams / 100;

    totalCalories += (entry.caloriesPer100 || 0) * factor;
    totalProtein += (entry.proteinPer100 || 0) * factor;
    totalCarbs += (entry.carbsPer100 || 0) * factor;
    totalFat += (entry.fatPer100 || 0) * factor;
    totalFiber += (entry.fiberPer100 || 0) * factor;
    totalSugar += (entry.sugarPer100 || 0) * factor;
    totalSaturatedFat += (entry.saturatedFatPer100 || 0) * factor;
    totalSalt += (entry.saltPer100 || 0) * factor;

    const waterShare = entry.waterContribution !== undefined
      ? entry.waterContribution
      : (entry.unit === 'ml' ? cfg.defaultWaterContribution.liquid : cfg.defaultWaterContribution.solid);
    effectiveWaterMl += grams * waterShare;

    if (entry.isVegetable) vegCount += 1;
    if (entry.isFruit) fruitCount += 1;

    qualityWeightedSum += getEntryQualityScore(entry) * grams;
    totalWeightGrams += grams;

    if (Array.isArray(entry.foodGroups)) {
      entry.foodGroups.forEach(group => foodGroups.add(group));
    } else if (entry.category) {
      foodGroups.add(entry.category);
    }

    distinctFoods.add(entry.foodId || entry.name);
  });

  /* 1. Qualität */
  const qualityScore = totalWeightGrams > 0
    ? Math.min(100, Math.max(0, qualityWeightedSum / totalWeightGrams))
    : 0;

  /* 2. Nährstoffe */
  const proteinTarget = getTargetValue(targets, 'protein');
  const fiberTarget = getTargetValue(targets, 'fiber');
  const sugarLimit = getTargetValue(targets, 'sugarMax');
  const satFatLimit = getTargetValue(targets, 'saturatedFatMax');
  const saltLimit = getTargetValue(targets, 'saltMax');
  const waterTarget = getTargetValue(targets, 'water');
  const calorieTarget = getTargetValue(targets, 'calories');

  const proteinAchievement = Math.min(1, totalProtein / proteinTarget);
  const fiberAchievement = Math.min(1, totalFiber / fiberTarget);
  const positiveNutrients = ((proteinAchievement + fiberAchievement) / 2) * 100;

  const penalties = cfg.nutrientPenalties;
  const totalPenalty =
    getNutrientExcessPenalty(totalSugar, sugarLimit, penalties.sugar) +
    getNutrientExcessPenalty(totalSaturatedFat, satFatLimit, penalties.saturatedFat) +
    getNutrientExcessPenalty(totalSalt, saltLimit, penalties.salt);

  const nutrientsScore = Math.min(100, Math.max(0, positiveNutrients - totalPenalty));

  /* 3. Vielfalt */
  const v = cfg.variety;
  const varietyScore = Math.min(
    100,
    Math.min(v.maxGroupPoints, foodGroups.size * v.pointsPerGroup) +
    Math.min(v.maxDistinctPoints, distinctFoods.size * v.pointsPerDistinctFood)
  );

  /* 4. Hydration */
  const hydrationScore = Math.min(100, Math.max(0, (effectiveWaterMl / waterTarget) * 100));

  /* 5. Balance (Kalorien + Nährstoffe) */
  const b = cfg.balance;
  const calorieRatio = totalCalories / calorieTarget;
  let calorieBalance = 100;

  if (calorieRatio < b.lowRatio) {
    calorieBalance = b.lowBaseScore + (calorieRatio / b.lowRatio) * b.lowSpan;
  } else if (calorieRatio > b.highRatio) {
    calorieBalance = Math.max(b.highFloor, 100 - (calorieRatio - b.highRatio) * b.highPenaltyPerRatio);
  }

  const balanceScore = Math.min(
    100,
    Math.max(0, calorieBalance * b.calorieWeight + nutrientsScore * b.nutrientWeight)
  );

  /* Gesamtscore */
  const w = cfg.weights;
  const weightedSum =
    qualityScore * w.quality +
    nutrientsScore * w.nutrients +
    varietyScore * w.variety +
    hydrationScore * w.hydration +
    balanceScore * w.balance;

  const finalScore = Math.round(
    Math.min(100, Math.max(0, weightedSum * getPersonalizationMultiplier()))
  );

  /* Auswertungstexte */
  const fb = cfg.feedback;
  const goodList = [];
  const missingList = [];
  const excessList = [];

  if (totalProtein >= proteinTarget) goodList.push('• Sehr gute Proteinversorgung erreicht.');
  if (effectiveWaterMl >= waterTarget * fb.goodWaterShare) goodList.push('• Ausreichende Flüssigkeits-Hydration.');
  if (varietyScore >= fb.goodVarietyScore) goodList.push('• Hohe Lebensmittelvielfalt über verschiedene Gruppen.');
  if (vegCount >= fb.goodProduceCount || fruitCount >= fb.goodProduceCount) goodList.push('• Gute Portionsmenge an Gemüse / Obst.');
  if (qualityScore >= fb.goodQualityScore) goodList.push('• Hoher Anteil an hochwertigen, naturnahen Lebensmitteln.');
  if (goodList.length === 0) goodList.push('• Erste gesunde Entscheidungen getroffen.');

  if (vegCount === 0) missingList.push('• Eine Portion frisches Gemüse fehlt noch.');
  if (totalFiber < fiberTarget) missingList.push(`• Ballaststoffe noch steigern (${Math.round(totalFiber)}g von ${fiberTarget}g).`);
  if (effectiveWaterMl < waterTarget) missingList.push(`• Wasserziel noch nicht vollständig (${Math.round(effectiveWaterMl)} ml / ${waterTarget} ml).`);
  if (totalProtein < proteinTarget * fb.lowProteinShare) missingList.push('• Proteinanteil könnte noch erhöht werden.');
  if (missingList.length === 0) missingList.push('• Optimal versorgt! Keine Lücken identifiziert.');

  if (totalSugar > sugarLimit) excessList.push(`• Zucker über Grenzwert (${Math.round(totalSugar)}g / max. ${sugarLimit}g).`);
  if (totalSaturatedFat > satFatLimit) excessList.push(`• Gesättigte Fette leicht erhöht (${Math.round(totalSaturatedFat)}g / max. ${satFatLimit}g).`);
  if (totalSalt > saltLimit) excessList.push(`• Salzzufuhr beachten (${totalSalt.toFixed(1)}g / max. ${saltLimit}g).`);
  if (excessList.length === 0) excessList.push('• Keine Nährstoffüberschreitungen heute.');

  return {
    totalCalories, totalProtein, totalCarbs, totalFat,
    totalFiber, totalSugar, totalSaturatedFat, totalSalt,
    effectiveWaterMl,
    scores: {
      quality: Math.round(qualityScore),
      nutrients: Math.round(nutrientsScore),
      variety: Math.round(varietyScore),
      hydration: Math.round(hydrationScore),
      balance: Math.round(balanceScore),
      finalScore
    },
    ratingText: getRatingText(finalScore),
    goodList, missingList, excessList
  };
}

/*
   Zeilen für die Rechenerklärung, z. B. "72% × 0,30 = 21.6%".
   Die Gewichte kommen aus SCORE_CONFIG.weights, damit Anzeige und
   Berechnung nicht auseinanderlaufen.
*/
function getScoreBreakdown(scores) {
  return Object.keys(SCORE_CONFIG.weights).map(key => {
    const weight = SCORE_CONFIG.weights[key];
    const score = scores[key];
    const contribution = score * weight;

    return {
      key,
      score,
      weight,
      contribution,
      text: `${score}% × ${weight.toFixed(2).replace('.', ',')} = ${contribution.toFixed(1)}%`
    };
  });
}



/* ===========================================================================
   4. VERLAUFSSTATISTIK
   =========================================================================== */

/*
   Werte für "Historischer Verlauf". Es zählen nur Tage mit Einträgen.
   - today: Score von heute (unabhängig vom angezeigten Datum), sonst null
   - avgShort / avgLong: Durchschnitt der letzten HISTORY_SHORT_DAYS bzw.
     HISTORY_LONG_DAYS Tage inkl. heute, sonst null
   - best / worst: { score, iso } des besten bzw. schlechtesten Tages im
     langen Zeitraum, sonst null
   Berechnet mit den aktuellen Tageszielen des Profils.
*/
function getHistoricalScoreStats(targets = getPersonalizedTargets()) {
  const store = getDateFoodStore();
  const days = [];

  for (let daysAgo = 0; daysAgo < HISTORY_LONG_DAYS; daysAgo += 1) {
    const iso = getISODaysAgo(daysAgo);
    const entries = store.dates?.[iso];
    if (!Array.isArray(entries) || entries.length === 0) continue;

    const analysis = calculateDailyNutritionEngine(entries.map(normalizeLoggedFood), targets);
    days.push({ iso, daysAgo, score: analysis.scores.finalScore });
  }

  const average = list => (
    list.length ? Math.round(list.reduce((sum, day) => sum + day.score, 0) / list.length) : null
  );

  const shortDays = days.filter(day => day.daysAgo < HISTORY_SHORT_DAYS);
  const todayEntry = days.find(day => day.daysAgo === 0);

  let best = null;
  let worst = null;
  days.forEach(day => {
    if (!best || day.score > best.score) best = { score: day.score, iso: day.iso };
    if (!worst || day.score < worst.score) worst = { score: day.score, iso: day.iso };
  });

  return {
    today: todayEntry ? todayEntry.score : null,
    avgShort: average(shortDays),
    avgLong: average(days),
    best,
    worst,
    daysCounted: days.length
  };
}



/* ===========================================================================
   5. KURZÜBERSICHT UND TACHO
   =========================================================================== */

/* Farbpaar für den Tacho: erste Stufe mit score < below, sonst GAUGE_COLOR_TOP. */
function getOverviewGaugeColors(score) {
  const step = GAUGE_COLOR_STEPS.find(item => score < item.below);
  return step ? step.colors : GAUGE_COLOR_TOP;
}

/* Wert für stroke-dashoffset des Tacho-Bogens (0 % = voller Bogen leer). */
function getGaugeDashOffset(score) {
  const clamped = Math.max(0, Math.min(100, Number(score) || 0));
  return GAUGE_ARC_LENGTH - GAUGE_ARC_LENGTH * (clamped / 100);
}

/*
   Hinweis der Kurzübersicht: Der schwächste Teilbereich des Tages wird mit
   den tatsächlich berechneten Werten benannt. Es werden keine Prognosen
   versprochen, die die App nicht selbst berechnet.
*/
function buildQuickOverviewInsight(data, targets, hasEntries) {
  if (!hasEntries) {
    return { icon: '📝', text: 'Heute noch keine Einträge erfasst. Trag dein erstes Lebensmittel ein, um deinen Health-Score zu sehen.' };
  }

  const s = data.scores;

  if (s.finalScore >= QUICK_OVERVIEW_STRONG_SCORE) {
    return { icon: '🏆', text: `Starke Bilanz: Dein Score liegt heute bei ${s.finalScore}% (${data.ratingText}). Die meisten deiner Ziele sind bereits erreicht.` };
  }

  const waterTarget = getTargetValue(targets, 'water');
  const fiberTarget = getTargetValue(targets, 'fiber');
  const proteinTarget = getTargetValue(targets, 'protein');
  const sugarLimit = getTargetValue(targets, 'sugarMax');
  const saltLimit = getTargetValue(targets, 'saltMax');
  const satFatLimit = getTargetValue(targets, 'saturatedFatMax');
  const calorieTarget = getTargetValue(targets, 'calories');

  const waterLeft = Math.max(0, Math.round(waterTarget - data.effectiveWaterMl));
  const fiberLeft = Math.max(0, Math.round(fiberTarget - data.totalFiber));
  const proteinLeft = Math.max(0, Math.round(proteinTarget - data.totalProtein));
  const sugarOver = Math.max(0, Math.round(data.totalSugar - sugarLimit));
  const saltOver = Math.max(0, Math.round((data.totalSalt - saltLimit) * 10) / 10);
  const satFatOver = Math.max(0, Math.round(data.totalSaturatedFat - satFatLimit));
  const calorieLeft = Math.round(calorieTarget - data.totalCalories);

  const dimensions = [
    ['quality', s.quality],
    ['nutrients', s.nutrients],
    ['variety', s.variety],
    ['hydration', s.hydration],
    ['balance', s.balance]
  ];
  dimensions.sort((a, b) => a[1] - b[1]);
  const weakest = dimensions[0][0];

  if (weakest === 'hydration' && waterLeft > 0) {
    return { icon: '💧', text: `Dir fehlen noch ${waterLeft} ml bis zu deinem Wasserziel (${Math.round(data.effectiveWaterMl)} / ${waterTarget} ml) – aktuell dein größter Hebel.` };
  }

  if (weakest === 'nutrients') {
    if (sugarOver > 0) return { icon: '🍬', text: `Der Zucker liegt heute ${sugarOver} g über dem Grenzwert (${Math.round(data.totalSugar)} / ${sugarLimit} g). Das drückt gerade am stärksten auf deinen Score.` };
    if (saltOver > 0) return { icon: '🧂', text: `Salz liegt ${saltOver.toFixed(1)} g über dem Grenzwert (${data.totalSalt.toFixed(1)} / ${saltLimit} g).` };
    if (satFatOver > 0) return { icon: '🥓', text: `Gesättigte Fette liegen ${satFatOver} g über dem Grenzwert (${Math.round(data.totalSaturatedFat)} / ${satFatLimit} g).` };
    if (proteinLeft > 0) return { icon: '🍗', text: `Dir fehlen noch ${proteinLeft} g Protein bis zum Ziel (${Math.round(data.totalProtein)} / ${proteinTarget} g).` };
    if (fiberLeft > 0) return { icon: '🌾', text: `Ballaststoffe fehlen noch ${fiberLeft} g bis zum Ziel (${Math.round(data.totalFiber)} / ${fiberTarget} g).` };
  }

  if (weakest === 'variety') {
    return { icon: '🥗', text: `Deine Lebensmittelvielfalt liegt bei ${s.variety}%. Ein Lebensmittel aus einer neuen Gruppe – z. B. Gemüse oder Hülsenfrüchte – würde den Score direkt verbessern.` };
  }

  if (weakest === 'quality') {
    return { icon: '🌱', text: `Die Qualität deiner bisherigen Auswahl liegt bei ${s.quality}%. Naturbelassene, wenig verarbeitete Lebensmittel würden diesen Wert steigern.` };
  }

  if (weakest === 'balance') {
    if (calorieLeft > 0) return { icon: '⚖️', text: `Du hast noch ${calorieLeft} kcal bis zu deinem Tagesziel (${Math.round(data.totalCalories)} / ${calorieTarget} kcal).` };
    return { icon: '⚖️', text: `Du liegst ${Math.abs(calorieLeft)} kcal über deinem Tagesziel (${Math.round(data.totalCalories)} / ${calorieTarget} kcal).` };
  }

  return { icon: '👍', text: `Dein Score liegt aktuell bei ${s.finalScore}% (${data.ratingText}). In den Statistiken findest du alle Details zu deinen Nährwerten.` };
}
