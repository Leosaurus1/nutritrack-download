/* ===========================================================================
   NutriTrack – js/storage.js

   Lokaler Zustand, localStorage und Datenmigration. Diese Datei wird nach
   config.js geladen: Alle dort definierten Konstanten stehen daher bereits
   global zur Verfügung. Wie die übrigen Skripte ist dies bewusst kein ES-
   Modul, damit die Funktionen auch für Inline-Handler erreichbar bleiben.

   Es gibt genau EIN Profil ("Du"). Seine Daten (Altersgruppe, Bewegung,
   Erholung, eigene Gesundheitsziele) werden gespeichert und fließen in die
   Berechnung ein; eine Oberfläche zum Ändern gibt es derzeit nicht.
   =========================================================================== */



/* ===========================================================================
   1. APP-ZUSTAND
   =========================================================================== */

let userProfile = createDefaultProfile();
let selectedDate = getTodayISO();
let loggedFoods = [];
let appSettings = { ...DEFAULT_APP_SETTINGS };



/* ===========================================================================
   2. ALLGEMEINE HILFSFUNKTIONEN
   =========================================================================== */

function getTodayISO() {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

function formatBytes(bytes) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
}

function getLocalStorageUsageBytes() {
  let bytes = 0;

  try {
    for (let index = 0; index < localStorage.length; index += 1) {
      const key = localStorage.key(index) || '';
      bytes += new Blob([key, localStorage.getItem(key) || '']).size;
    }
  } catch (error) {
    console.warn('Speicherverbrauch konnte nicht ermittelt werden:', error);
  }

  return bytes;
}

function updateStorageUsageUI() {
  const used = document.getElementById('settings-storage-used');
  const bar = document.getElementById('settings-storage-bar');
  const limit = document.getElementById('settings-storage-limit');
  if (!used || !bar || !limit) return;

  const bytes = getLocalStorageUsageBytes();
  const percent = Math.min(100, Math.round((bytes / STORAGE_BUDGET_BYTES) * 100));

  used.textContent = formatBytes(bytes);
  bar.style.width = `${Math.min(100, Math.max(0.5, (bytes / STORAGE_BUDGET_BYTES) * 100))}%`;
  limit.textContent = `ca. 5 MB Richtwert · ${percent}%`;
}



/* ===========================================================================
   3. EIGENE LEBENSMITTEL
   =========================================================================== */

function loadPersistentCustomFoods() {
  try {
    const storedFoods = JSON.parse(localStorage.getItem(CUSTOM_FOODS_STORAGE_KEY) || '[]');
    if (!Array.isArray(storedFoods)) return;

    const existingIds = new Set(foodCatalog.map(food => food.id));
    storedFoods.forEach(food => {
      if (!food || !food.id || existingIds.has(food.id)) return;
      foodCatalog.push(food);
      existingIds.add(food.id);
    });
  } catch (error) {
    console.warn('Eigene Lebensmittel konnten nicht geladen werden:', error);
  }
}

function savePersistentCustomFoods() {
  try {
    const customFoods = foodCatalog.filter(food => food.isCustomPersistent);
    localStorage.setItem(CUSTOM_FOODS_STORAGE_KEY, JSON.stringify(customFoods));
  } catch (error) {
    console.warn('Eigene Lebensmittel konnten nicht gespeichert werden:', error);
  }
}



/* ===========================================================================
   4. EINSTELLUNGEN UND PROFIL
   =========================================================================== */

function loadAppSettings() {
  try {
    const storedSettings = JSON.parse(localStorage.getItem(SETTINGS_STORAGE_KEY) || '{}');
    appSettings = { ...DEFAULT_APP_SETTINGS, ...(storedSettings || {}) };

    // Die früher gespeicherte Kontenanzahl gibt es nicht mehr.
    if ('maxProfiles' in appSettings) {
      delete appSettings.maxProfiles;
      saveAppSettings();
    }
  } catch (error) {
    console.warn('Einstellungen konnten nicht geladen werden:', error);
    appSettings = { ...DEFAULT_APP_SETTINGS };
  }

  appSettings.retentionDays = Math.max(
    RETENTION_LIMITS.min,
    Math.min(RETENTION_LIMITS.max, Number(appSettings.retentionDays) || RETENTION_LIMITS.default)
  );
  if (!QUICK_OVERVIEW_OPTIONS.some(option => option.value === appSettings.quickOverviewMode)) {
    appSettings.quickOverviewMode = DEFAULT_APP_SETTINGS.quickOverviewMode;
  }
  if (!DARK_MODE_OPTIONS.some(option => option.value === appSettings.darkMode)) {
    appSettings.darkMode = DEFAULT_APP_SETTINGS.darkMode;
  }
}

function saveAppSettings() {
  try {
    localStorage.setItem(SETTINGS_STORAGE_KEY, JSON.stringify(appSettings));
  } catch (error) {
    console.warn('Einstellungen konnten nicht gespeichert werden:', error);
  }
}

function ensureProfileHealthTargets(profile) {
  if (!profile.healthTargets || typeof profile.healthTargets !== 'object') {
    profile.healthTargets = {};
  }

  Object.keys(DEFAULT_HEALTH_TARGETS).forEach(key => {
    const value = Number(profile.healthTargets[key]);
    if (!Number.isFinite(value) || value < 0) delete profile.healthTargets[key];
  });
}

function getBaseHealthTargets(profile = userProfile) {
  const targets = { ...DEFAULT_HEALTH_TARGETS };
  if (!profile) return targets;

  ensureProfileHealthTargets(profile);
  Object.keys(targets).forEach(key => {
    if (profile.healthTargets[key] !== undefined) {
      targets[key] = Number(profile.healthTargets[key]);
    }
  });

  return targets;
}

function createDefaultProfile() {
  return {
    id: DEFAULT_PROFILE_ID,
    name: DEFAULT_PROFILE_NAME,
    ...DEFAULT_PROFILE_ATTRIBUTES,
    healthTargets: {}
  };
}

function loadProfile() {
  let stored = null;

  try {
    stored = JSON.parse(localStorage.getItem(PROFILE_STORAGE_KEY));

    // Einmalige Übernahme aus der Zeit mit mehreren Profilen: Nur "Du" bleibt erhalten.
    if (!stored) {
      const legacyProfiles = JSON.parse(localStorage.getItem(LEGACY_PROFILES_STORAGE_KEY));
      if (Array.isArray(legacyProfiles)) {
        stored = legacyProfiles.find(item => item?.id === DEFAULT_PROFILE_ID) || null;
      }
    }
  } catch (error) {
    console.warn('Profil konnte nicht geladen werden:', error);
  }

  const isUsable = stored && typeof stored === 'object' && !Array.isArray(stored);
  userProfile = { ...createDefaultProfile(), ...(isUsable ? stored : {}) };
  userProfile.id = DEFAULT_PROFILE_ID;
  userProfile.name = DEFAULT_PROFILE_NAME;

  if (!AGE_GROUPS.some(group => group.id === userProfile.ageGroup)) {
    userProfile.ageGroup = DEFAULT_PROFILE_ATTRIBUTES.ageGroup;
  }
  if (!SPORTINESS_LEVELS.some(level => level.value === Number(userProfile.sportiness))) {
    userProfile.sportiness = DEFAULT_PROFILE_ATTRIBUTES.sportiness;
  }
  if (!SLEEP_LEVELS.some(level => level.value === Number(userProfile.sleepQuality))) {
    userProfile.sleepQuality = DEFAULT_PROFILE_ATTRIBUTES.sleepQuality;
  }
  ensureProfileHealthTargets(userProfile);

  // Alte Daten weiterer Profile erst entfernen, wenn "Du" sicher im neuen Format gespeichert ist.
  if (saveProfile()) removeObsoleteProfileStorage();
}

function saveProfile() {
  try {
    localStorage.setItem(PROFILE_STORAGE_KEY, JSON.stringify(userProfile));
    return true;
  } catch (error) {
    console.warn('Profil konnte nicht gespeichert werden:', error);
    return false;
  }
}

/*
   Entfernt alles, was aus der Zeit mit mehreren Profilen übrig ist: die alte
   Profilliste, das aktive Profil sowie Tagebuch, Favoriten und Chat-Verlauf
   aller Profile außer "Du".
*/
function removeObsoleteProfileStorage() {
  try {
    const keep = new Set([getFoodsStorageKey(), getFavoritesStorageKey(), getChatHistoryStorageKey()]);
    const prefixes = [FOODS_STORAGE_PREFIX, FAVORITES_STORAGE_PREFIX, CHAT_HISTORY_STORAGE_PREFIX];
    const obsoleteKeys = [LEGACY_PROFILES_STORAGE_KEY, LEGACY_ACTIVE_PROFILE_STORAGE_KEY];

    for (let index = 0; index < localStorage.length; index += 1) {
      const key = localStorage.key(index);
      if (key && !keep.has(key) && prefixes.some(prefix => key.startsWith(prefix))) obsoleteKeys.push(key);
    }

    obsoleteKeys.forEach(key => localStorage.removeItem(key));
  } catch (error) {
    console.warn('Alte Profildaten konnten nicht entfernt werden:', error);
  }
}



/* ===========================================================================
   5. TAGEBUCH UND FAVORITEN
   =========================================================================== */

function getFoodsStorageKey() {
  return `${FOODS_STORAGE_PREFIX}${DEFAULT_PROFILE_ID}`;
}

function getFavoritesStorageKey() {
  return `${FAVORITES_STORAGE_PREFIX}${DEFAULT_PROFILE_ID}`;
}

function getDateFoodStore() {
  try {
    const raw = localStorage.getItem(getFoodsStorageKey());
    if (!raw) return { dates: {} };

    const parsed = JSON.parse(raw);
    // Frühere Versionen speicherten eine einzelne Liste statt eines Tagesarchivs.
    if (Array.isArray(parsed)) return { dates: { [getTodayISO()]: parsed } };
    if (parsed && typeof parsed === 'object' && parsed.dates && typeof parsed.dates === 'object') {
      return parsed;
    }
  } catch (error) {
    console.warn('Tagebuch-Daten konnten nicht gelesen werden:', error);
  }

  return { dates: {} };
}

function saveDateFoodStore(store) {
  try {
    localStorage.setItem(getFoodsStorageKey(), JSON.stringify(store));
  } catch (error) {
    console.warn('Fehler beim Speichern der Lebensmittel:', error);
  }
}

function pruneStoreByRetention(store) {
  const retentionDays = Number(appSettings.retentionDays) || 0;
  if (!store?.dates || retentionDays <= 0) return false;

  const cutoff = new Date();
  cutoff.setHours(0, 0, 0, 0);
  cutoff.setDate(cutoff.getDate() - retentionDays);

  let changed = false;
  Object.keys(store.dates).forEach(iso => {
    const [year, month, day] = iso.split('-').map(Number);
    if (!year || !month || !day) return;
    if (new Date(year, month - 1, day) < cutoff) {
      delete store.dates[iso];
      changed = true;
    }
  });

  return changed;
}

function applyRetention() {
  const store = getDateFoodStore();
  if (pruneStoreByRetention(store)) saveDateFoodStore(store);
}

function normalizeLoggedFood(item) {
  const catalogFood = foodCatalog.find(food => food.id === item.foodId || food.name === item.name);
  const fallback = item.unit === 'ml'
    ? { waterContribution: 0.9 }
    : { waterContribution: 0.3 };
  const source = catalogFood || fallback;

  return {
    ...item,
    foodQuality: item.foodQuality ?? source.foodQuality ?? source.healthScore ?? item.healthScore ?? 50,
    waterContribution: item.waterContribution ?? source.waterContribution ?? 0.5,
    caloriesPer100: item.caloriesPer100 ?? source.caloriesPer100 ?? 150,
    proteinPer100: item.proteinPer100 ?? source.proteinPer100 ?? 5,
    carbsPer100: item.carbsPer100 ?? source.carbsPer100 ?? 20,
    fatPer100: item.fatPer100 ?? source.fatPer100 ?? 5,
    fiberPer100: item.fiberPer100 ?? source.fiberPer100 ?? 1.5,
    sugarPer100: item.sugarPer100 ?? source.sugarPer100 ?? 5,
    saturatedFatPer100: item.saturatedFatPer100 ?? source.saturatedFatPer100 ?? 2,
    saltPer100: item.saltPer100 ?? source.saltPer100 ?? 0.5,
    foodGroups: item.foodGroups ?? source.foodGroups ?? ['Custom'],
    processingLevel: item.processingLevel ?? source.processingLevel ?? 'processed'
  };
}

function loadLoggedFoods() {
  let raw = null;
  try {
    raw = localStorage.getItem(getFoodsStorageKey());
  } catch (error) {
    console.warn('Tagebuch-Rohdaten konnten nicht gelesen werden:', error);
  }

  const store = getDateFoodStore();
  const wasLegacyArray = (() => {
    try { return Boolean(raw) && Array.isArray(JSON.parse(raw)); }
    catch (error) { return false; }
  })();

  const wasPruned = pruneStoreByRetention(store);
  if (!Array.isArray(store.dates[selectedDate])) store.dates[selectedDate] = [];

  const originalFoods = store.dates[selectedDate];
  loggedFoods = originalFoods.map(normalizeLoggedFood);
  store.dates[selectedDate] = loggedFoods;

  if (wasLegacyArray || wasPruned || JSON.stringify(originalFoods) !== JSON.stringify(loggedFoods)) {
    saveDateFoodStore(store);
  }
}

function saveLoggedFoods() {
  const store = getDateFoodStore();
  store.dates[selectedDate] = loggedFoods;
  saveDateFoodStore(store);
}

function loadFavorites() {
  try {
    const favorites = JSON.parse(localStorage.getItem(getFavoritesStorageKey()) || '[]');
    return Array.isArray(favorites) ? favorites.slice(0, MAX_FAVORITES) : [];
  } catch (error) {
    console.warn('Favoriten konnten nicht geladen werden:', error);
    return [];
  }
}

function saveFavorites(favorites) {
  try {
    const validFavorites = Array.isArray(favorites) ? favorites.slice(0, MAX_FAVORITES) : [];
    localStorage.setItem(getFavoritesStorageKey(), JSON.stringify(validFavorites));
  } catch (error) {
    console.warn('Favoriten konnten nicht gespeichert werden:', error);
  }
}

/* ----- Chat-Verlauf des KI-Beraters (neueste zuerst) -----
   Form eines Chats: { id, updatedAt (ms), messages: [{ role: 'user' | 'model', parts: [{ text }] }] } */

function getChatHistoryStorageKey() {
  return `${CHAT_HISTORY_STORAGE_PREFIX}${DEFAULT_PROFILE_ID}`;
}

function loadSavedChats() {
  try {
    const chats = JSON.parse(localStorage.getItem(getChatHistoryStorageKey()) || '[]');
    if (!Array.isArray(chats)) return [];

    return chats
      .filter(chat => chat && typeof chat.id === 'string' && Array.isArray(chat.messages) && chat.messages.length > 0)
      .slice(0, CHAT_MAX_SAVED_CHATS);
  } catch (error) {
    console.warn('Chat-Verlauf konnte nicht geladen werden:', error);
    return [];
  }
}

function saveSavedChats(chats) {
  try {
    const validChats = Array.isArray(chats) ? chats.slice(0, CHAT_MAX_SAVED_CHATS) : [];
    localStorage.setItem(getChatHistoryStorageKey(), JSON.stringify(validChats));
    return true;
  } catch (error) {
    console.warn('Chat-Verlauf konnte nicht gespeichert werden:', error);
    return false;
  }
}



/* ===========================================================================
   5b. GEMINI-API-KEY
   =========================================================================== */

function getGeminiApiKey() {
  try {
    return (localStorage.getItem(GEMINI_API_KEY_STORAGE_KEY) || '').trim();
  } catch (error) {
    console.warn('API-Key konnte nicht gelesen werden:', error);
    return '';
  }
}

/* Gibt true bei Erfolg zurück, damit die UI Toast und Anzeige steuern kann. */
function saveGeminiApiKey(value) {
  try {
    localStorage.setItem(GEMINI_API_KEY_STORAGE_KEY, String(value || '').trim());
    return true;
  } catch (error) {
    console.warn('API-Key konnte nicht gespeichert werden:', error);
    return false;
  }
}

function clearGeminiApiKey() {
  try {
    localStorage.removeItem(GEMINI_API_KEY_STORAGE_KEY);
    return true;
  } catch (error) {
    console.warn('API-Key konnte nicht entfernt werden:', error);
    return false;
  }
}



/* ===========================================================================
   6. KOMPATIBILITÄT UND ANZEIGE-EINSTELLUNGEN
   =========================================================================== */

function migrateLegacyData() {
  try {
    const legacyFoods = localStorage.getItem(LEGACY_FOODS_KEY);
    const profileFoodsKey = getFoodsStorageKey();
    if (legacyFoods && !localStorage.getItem(profileFoodsKey)) {
      localStorage.setItem(profileFoodsKey, legacyFoods);
    }
  } catch (error) {
    console.warn('Migration fehlgeschlagen:', error);
  }
}

function resolveDarkModeActive() {
  const mode = appSettings.darkMode || DEFAULT_APP_SETTINGS.darkMode;
  if (mode === 'on') return true;
  if (mode === 'off') return false;
  return Boolean(window.matchMedia?.('(prefers-color-scheme: dark)').matches);
}

function applyDarkMode() {
  const isDark = resolveDarkModeActive();
  document.documentElement.classList.toggle('dark', isDark);

  const themeColorMeta = document.querySelector('meta[name="theme-color"]');
  if (themeColorMeta) themeColorMeta.setAttribute('content', isDark ? '#0b1220' : '#ffffff');
}

function shouldShowQuickOverviewOnLoad() {
  const mode = appSettings.quickOverviewMode || DEFAULT_APP_SETTINGS.quickOverviewMode;
  if (mode === 'never') return false;
  if (mode === 'onOpen') return true;

  try {
    if (localStorage.getItem(QUICK_OVERVIEW_LAST_SHOWN_KEY) === getTodayISO()) return false;
  } catch (error) {
    console.warn('Zeitpunkt der Kurzübersicht konnte nicht gelesen werden:', error);
  }

  return Array.isArray(loggedFoods) && loggedFoods.length > 0;
}

function markQuickOverviewShownToday() {
  try {
    localStorage.setItem(QUICK_OVERVIEW_LAST_SHOWN_KEY, getTodayISO());
  } catch (error) {
    console.warn('Zeitpunkt der Kurzübersicht konnte nicht gespeichert werden:', error);
  }
}

loadPersistentCustomFoods();
